from pathlib import Path
import hashlib,json,subprocess,zipfile,re,shutil
R=Path('/workspace/russian-companion');W=Path(__file__).parent;B=R/'audit/gpt61-sol-high-comprehensive-2026-10-19';D=B/'engineering-unit13-affected-integration-2026-10-27';D.mkdir()
base='0c1bbdeb265d03224e0fbe859c006745f0b72813';pair='31ac807387253082c44bd2f6d67021478f0df66e';git=lambda *a:subprocess.check_output(['git',*a],cwd=R,text=True).strip();blob=lambda s,n:subprocess.check_output(['git','show',s+':'+n],cwd=R);sha=lambda b:hashlib.sha256(b).hexdigest();assert git('rev-parse','HEAD')==base and not git('status','--porcelain')
files=['app/src/test/java/dev/russiancompanion/v2/Unit12BindingConservationTest.kt','app/src/test/java/dev/russiancompanion/v2/Unit12GenderCompatibilityTest.kt']
with zipfile.ZipFile(D/'ORIGINAL_COMPARISON_TESTS.zip','x',zipfile.ZIP_DEFLATED) as z:
 for n in files:z.write(R/n,n)
kernel='app/src/main/java/dev/russiancompanion/v2/curriculum/V2CumulativeReview.kt';ref='app/src/test/resources/reviewed-curriculum-cyrillic.json';k='src/main/java/dev/russiancompanion/v2/curriculum/V2CumulativeReview.kt'
recorded=lambda s:next(x['sha256'] for x in json.loads(blob(s,ref))['files'] if x['path']==k)
assert recorded(pair)==sha(blob(pair,kernel))
wrong='aa93df85b4290406d5b78b0035b4a77912ae25fe';assert recorded(wrong)!=sha(blob(wrong,kernel))
(D/'HISTORICAL_PAIR_PROOF.json').write_text(json.dumps(dict(plannedPointerCorrectedFrom=wrong,plannedPointerRecordedHash=recorded(wrong),plannedPointerActualKernelHash=sha(blob(wrong,kernel)),actualMatchingPair=pair,recordedHash=recorded(pair),actualKernelSha256=sha(blob(pair,kernel)),referenceSha256=sha(blob(pair,ref)),reason='aa93already contains Unit13core but its reference still records Unit12kernel;31acis the genuine matching post-Unit12/pre-Unit13pair',noTestExecuted=True),indent=2)+'\n')
p=R/files[0];old=p.read_text();t=old
line='        assertEquals(pack.units.filter { it.number != 12 }, before12.units.filter { it.number != 12 })';assert t.count(line)==1;t=t.replace(line,'        // Original whole-pack equality belongs before the exact Unit13 declaration transition.\n        RecordedCurriculumConservationScope.beforeUnit13PresentReview(root, pack).let { pack ->\n    '+line+'\n        }')
t=t.replace('val now = Json.parseToJsonElement(File(root, path).readText()).jsonObject','val now = Json.parseToJsonElement(historicalBytes(path).decodeToString()).jsonObject')
t=t.replace('MessageDigest.getInstance("SHA-256").digest(File(root, "app/$name").readBytes())','MessageDigest.getInstance("SHA-256").digest(historicalBytes("app/$name"))')
assert t.endswith('}\n');t=t[:-2]+f'''    // Original Unit12 hash/append contract: keep a genuine matching kernel/reference pair.
    // Unit13BindingConservationTest independently guards the actual-current pair and mutation refusals.
    private fun historicalBytes(path: String): ByteArray {{
        val process = ProcessBuilder("git", "show", "{pair}:$path").directory(root).start()
        val bytes = process.inputStream.readBytes()
        assertEquals("Historical Unit12 reference input $path", 0, process.waitFor())
        return bytes
    }}
}}
''';p.write_text(t)
p=R/files[1];t=p.read_text();start=t.index('        val priorDeclarationOnly =');end=t.index('        for (legacy13',start);block=t[start:end];t=t[:start]+'        // Scope only this original equality; runtime, eligibility and mutation checks below stay current.\n        RecordedCurriculumConservationScope.beforeUnit13PresentReview(root, pack).let { pack ->\n'+''.join('    '+line+'\n' for line in block.splitlines())+'        }\n'+t[end:];p.write_text(t)
# Capture every original assertion invocation; preserve order/arguments after harmless indentation.
def assertions(t):
 out=[]
 for m in re.finditer(r'\b(assert\w+|fail)\s*\(',t):
  start=m.start();i=m.end();depth=1;quote=None;escape=False
  while depth:
   c=t[i];i+=1
   if quote:
    if escape:escape=False
    elif c=='\\':escape=True
    elif c==quote:quote=None
   elif c in '\"\'':quote=c
   elif c=='(':depth+=1
   elif c==')':depth-=1
  out.append(re.sub(r'\s+',' ',t[start:i]))
 return out
reviews=[]
for n in files:
 old=blob(base,n).decode();new=(R/n).read_text();a=assertions(old);b=assertions(new);j=0
 for x in b:
  if j<len(a) and x==a[j]:j+=1
 assert j==len(a),(n,j,len(a));reviews.append(dict(path=n,originalSha256=sha(old.encode()),newSha256=sha(new.encode()),originalAssertions=len(a),newAssertions=len(b),everyOriginalAssertionPreservedInOrder=True))
(D/'COMPARISON_REVIEW.json').write_text(json.dumps(reviews,indent=2)+'\n')
prior=B/'engineering-unit13-source-reconciliation-2026-10-27';scope=json.loads((prior/'NEXT_AFFECTED_SCOPE.json').read_text());assert scope['plannedClasses']==len(scope['selectors'])==83
(D/'SCOPE.json').write_text(json.dumps(scope,indent=2)+'\n');(W/'SCOPE.json').write_text(json.dumps(scope,indent=2)+'\n')
old=Path('/workspace/artifacts/unit12-source-reconciliation-2026-10-27')
for n in ['run.py','resources.gradle','launch.py','supervise.py','durable_monitor.py']:
 t=(old/n).read_text()
 if n=='run.py':
  begin=t.index('selectors=[');end=t.index('\nfor selector',begin);t=t[:begin]+"selectors=json.loads((W/'SCOPE.json').read_text())['selectors']"+t[end:]
  t=t.replace(' and len(names)==462',' and len(names)>0')
  t=t.replace('462 selected methods/79 full classes: affected Unit12 source bindings/conservation/old and current review versions/owner12 downstream/source guard/pipeline/rights and attachment controls;not complete suite; not a current declared-gate or ordinary-knowledge bypass; not complete suite','83 selected full classes: Unit13 binding/core/old and current schemas/owner13 downstream/source conservation/pipeline/rights/attachment controls; method count determined by fresh discovery; not complete suite')
 if n=='resources.gradle':t=t.replace("        systemProperty 'audit.unit12.capture.dir', System.getProperty('audit.unit12.capture.dir')\n",'')
 if n=='durable_monitor.py':t=t.replace('expectedMethods=462',"expectedMethods=len(json.loads((W/'DISCOVERY/RESULT.json').read_text())['tests'])")
 (W/n).write_text(t);(D/n).write_text(t)
con=json.loads((prior/'CONSERVATION.json').read_text());bindings=json.loads((prior/'APPLIED_RECORDS.json').read_text())['currentRecordHashes'];oldtests={n:sha(blob(base,n)) for n in git('ls-tree','-r','--name-only',base,'app/src/test').splitlines()};assert len(oldtests)==276
for n,h in oldtests.items():
 if n not in files:assert sha((R/n).read_bytes())==h,n
for n,h in bindings.items():assert sha((R/n).read_bytes())==h,n
for n,h in con['archives'].items():
 assert sha((R/n).read_bytes())==h
 with zipfile.ZipFile(R/n) as z:assert z.testzip() is None
prep=dict(parentCommit=base,productionTree=git('rev-parse',base+':app/src/main'),existingTestFiles=oldtests,changedComparisonFiles=files,comparisonReview=reviews,historicalPair=pair,currentRecordHashes=bindings,archives=con['archives'],plannedClasses=83,methodCount='REQUIRES_FRESH_DISCOVERY',all48Findings='OPEN',audit='INCOMPLETE',physicalAcceptance='OUTSTANDING_LAST',repositorySourceDigest='3c0acbb95297cf10f08da2bd8391463067eece22fec785158b5d2680d37dc2ba',packContentReviewDigest='15c6ae393767cb7ffc190882867bfad923c9e81b07d0f4285cf0a678f2489280')
(D/'PREPARATION.json').write_text(json.dumps(prep,indent=2)+'\n');(W/'PREPARATION.json').write_text(json.dumps(prep,indent=2)+'\n')
(D/'STATUS.md').write_text('''# Unit13 affected integration prepared\n\n83fullclasses are an inventory only; actual method count requires fresh discovery. Two older Unit12 comparison files are scoped narrowly to exact before13/genuine matching31ac kernel-reference bytes; every original assertion/pin remains in order, current runtime/mutation controls stay current. Historical planned aa93pointer was wrong (new kernel/old reference); actual matching pair proved and recorded. Original two files archived. Production/all other274testfiles/wholebaseline/coreassertions/155reconciledbindings/74archives conserved.\n\nExternal /workspace/artifacts/unit13-affected-integration-2026-10-27: inspect DISCOVERY/REGRESSION contexts/processes/completions/native-monitor status before launching or editing. One agent owns evidence collection; never duplicate a run or edit active inputs. Fresh discovery first, then actual full selected classes with compile/lint/gate. Preserve all outcomes/full failures and exact source/input trees. Four screenshot exporters16methods excluded. This scope is not a complete suite or independent acceptance.\n\nRepository source3c0acbb95297cf10f08da2bd8391463067eece22fec785158b5d2680d37dc2ba differs from packcontent15c6ae393767cb7ffc190882867bfad923c9e81b07d0f4285cf0a678f2489280; prior mislabel explicitly corrected with immutable evidence. Prior17core/2binding/1458broad scopes remain separate/unsummed. All48OPEN/auditINCOMPLETE/physicalLAST after final independent comprehensive nonphysical audit. Qualified reviews/CC024risk/CC048authority/originalUnit7restorecause outstanding. No APKassembly/install/signing/merge/freeze/formal advancement/releaseapproval. PrivatePDF unread/unpackaged/environmentunchanged/publication user-confirmed independently unobserved/JITdirective provisional/unadopted/nativecauseUNCONFIRMED.\n''')
(D/'NEXT_TASK.md').write_text('''# Complete fresh affected integration\n\nRead STATUS.md, PREPARATION.json, COMPARISON_REVIEW.json, HISTORICAL_PAIR_PROOF.json and SCOPE.json. First inspect external contexts/processes/completions and monitor before launching or changing anything. Fresh83class discovery must measure method identities; no count assumption. Run exact discovered classes against identical input trees. Root owns actual evidence verification/collection/audit-docs commit/normalpush/DraftPR64 update; preserve every failed/error outcome before any fixes. No app/test input changes during run.\n\nAfter actual completion, verify XML/events/source/commands/task/cache/lint/gate/native monitoring, all155bindings/74archives/wholebaseline/other274testfiles/originalassertions. If failures remain, inspect full messages and fix actual defects or narrowly justified historical scopes without changing original meaning/pins. Focused proofs and older scopes remain separate/unsummed. Fresh broad selected-host discovery/runtime follows resolved affected scope as next large task. All48OPEN/auditINCOMPLETE/four exporters excluded/physicalLAST/noAPK/signing/merge/freeze/releaseapproval.\n''')
rel=D.relative_to(R).as_posix()
for n in ['AGENTS.md','audit/content-corrections/CODEX_ENGINEERING_CONTINUATION.md','audit/content-corrections/CODEX_CHECKPOINT_2026-10-12.md']:
 p=R/n;link=rel+'/STATUS.md' if n=='AGENTS.md' else '../'+rel.removeprefix('audit/')+'/STATUS.md';p.write_text(f'Current checkpoint: [Unit13 affected integration prepared]({link}).83class inventory/method count requires fresh discovery;2oldUnit12comparisonfiles scoped narrowly/alloriginalassertions retained/matching31acpair proved. Production/wholebaseline/other274tests/155bindings/74archives conserved. Inspect external unit13-affected-integration-2026-10-27 contexts/processes/completions before launch/edit. Repositorydigest3c0acbb9 differs pack15c6ae39. All48OPEN/auditINCOMPLETE/four exporters excluded/physicalLAST/noAPK/signing/merge/freeze/approval.\n\n'+p.read_text())
print(json.dumps(dict(classesInventory=83,comparisons=reviews,matchingHistoricalPair=pair,otherTestsConserved=274,bindings=155,archives=74)))
