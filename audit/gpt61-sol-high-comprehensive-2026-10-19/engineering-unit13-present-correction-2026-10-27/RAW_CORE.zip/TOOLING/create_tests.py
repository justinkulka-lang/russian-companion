from pathlib import Path
R=Path('/workspace/russian-companion');T=R/'app/src/test/java/dev/russiancompanion/v2'
t=(T/'Unit12GenderFixtures.kt').read_text().replace('Unit12GenderFixtures','Unit13PresentFixtures').replace('unit12-','unit13-').replace('through: Int = 12','through: Int = 13').replace('number < 12','number < 13').replace('openCumulativeReview(pack, 12,','openCumulativeReview(pack, 13,')
t=t.replace('val pack by lazy', 'val before13 by lazy { RecordedIntakeCorrectionScope.load(root, "31ac807387253082c44bd2f6d67021478f0df66e") }\n    val pack by lazy')
t=t.replace('fun prepare(store: LocalStore, through: Int = 13)', 'fun prepare(store: LocalStore, through: Int = 13, p: V2CurriculumPack = pack)').replace('ordinary(store, number)','ordinary(store, number, p)').replace('store.openCumulativeReview(pack, number,','store.openCumulativeReview(p, number,').replace('answer(store, task, it)','answer(store, task, it, p = p)').replace('advance(store, number)','advance(store, number, p)')
t=t.replace('correct: Boolean = true)', 'correct: Boolean = true, p: V2CurriculumPack = pack)').replace('val item = pack.item(task.slots[index].itemId)!!','val item = p.item(task.slots[index].itemId)!!').replace('store.answerCumulativeReview(pack, task.id','store.answerCumulativeReview(p, task.id')
t=t[:t.index('    const val v1Capture')] + '''    const val v1Capture = "audit/independent-gpt61-2026-10-12/ia003-unit13-past-teaching/PARTIAL_REVIEW.zip"
    const val v2Capture = "audit/gpt61-sol-high-comprehensive-2026-10-19/engineering-unit13-present-baseline-2026-10-27/BASELINE_CURRENT_UNIT13_V2.zip"
}
'''
(T/'Unit13PresentFixtures.kt').write_text(t)
old=(T/'Unit12GenderCompatibilityTest.kt').read_text();head=old[:old.index('    @Test fun exactPriorDeclaration')].replace('Unit12Gender','Unit13Present').replace('Unit13PresentFixtures.v1Capture','Unit13PresentFixtures.v2Capture')
head=head.replace('import java.io.File','import java.io.File\nimport kotlinx.serialization.json.*\nimport dev.russiancompanion.v2.Unit13PresentFixtures.before13\nimport dev.russiancompanion.v2.Unit13PresentFixtures.v1Capture')
first=r'''    @Test fun exactPriorDeclarationsRefuseNewTasksAndPreserveBothUnit14OwnerBindings() {
        val old = before13
        val restored = pack.copy(units = pack.units.map { u -> if (u.number != 13) u else
            u.copy(advancement = u.advancement!!.copy(cumulativeReviewPolicyId = Unit13WiderCumulativeReviewPolicy.definition.id)) })
        assertEquals("Entire actual baseline pack differs only by Unit13 declaration", old, restored)
        val policies = (3..30).map { cumulativeReviewPolicy(it)!! }
        assertEquals(28, policies.size); assertEquals(59, policies.sumOf { it.pool.size })
        assertEquals(112, policies.sumOf { p -> p.pool.sumOf { it.candidateItemIds.size } })
        assertEquals(52, policies.flatMap { it.pool }.flatMap { it.candidateItemIds }.distinct().size)
        assertEquals(19, policies.count { p -> p.pool.any { it.candidateItemIds == listOf("u1-i-decode-pair") } })
        assertEquals(Unit13WiderCumulativeReviewPolicy.definition.pool[2], Unit12GenderCumulativeReviewPolicy.definition.pool[1])
        val observation = buildJsonObject {
            put("canonicalSourceDigest", V2Validator.contentReviewDigest(pack))
            put("unit13BeforeV2Digest", V2Validator.unitContentReviewDigest(old, 13))
            put("unit13CurrentDigest", V2Validator.unitContentReviewDigest(pack, 13))
            put("activePolicies", policies.size); put("pools", 59); put("placements", 112)
            put("uniqueCandidates", 52); put("printSingletonPolicies", 19)
            put("policies", buildJsonArray { policies.forEach { p -> add(buildJsonObject {
                put("unit", p.targetUnit); put("id", p.id); put("digest", p.digest)
                put("pools", buildJsonArray { p.pool.forEach { o -> add(buildJsonObject {
                    put("objective", o.objectiveId); put("skill", o.skill.name)
                    put("candidates", buildJsonArray { o.candidateItemIds.forEach { add(it) } })
                }) } })
            }) } })
        }
        println("UNIT13_COMPILED_OBSERVATION $observation")
        System.getProperty("audit.unit13.observation")?.let { path ->
            require(path.startsWith("/workspace/artifacts/")); check(!File(path).exists())
            File(path).writeText(observation.toString()+"\n")
        }
        for (legacy in listOf(false, true)) {
            // v2 is the genuine baseline; v1 here is an explicit declaration-only variant.
            // Separate historical-archive coverage below preserves the actual old v1 bytes.
            val producer = if (!legacy) old else old.copy(units = old.units.map { u -> if (u.number != 13) u else
                u.copy(advancement = u.advancement!!.copy(cumulativeReviewPolicyId = Unit13CumulativeReviewPolicy.definition.id)) })
            LocalStore.openInMemory(context()).use { store ->
                val original = document(v2Capture)
                assertEquals(GovernedReplaceOutcome.REPLACED, store.replaceGovernedLearner(original, emptyList()))
                val future = createCumulativeReviewAssignment(pack, store.v2LearnerView(), 13, "future-unit13", 0)!!
                assertEquals(15, future.schema); assertTrue(reviewAssignmentCurrent(pack, future))
                assertFalse(reviewAssignmentCurrent(producer, future)); assertFalse(reviewAssignmentEligible(producer, store.v2LearnerView(), future))
                if (legacy) {
                    // Complete and record a genuine schema1 assignment using supported old declaration APIs.
                    // Do not relabel the v2 capture or claim this is an older historical archive.
                    val ordinary = original.copy(reviewAssignments = original.reviewAssignments.filter { it.targetUnit != 13 },
                        reviewAnswers = original.reviewAnswers.filter { it.assignmentId != original.reviewAssignments.single { it.targetUnit == 13 }.id })
                    assertEquals(GovernedReplaceOutcome.REPLACED, store.replaceGovernedLearner(ordinary, emptyList()))
                }
                val saved = store.openCumulativeReview(producer, 13, store.learnerMutationEpoch())!!
                assertEquals(if (legacy) 1 else 6, saved.schema)
                saved.slots.indices.forEach { answer(store, saved, it, p = producer) }
                assertTrue(advance(store, 13, producer)); ordinary(store, 14, producer)
                val downstream = store.openCumulativeReview(producer, 14, store.learnerMutationEpoch())!!
                val owner = downstream.slots.single { it.ownerUnit == 13 }
                assertEquals(V2Validator.unitContentReviewDigest(producer, 13), owner.unitDigest)
                assertNotEquals(V2Validator.unitContentReviewDigest(pack, 13), owner.unitDigest)
                assertTrue(reviewAssignmentCurrent(pack, downstream)); assertTrue(reviewAssignmentEligible(pack, store.v2LearnerView(), downstream))
                val changed = pack.copy(items = pack.items.map { if (it.id == owner.itemId) it.copy(feedback = it.feedback + " changed") else it })
                assertFalse(reviewAssignmentCurrent(changed, downstream))
                val changedContent = pack.copy(items = pack.items.map { if (it.id == "u13-i-infinitive-1") it.copy(explanation = it.explanation + " changed") else it })
                assertFalse(reviewAssignmentCurrent(changedContent, downstream))
                val changedRule = pack.copy(units = pack.units.map { u -> if (u.number != 13) u else
                    u.copy(advancement = u.advancement!!.copy(minimumDistinctChecks = u.advancement.minimumDistinctChecks + 1)) })
                assertFalse(reviewAssignmentCurrent(changedRule, downstream)); assertFalse(13 in currentCompletedUnitNumbers(changedRule, store.v2LearnerView()))
                val changedTeaching = pack.copy(units = pack.units.map { u -> if (u.number != 13) u else
                    u.copy(sessions = u.sessions.map { session -> session.copy(steps = session.steps.map { step ->
                        if (step.kind == "TEACH") step.copy(body = step.body + " changed") else step }) }) })
                assertFalse(reviewAssignmentCurrent(changedTeaching, downstream))
                downstream.slots.indices.forEach { answer(store, downstream, it) }
                assertTrue(advance(store, 14)); assertTrue(14 in currentCompletedUnitNumbers(pack, store.v2LearnerView()))
            }
        }
    }

    @Test fun historicalUnit13BothVersionsAndOwner12BridgesKeepExactSavedIdentities() {
        for (path in listOf(v1Capture, v2Capture)) {
            val original = document(path);val task = original.reviewAssignments.single { it.targetUnit == 13 }
            assertEquals(if (path == v1Capture) 1 else 6, task.schema)
            assertTrue(reviewAssignmentCurrent(pack, task))
            LocalStore.openInMemory(context()).use { store ->
                assertEquals(GovernedReplaceOutcome.REPLACED, store.replaceGovernedLearner(original, emptyList()))
                assertEquals(original, store.governedLearnerDocument())
                assertEquals(task, store.cumulativeReviewHistory().first.single { it.targetUnit == 13 })
                val bad = pack.copy(items = pack.items.map { if (it.id == task.slots[1].itemId) it.copy(feedback=it.feedback+" changed") else it })
                assertFalse(reviewAssignmentCurrent(bad, task))
            }
        }
    }

'''
# Reuse full lifecycle/mutation controls with new target, retaining older tests untouched.
tail=old[old.index('    @Test fun wrongSchemasResponseTargetAndEpoch'):old.index('    @Test fun genuineSchemaOnePartial')]
tail=tail.replace('Unit12Gender','Unit13Present').replace('unit12-','unit13-').replace('assertEquals(14, task.schema)','assertEquals(15, task.schema)').replace('(1..13) + 15','(1..14) + 16').replace('schema = 14','schema = 15').replace('openCumulativeReview(pack, 12,','openCumulativeReview(pack, 13,').replace('listOf(3, 11)','listOf(4, 12, 11)').replace(', 12, "',', 13, "').replace('advance(store, 12)','advance(store, 13)').replace('(1..12).toSet()','(1..13).toSet()').replace('u3-i-gender-дверь','u4-i-verb-писать-вы').replace('pack.unit(3)!!','pack.unit(4)!!').replace('recentGenderMiss','recentPresentMiss')
legacy=r'''    @Test fun genuineV2PartialCompletesWithoutRelabellingAndHistoricalV1CanRefreshPrerequisites() {
        for (path in listOf(v2Capture, v1Capture)) {
            val original = document(path); val saved = original.reviewAssignments.single { it.targetUnit == 13 }
            val context = context(); val name = "unit13-genuine-${saved.schema}-${System.nanoTime()}"
            try {
                LocalStore.openNamed(context, name).use { store ->
                    assertEquals(GovernedReplaceOutcome.REPLACED, store.replaceGovernedLearner(original, emptyList()))
                    assertEquals(original, store.governedLearnerDocument())
                    if (path == v1Capture) prepare(store) // actual fresh work; never raw-flag old prerequisites
                    assertEquals(saved, open(store))
                    assertEquals(setOf(0), completedReviewSlots(pack, saved, store.v2LearnerView().reviewAnswers))
                    val relabelled = saved.copy(schema = 15).let { it.copy(digest = reviewAssignmentDigest(it)) }
                    assertFalse(reviewAssignmentCurrent(pack, relabelled))
                    saved.slots.indices.drop(1).forEach { answer(store, saved, it) }
                    assertTrue(advance(store, 13))
                    val current = store.governedLearnerDocument()
                    assertEquals(saved, current.reviewAssignments.single { it.id == saved.id })
                    assertEquals(original.reviewAnswers, current.reviewAnswers.take(original.reviewAnswers.size))
                    assertEquals(saved.policyDigest, current.unitCompletions.single { it.unitNumber == 13 }.reviewPolicyDigest)
                    assertEquals((1..13).toSet(), currentCompletedUnitNumbers(pack, store.v2LearnerView()))
                }
                LocalStore.openNamed(context, name).use { store ->
                    assertEquals(saved, open(store)); assertEquals((1..13).toSet(), currentCompletedUnitNumbers(pack, store.v2LearnerView()))
                }
            } finally { context.deleteDatabase(name); File(context.filesDir, "recordings-$name").deleteRecursively() }
        }
    }

    @Test fun allEightCandidatesAllocateFromGovernedMissesWhilePracticeMalformedAndDuplicateOrdersCannotSelect() {
        LocalStore.openInMemory(context()).use { store ->
            prepare(store)
            val policy = Unit13PresentCumulativeReviewPolicy.definition
            assertEquals(listOf(4,2,2), policy.pool.map { it.candidateItemIds.size })
            for ((slot, spec) in policy.pool.withIndex()) {
                val ids = spec.candidateItemIds
                val viewBefore = store.v2LearnerView()
                assertEquals(ids.first(), createCumulativeReviewAssignment(pack, viewBefore, 13, "least-$slot", 0)!!.slots[slot].itemId)
                for (id in ids) {
                    recordMiss(store,id)
                    val task = createCumulativeReviewAssignment(pack, store.v2LearnerView(),13,"miss-$id",0)!!
                    assertEquals(id, task.slots[slot].itemId)
                    val item=pack.item(id)!!;val presented=reviewPresentedOptions(item,task,slot)
                    assertEquals(item.options.toSet(),presented.toSet());assertEquals(item.options.size,presented.size)
                    assertEquals(presented,reviewPresentedOptions(item.copy(answer=item.options.first { it!=item.answer }),task,slot))
                }
                val item=pack.item(ids.first())!!
                store.v2RecordGovernedAttempt(prepareGovernedAttempt(pack,item.id,item.options.first { it!=item.answer },OPTIONAL_PRACTICE,practiceStepId("mixed"),"optional")!!)
                val view=store.v2LearnerView();val candidates=ids.map { pack.item(it)!! }
                assertEquals(ids.last(),createCumulativeReviewAssignment(pack,view,13,"ignore-optional-$slot",0)!!.slots[slot].itemId)
                assertEquals(ids.first(),recentReviewCandidate(pack,view.copy(governedAttempts=view.governedAttempts!!.map { it.copy(itemDigest="0".repeat(64)) }),candidates)!!.id)
                assertEquals(ids.first(),recentReviewCandidate(pack,view.copy(governedAttempts=view.governedAttempts!!.map { it.copy(acceptedOrder=1) }),candidates)!!.id)
            }
        }
    }
    private fun recordMiss(store: LocalStore, id: String) {
        val item=pack.item(id)!!;val step=pack.units.flatMap { it.sessions }.flatMap { it.steps }.single { it.kind=="CHECK" && id in it.itemIds }
        store.v2RecordGovernedAttempt(prepareGovernedAttempt(pack,id,item.options.first { it!=item.answer },PRESCRIBED_CHECK,step.id,"unit13-miss")!!)
    }
}
'''
(T/'Unit13PresentCompatibilityTest.kt').write_text(head+first+tail+legacy)
# Full app repair flows adapted as new tests; all existing UI files remain unchanged.
u=(T/'Unit12GenderReviewUiTest.kt').read_text().replace('Unit12Gender','Unit13Present').replace('unit12-','unit13-')
u=u.replace('Unit13PresentFixtures.v1Capture','Unit13PresentFixtures.v1Capture\nimport dev.russiancompanion.v2.Unit13PresentFixtures.v2Capture')
u=u.replace('store.v2LearnerView(), 12,','store.v2LearnerView(), 13,').replace('it.targetUnit == 12','it.targetUnit == 13').replace('it.unitNumber == 12','it.unitNumber == 13').replace('currentUnitNumber = 12','currentUnitNumber = 13').replace('assertEquals(13, store.v2Profile().currentUnitNumber)','assertEquals(14, store.v2Profile().currentUnitNumber)').replace('assertEquals(14, task.schema)','assertEquals(15, task.schema)').replace('assertEquals(2, task.slots.size)','assertEquals(3, task.slots.size)').replace('"0 of 2 review checks recorded"','"0 of 3 review checks recorded"')
u=u.replace('unpreparedReviewStatesFiniteScopeAndRoutesToBothRealOwnersWithoutCredit','unpreparedReviewStatesFiniteScopeAndRoutesToAllThreeRealOwnersWithoutCredit').replace('Open earlier Unit 3 instruction','Open earlier Unit 4 instruction').replace('assertEquals(3, requested)','assertEquals(4, requested)')
u=u.replace('            compose.onNodeWithTag("v2-review-repair-11")','            compose.onNodeWithTag("v2-review-repair-12").performScrollTo().assertTextEquals("Open earlier Unit 12 instruction and checks").performClick()\n            assertEquals(12, requested)\n            compose.onNodeWithTag("v2-review-repair-11")',1)
u=u.replace('freshUnitDetailEntryAndUnstartedScreenUseTheDeclaredGenderPolicy','freshUnitDetailEntryAndUnstartedScreenUseTheDeclaredPresentPolicy')
u=u.replace('actualFreshReviewRepairsNounGenderTeachingWithoutPracticeCreditAndAdvances','actualFreshReviewRepairsPresentTeachingWithoutPracticeCreditAndAdvances').replace('freshRepair(0, 3, "u3-i-gender-дверь", "u3-st-rem-gender", 5, 16)','freshRepair(0, 4, "u4-i-verb-писать-вы", "u4-st-rem-present", 11, 6)\n\n    @Test fun actualFreshReviewRepairsAspectTeachingWithoutPracticeCreditAndAdvances() =\n        freshRepair(1, 12, "u12-i-aspect-2", "u12-st-rem-aspect", 3, 4)').replace('freshRepair(1, 11,','freshRepair(2, 11,')
u=u.replace('"Review noun genders and supplied past agreement"','"Review supplied present forms, aspect partners and past agreement"').replace('Review earlier reading and supplied past gender','Review earlier reading, supplied aspect partners and past agreement')
u=u.replace('legacyEntry(v1Capture, false, 2)','legacyEntry(v1Capture, true, 2)\n    }\n\n    @Test fun genuineSchemaSixEntryContinueAndReviewKeepTheirOwnPartialMeaning() {\n        legacyEntry(v2Capture, false, 3)')
u=u.replace('genuinelyCompletedUnit3RoutesMissingUnit11WithoutCreatingReviewCredit','genuinelyCompletedUnit4RoutesMissingUnit12And11WithoutCreatingReviewCredit').replace('prepare(store, 3)','prepare(store, 4)').replace('assertTrue(3 in','assertTrue(4 in')
# In the prepared-owner case missing owners retain pool order12 then11.
needle='compose.onNodeWithTag("v2-review-repair").performScrollTo().assertTextEquals("Open earlier Unit 11 instruction and checks").performClick()'
u=u.replace(needle,'compose.onNodeWithTag("v2-review-repair").performScrollTo().assertTextEquals("Open earlier Unit 12 instruction and checks").performClick()\n            assertEquals(12, requested)\n            compose.onNodeWithTag("v2-review-repair-11").performScrollTo().assertTextEquals("Open earlier Unit 11 instruction and checks").performClick()')
(T/'Unit13PresentReviewUiTest.kt').write_text(u)
print('New fixtures plus7compatibility/8UI methods; existing baseline2methods retained unchanged.')
