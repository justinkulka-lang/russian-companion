from pathlib import Path
R=Path('/workspace/russian-companion');p=R/'app/src/main/java/dev/russiancompanion/v2/curriculum/V2CumulativeReview.kt';t=p.read_text()
def change(a,b):
 global t
 assert t.count(a)==1,(a,t.count(a));t=t.replace(a,b)
change('internal const val CUMULATIVE_REVIEW_ROLE', '// Fresh Unit13 supplied-present/aspect/past v3 only; schemas1-14 stay immutable.\ninternal const val UNIT13_PRESENT_REVIEW_ASSIGNMENT_SCHEMA = 15\ninternal const val CUMULATIVE_REVIEW_ROLE')
change('/** Recorded noun labels and supplied singular past forms; not productive agreement. */', '''/** Reuses finite taught present forms, lexical aspect partners and past-gender forms. */
internal object Unit13PresentCumulativeReviewPolicy {
    val definition = CumulativeReviewPolicy("unit13-prior-present-aspect-past-gender-v3", 13, listOf(
        Unit6PresentCumulativeReviewPolicy.definition.pool[0],
        Unit13CumulativeReviewPolicy.definition.pool[1].copy(
            candidateItemIds = listOf("u12-i-aspect-1", "u12-i-aspect-2")),
        Unit13WiderCumulativeReviewPolicy.definition.pool[2],
    ))
}

/** Recorded noun labels and supplied singular past forms; not productive agreement. */''')
change('    13 -> Unit13WiderCumulativeReviewPolicy.definition','    13 -> Unit13PresentCumulativeReviewPolicy.definition')
change('    13 -> "Review earlier reading, supplied aspect partners and past agreement"','    13 -> if (policyId == Unit13PresentCumulativeReviewPolicy.definition.id)\n        "Review supplied present forms, aspect partners and past agreement"\n        else "Review earlier reading, supplied aspect partners and past agreement"')
change('        targetUnit == 13 && rule.cumulativeReviewPolicyId == Unit13CumulativeReviewPolicy.definition.id ->','        targetUnit == 13 && rule.cumulativeReviewPolicyId == Unit13WiderCumulativeReviewPolicy.definition.id ->\n            Unit13WiderCumulativeReviewPolicy.definition\n        targetUnit == 13 && rule.cumulativeReviewPolicyId == Unit13CumulativeReviewPolicy.definition.id ->')
change('    13 -> if (policy.id == Unit13WiderCumulativeReviewPolicy.definition.id) UNIT13_WIDER_REVIEW_ASSIGNMENT_SCHEMA\n        else CUMULATIVE_REVIEW_SCHEMA','    13 -> when (policy.id) {\n        Unit13PresentCumulativeReviewPolicy.definition.id -> UNIT13_PRESENT_REVIEW_ASSIGNMENT_SCHEMA\n        Unit13WiderCumulativeReviewPolicy.definition.id -> UNIT13_WIDER_REVIEW_ASSIGNMENT_SCHEMA\n        else -> CUMULATIVE_REVIEW_SCHEMA\n    }')
change('        a.policyId != Unit13WiderCumulativeReviewPolicy.definition.id\n','        a.policyId != Unit13WiderCumulativeReviewPolicy.definition.id &&\n        a.policyId != Unit13PresentCumulativeReviewPolicy.definition.id\n')
change('    else -> false\n}\n\n/** Explicit history registry', '    UNIT13_PRESENT_REVIEW_ASSIGNMENT_SCHEMA -> a.targetUnit == 13 &&\n        a.policyId == Unit13PresentCumulativeReviewPolicy.definition.id\n    else -> false\n}\n\n/** Explicit history registry')
change('            13 -> listOf(Unit13CumulativeReviewPolicy.definition)','            13 -> listOf(Unit13CumulativeReviewPolicy.definition, Unit13WiderCumulativeReviewPolicy.definition)')
change('        !(a.targetUnit == 13 && declared.id == Unit13WiderCumulativeReviewPolicy.definition.id &&\n            policy.id == Unit13CumulativeReviewPolicy.definition.id)) return false','        !(a.targetUnit == 13 && (\n            declared.id == Unit13WiderCumulativeReviewPolicy.definition.id && policy.id == Unit13CumulativeReviewPolicy.definition.id ||\n            declared.id == Unit13PresentCumulativeReviewPolicy.definition.id && policy.id in setOf(\n                Unit13CumulativeReviewPolicy.definition.id, Unit13WiderCumulativeReviewPolicy.definition.id)))) return false')
change('        13 -> cumulativeReviewDeclarationValid(pack, 13) && recorded == priorActiveUnit13Digest(pack)','        13 -> cumulativeReviewDeclarationValid(pack, 13) && recorded in priorActiveUnit13Digests(pack)')
change('''private val priorActiveUnit13Digests = IdentityWeakCache<String>()
private fun priorActiveUnit13Digest(pack: V2CurriculumPack): String = priorActiveUnit13Digests.get(pack) ?: run {
    val old = pack.copy(units = pack.units.map { unit -> if (unit.number == 13) unit.copy(
        advancement = unit.advancement!!.copy(requireDueReview = true,
            cumulativeReviewPolicyId = Unit13CumulativeReviewPolicy.definition.id)) else unit })
    V2Validator.unitContentReviewDigest(old, 13).also { priorActiveUnit13Digests.put(pack, it) }
}''','''private val priorActiveUnit13DigestCache = IdentityWeakCache<Set<String>>()
private fun priorActiveUnit13Digests(pack: V2CurriculumPack): Set<String> = priorActiveUnit13DigestCache.get(pack) ?: run {
    // Restore only earlier declarations against all CURRENT content/teaching/rule fields.
    // A recorded historical hash alone never authorizes unrelated content changes.
    val ids = listOf(Unit13CumulativeReviewPolicy.definition.id) +
        if (pack.unit(13)?.advancement?.cumulativeReviewPolicyId == Unit13PresentCumulativeReviewPolicy.definition.id)
            listOf(Unit13WiderCumulativeReviewPolicy.definition.id) else emptyList()
    ids.map { policyId ->
        val old = pack.copy(units = pack.units.map { unit -> if (unit.number == 13) unit.copy(
            advancement = unit.advancement!!.copy(requireDueReview = true, cumulativeReviewPolicyId = policyId)) else unit })
        V2Validator.unitContentReviewDigest(old, 13)
    }.toSet().also { priorActiveUnit13DigestCache.put(pack, it) }
}''')
p.write_text(t)
p=R/'app/src/main/java/dev/russiancompanion/v2/ui/V2CumulativeReviewScreen.kt';t=p.read_text();old='            13 -> if ((state?.assignment?.policyId ?: declaredPolicy?.id) == Unit13CumulativeReviewPolicy.definition.id)';assert t.count(old)==1
t=t.replace(old,'''            13 -> if ((state?.assignment?.policyId ?: declaredPolicy?.id) == Unit13PresentCumulativeReviewPolicy.definition.id)
                "Review supplied present forms for person cues from Unit 4, saying/telling or doing/making aspect partners from Unit 12 and singular past-gender forms from Unit 11. Repairs restore the full taught form sets; guided practice does not complete any fresh review check. Complete one assigned answer from each of the three pools. These finite recognitions do not demonstrate unseen reading, productive conjugation, sentence-context aspect selection, speaking or writing."
            else if ((state?.assignment?.policyId ?: declaredPolicy?.id) == Unit13CumulativeReviewPolicy.definition.id)''');p.write_text(t)
p=R/'app/src/main/assets/content/v2-curriculum.json';b=p.read_bytes();old=b'unit13-prior-reading-aspect-past-gender-v2';assert b.count(old)==1;p.write_bytes(b.replace(old,b'unit13-prior-present-aspect-past-gender-v3'))
print('New separate Unit13 policy/schema15, directional history and exact prior-content owner13 bridge applied; old objects unchanged.')
