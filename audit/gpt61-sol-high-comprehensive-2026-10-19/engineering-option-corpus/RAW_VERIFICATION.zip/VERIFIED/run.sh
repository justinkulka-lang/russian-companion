source /workspace/setup/android-env.sh
./gradlew -I /workspace/setup/cloud-validation.gradle -I /workspace/russian-companion/audit/independent-gpt61-2026-10-12/broader-regression-2026-10-18/broader-tests.gradle -Daudit.events.path=/workspace/artifacts/post-correction-broad-2026-10-20/option-corpus/VERIFIED/EVENTS.jsonl testDebugUnitTest --tests dev.russiancompanion.v2.OptionPresentationTest --tests dev.russiancompanion.v2.OptionPresentationUiTest --tests dev.russiancompanion.v2.Unit8ExistenceSequenceTest --tests dev.russiancompanion.v2.Unit8ExistenceUiTest --rerun compileDebugSources lintDebug verifyReleaseGateAttachment --continue --offline --max-workers=4 --console=plain > /workspace/artifacts/post-correction-broad-2026-10-20/option-corpus/VERIFIED/RUN.log 2>&1
result=$?
printf "%s\n" "$result" > /workspace/artifacts/post-correction-broad-2026-10-20/option-corpus/VERIFIED/RUN.exit
exit "$result"
