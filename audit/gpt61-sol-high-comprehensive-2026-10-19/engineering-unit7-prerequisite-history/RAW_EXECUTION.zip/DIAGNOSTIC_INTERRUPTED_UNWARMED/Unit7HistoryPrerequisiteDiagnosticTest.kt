package dev.russiancompanion.v2

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import dev.russiancompanion.RussianCompanionApplication
import dev.russiancompanion.data.local.LocalStore
import dev.russiancompanion.v2.backup.*
import dev.russiancompanion.v2.curriculum.*
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.json.*
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [33])
class Unit7HistoryPrerequisiteDiagnosticTest {
    @Test fun actualUnit4BoundaryAndCurrentRepairExplainUnit7ReviewRefusal() {
        val root = File(if (File("app").isDirectory) "." else "..")
        fun at(commit: String): V2CurriculumPack {
            val p = ProcessBuilder("git", "show", "$commit:app/src/main/assets/content/v2-curriculum.json").directory(root).start()
            return V2PackLoader.parse(p.inputStream.bufferedReader().readText()).also {
                assertEquals(0, p.waitFor()); V2PackIdentityIndex.warm(it)
            }
        }
        val current = V2PackLoader.parse(File(root, "app/src/main/assets/content/v2-curriculum.json").readText())
        val before = at("b5e1daf50ac8597d00aeb6976f894d3ce44c03ca")
        val after = at("e6db0bdfe0bbb40edf190623e2123014946f305b")
        assertEquals(after.unit(4), current.unit(4))
        assertEquals(V2Validator.unitContentReviewDigest(after, 4), V2Validator.unitContentReviewDigest(current, 4))
        val original = backupJson.decodeFromString(GovernedLearnerDocument.serializer(),
            File(root, "audit/independent-gpt61-2026-10-12/ia003-unit7-agreement-teaching/COMPLETED_UNIT8.json").readText())
        val context: Context = ApplicationProvider.getApplicationContext()
        (context.applicationContext as RussianCompanionApplication).closeStartupStoreForTests()
        LocalStore.openInMemory(context).use { store ->
            store.openLearnerReplacement()
            try { assertEquals(GovernedReplaceOutcome.REPLACED, store.replaceGovernedLearner(original, emptyList())) }
            finally { store.closeLearnerReplacement() }
            val snapshots = buildJsonObject {
                for ((label, p) in listOf("BEFORE_UNIT4" to before, "AFTER_UNIT4" to after, "CURRENT" to current)) {
                    put(label, buildJsonObject {
                        put("completed", JsonArray(currentCompletedUnitNumbers(p, store.v2LearnerView()).sorted().map { JsonPrimitive(it) }))
                        put("unit4OrdinaryMissing", JsonArray(ordinaryUnitRequirements(p,p.unit(4)!!,store.v2LearnerView()).remaining.map { JsonPrimitive(it) }))
                        put("unit7UnmetPrerequisites", JsonArray(unmetCurrentPrerequisites(p,p.unit(7)!!,store.v2LearnerView()).map { JsonPrimitive(it) }))
                    })
                }
            }
            println("UNIT7_DIAGNOSTIC_INITIAL=$snapshots")
            assertEquals((1..6).toSet(), currentCompletedUnitNumbers(before, store.v2LearnerView()))
            assertEquals((1..3).toSet(), currentCompletedUnitNumbers(after, store.v2LearnerView()))
            assertEquals((1..3).toSet(), currentCompletedUnitNumbers(current, store.v2LearnerView()))
            assertEquals(original, store.governedLearnerDocument())
            ordinary(current,store,7)
            assertTrue(ordinaryUnitRequirements(current,current.unit(7)!!,store.v2LearnerView()).allowed)
            assertEquals(listOf(6),unmetCurrentPrerequisites(current,current.unit(7)!!,store.v2LearnerView()))
            val beforeRefusal=store.governedLearnerDocument()
            assertNull(store.openCumulativeReview(current,7,store.learnerMutationEpoch()))
            assertEquals(beforeRefusal,store.governedLearnerDocument())
            for (number in 4..8) {
                ordinary(current,store,number)
                val assignment=store.openCumulativeReview(current,number,store.learnerMutationEpoch())
                assertNotNull("Review unavailable for Unit $number: ${advancementDecision(current,current.unit(number)!!,store.v2LearnerView()).remaining}",assignment)
                val a=assignment!!
                a.slots.indices.forEach { index -> assertTrue(store.answerCumulativeReview(current,a.id,index,current.item(a.slots[index].itemId)!!.answer,store.learnerMutationEpoch())) }
                assertTrue(runBlocking {
                    val next=current.unit(number+1)!!.sessions.first().id
                    store.v2AdvanceUnitIfCurrentAsync(store.learnerMutationEpoch(),number,"diagnostic",number+1,next,resumePositionDigest(current,next,0)!!,GOVERNED_IDENTITY_SCHEMA,current)
                })
                assertEquals((1..number).toSet(),currentCompletedUnitNumbers(current,store.v2LearnerView()))
                val document=store.governedLearnerDocument()
                assertEquals(original.attempts,document.attempts.take(original.attempts.size))
                assertTrue(document.reviewAssignments.containsAll(original.reviewAssignments))
                assertTrue(document.reviewAnswers.containsAll(original.reviewAnswers))
                println("UNIT7_DIAGNOSTIC_REPAIRED=$number;schema=${a.schema};reused=${a in original.reviewAssignments}")
            }
        }
    }
    private fun ordinary(p:V2CurriculumPack,s:LocalStore,number:Int) {
        s.v2SaveProfile(s.v2Profile().copy(onboardingCompleted=true,currentUnitNumber=number,currentSessionId=null))
        p.unit(number)!!.sessions.flatMap { it.steps }.forEach { step ->
            step.itemIds.forEach { id -> s.v2RecordGovernedAttempt(prepareGovernedAttempt(p,id,p.item(id)!!.answer,PRESCRIBED_CHECK,step.id,"diagnostic")!!) }
            s.v2CompleteGovernedStep(step.id,governedStepCompletionDigest(p,s.v2LearnerView(),step.id)!!,"diagnostic")
        }
        s.v2AttestBook(number,"diagnostic")
    }
}
