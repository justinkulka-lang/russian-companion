# Curriculum design diagnostics

Verdict: NEEDS_CORRECTION_OR_REVIEW. This is not curriculum or release acceptance.

Raw input SHA256: `02202d37e0aa2c51182e4db22feff177124b6db2c270a67a93ef85e188916c19` (20350052 bytes).

Structural errors: 37; review signals: 426.

| Rule | Signals |
| --- | ---: |
| ANSWER_IN_INSTRUCTION_SIGNAL | 59 |
| CONSTANT_REQUIRED_KEY | 9 |
| CUE_AS_DISTRACTOR | 42 |
| FEWER_THAN_THREE_OPTIONS | 208 |
| IDENTICAL_REQUIRED_DISPLAY_TASK | 13 |
| LEARNER_MARKUP | 37 |
| NO_CYRILLIC_IN_REQUIRED_DISPLAY | 11 |
| REMEDIATION_TRANSFER_OR_GAP | 77 |
| TEACHING_TRANSFER_OR_GAP | 7 |

- Review signals are not confirmed linguistic or pedagogical defects.
- Lexical absence may be legitimate transfer; lexical presence does not prove adequate teaching.
- Authored key positions do not establish displayed positions after runtime permutation.
- This report neither replaces runtime validation nor grants review, rights or release approval.

## Located signals

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u12-i-aspect-2 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u12-st-teach-aspect-3

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u13-i-infinitive-1 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u13-st-teach-infinitive-3

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u13-i-infinitive-2 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u13-st-teach-infinitive-3

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u16-i-complements-1 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u16-st-teach-complements-1

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u16-i-complements-2 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u16-st-teach-complements-3

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u16-i-inst-adj-1 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u16-st-teach-inst-adj-4

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u16-i-inst-adj-2 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u16-st-teach-inst-adj-3, u16-st-teach-inst-adj-4

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u16-i-inst-pl-1 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u16-st-teach-inst-pl-4

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u16-i-inst-pl-2 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u16-st-teach-inst-pl-6

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u16-i-inst-sg-1 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u16-st-teach-inst-sg-4

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u17-i-age-2 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u17-st-teach-age-2

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u17-i-hours-1 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u17-st-teach-hours-3

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u17-i-hours-2 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u17-st-teach-hours-3

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u17-i-minutes-1 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u17-st-teach-minutes-3

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u17-i-minutes-2 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u17-st-teach-minutes-3

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u17-i-months-1 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u17-st-teach-months-3

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u17-i-months-2 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u17-st-teach-months-3

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u17-i-ordinals-1 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u17-st-teach-ordinals-3

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u17-i-ordinals-2 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u17-st-teach-ordinals-3

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u17-i-weekdays-1 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u17-st-teach-weekdays-3

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u17-i-weekdays-2 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u17-st-teach-weekdays-3

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u17-i-years-1 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u17-st-teach-years-3

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u17-i-years-2 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u17-st-teach-years-3

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u18-i-comparison-1 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u18-st-teach-comparison-3

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u18-i-comparison-2 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u18-st-teach-comparison-3

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u19-i-conditional-1 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u19-st-teach-conditional-2

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u19-i-prefix-caution-2 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u19-st-teach-prefix-caution-2

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u20-i-motion-2 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u20-st-teach-motion-3

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u24-i-concord-1 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u24-st-teach-concord-2

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u24-i-concord-2 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u24-st-teach-concord-2

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u26-i-address-notation-1 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u26-st-teach-address-notation-2

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u26-i-correspondence-1 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u26-st-teach-correspondence-2

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u26-i-correspondence-2 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u26-st-teach-correspondence-2

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u26-i-vy-capital-1 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u26-st-teach-vy-capital-1

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u26-i-vy-capital-2 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u26-st-teach-vy-capital-1

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u28-i-perfective-adverb-1 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u28-st-teach-perfective-adverb-2

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u28-i-readings-1 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u28-st-teach-readings-2

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u29-i-active-1 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u29-st-teach-active-2

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u29-i-active-2 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u29-st-teach-active-2

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u30-i-address-marks-1 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u30-st-teach-address-marks-3

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u30-i-address-marks-2 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u30-st-teach-address-marks-3

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u4-i-verb-видеть-он (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u4-st-teach-present-видеть

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u4-i-verb-говорить-мы (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u4-st-teach-present-говорить

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u4-i-verb-идти-они (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u4-st-teach-present-идти

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u4-i-verb-писать-вы (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u4-st-teach-present-писать

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u6-i-possessive-1 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u6-st-teach-possessive-4

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u6-i-possessive-3 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u6-st-teach-possessive-6

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u7-i-endings-1 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u7-st-teach-endings-2

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u7-i-endings-2 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u7-st-teach-endings-5

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u7-i-endings-3 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u7-st-teach-endings-2, u7-st-teach-endings-5

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u7-i-endings-4 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u7-st-teach-endings-5

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u7-i-spelling-1 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u7-st-teach-spelling-4

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u7-i-spelling-2 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u7-st-teach-spelling-4

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u8-i-spelling-1 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u8-st-teach-spelling-3

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u8-i-spelling-2 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u8-st-teach-spelling-5

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u8-i-spelling-3 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u8-st-teach-spelling-5

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u8-i-spelling-4 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u8-st-teach-spelling-5

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u9-i-odindva-1 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u9-st-teach-odindva-6

- REVIEW_SIGNAL / ANSWER_IN_INSTRUCTION_SIGNAL: u9-i-odindva-4 (instruction). An instruction sentence names the key and an answer-selection phrase. A human must distinguish answer scripts from legitimate rules/examples.
  Steps: u9-st-teach-odindva-6

- REVIEW_SIGNAL / CONSTANT_REQUIRED_KEY: obj-u11-past-be, u11-i-past-be-1, u11-i-past-be-2 (answer). Every required check has the same key. Review shortcut strategies and the objective's actual construct.

- REVIEW_SIGNAL / CONSTANT_REQUIRED_KEY: obj-u15-imperative, u15-i-imperative-1, u15-i-imperative-2 (answer). Every required check has the same key. Review shortcut strategies and the objective's actual construct.

- REVIEW_SIGNAL / CONSTANT_REQUIRED_KEY: obj-u24-concord, u24-i-concord-1, u24-i-concord-2 (answer). Every required check has the same key. Review shortcut strategies and the objective's actual construct.

- REVIEW_SIGNAL / CONSTANT_REQUIRED_KEY: obj-u24-placement, u24-i-placement-1, u24-i-placement-2 (answer). Every required check has the same key. Review shortcut strategies and the objective's actual construct.

- REVIEW_SIGNAL / CONSTANT_REQUIRED_KEY: obj-u25-name-question, u25-i-name-question-1, u25-i-name-question-2 (answer). Every required check has the same key. Review shortcut strategies and the objective's actual construct.

- REVIEW_SIGNAL / CONSTANT_REQUIRED_KEY: obj-u26-vy-capital, u26-i-vy-capital-1, u26-i-vy-capital-2 (answer). Every required check has the same key. Review shortcut strategies and the objective's actual construct.

- REVIEW_SIGNAL / CONSTANT_REQUIRED_KEY: obj-u29-active, u29-i-active-1, u29-i-active-2 (answer). Every required check has the same key. Review shortcut strategies and the objective's actual construct.

- REVIEW_SIGNAL / CONSTANT_REQUIRED_KEY: obj-u4-nominative, u4-i-nom-role-student, u4-i-nom-role-train (answer). Every required check has the same key. Review shortcut strategies and the objective's actual construct.

- REVIEW_SIGNAL / CONSTANT_REQUIRED_KEY: obj-u7-adverb-invariance, u7-i-adverb-invariance-1, u7-i-adverb-invariance-2 (answer). Every required check has the same key. Review shortcut strategies and the objective's actual construct.

- REVIEW_SIGNAL / CUE_AS_DISTRACTOR: u10-i-animate-1 (options). A distractor exactly repeats the visible cue. Inspect whether rejecting the cue alone gives away the answer.

- REVIEW_SIGNAL / CUE_AS_DISTRACTOR: u10-i-animate-2 (options). A distractor exactly repeats the visible cue. Inspect whether rejecting the cue alone gives away the answer.

- REVIEW_SIGNAL / CUE_AS_DISTRACTOR: u10-i-animate-3 (options). A distractor exactly repeats the visible cue. Inspect whether rejecting the cue alone gives away the answer.

- REVIEW_SIGNAL / CUE_AS_DISTRACTOR: u10-i-preposition-1 (options). A distractor exactly repeats the visible cue. Inspect whether rejecting the cue alone gives away the answer.

- REVIEW_SIGNAL / CUE_AS_DISTRACTOR: u10-i-preposition-2 (options). A distractor exactly repeats the visible cue. Inspect whether rejecting the cue alone gives away the answer.

- REVIEW_SIGNAL / CUE_AS_DISTRACTOR: u10-i-preposition-4 (options). A distractor exactly repeats the visible cue. Inspect whether rejecting the cue alone gives away the answer.

- REVIEW_SIGNAL / CUE_AS_DISTRACTOR: u22-i-compounds-1 (options). A distractor exactly repeats the visible cue. Inspect whether rejecting the cue alone gives away the answer.

- REVIEW_SIGNAL / CUE_AS_DISTRACTOR: u22-i-compounds-2 (options). A distractor exactly repeats the visible cue. Inspect whether rejecting the cue alone gives away the answer.

- REVIEW_SIGNAL / CUE_AS_DISTRACTOR: u6-i-animacy-1 (options). A distractor exactly repeats the visible cue. Inspect whether rejecting the cue alone gives away the answer.

- REVIEW_SIGNAL / CUE_AS_DISTRACTOR: u6-i-animacy-2 (options). A distractor exactly repeats the visible cue. Inspect whether rejecting the cue alone gives away the answer.

- REVIEW_SIGNAL / CUE_AS_DISTRACTOR: u6-i-feminine-1 (options). A distractor exactly repeats the visible cue. Inspect whether rejecting the cue alone gives away the answer.

- REVIEW_SIGNAL / CUE_AS_DISTRACTOR: u6-i-feminine-2 (options). A distractor exactly repeats the visible cue. Inspect whether rejecting the cue alone gives away the answer.

- REVIEW_SIGNAL / CUE_AS_DISTRACTOR: u6-i-object-1 (options). A distractor exactly repeats the visible cue. Inspect whether rejecting the cue alone gives away the answer.

- REVIEW_SIGNAL / CUE_AS_DISTRACTOR: u6-i-object-2 (options). A distractor exactly repeats the visible cue. Inspect whether rejecting the cue alone gives away the answer.

- REVIEW_SIGNAL / CUE_AS_DISTRACTOR: u6-i-object-3 (options). A distractor exactly repeats the visible cue. Inspect whether rejecting the cue alone gives away the answer.

- REVIEW_SIGNAL / CUE_AS_DISTRACTOR: u6-i-possessive-3 (options). A distractor exactly repeats the visible cue. Inspect whether rejecting the cue alone gives away the answer.

- REVIEW_SIGNAL / CUE_AS_DISTRACTOR: u7-i-default-1 (options). A distractor exactly repeats the visible cue. Inspect whether rejecting the cue alone gives away the answer.

- REVIEW_SIGNAL / CUE_AS_DISTRACTOR: u7-i-default-2 (options). A distractor exactly repeats the visible cue. Inspect whether rejecting the cue alone gives away the answer.

- REVIEW_SIGNAL / CUE_AS_DISTRACTOR: u7-i-default-3 (options). A distractor exactly repeats the visible cue. Inspect whether rejecting the cue alone gives away the answer.

- REVIEW_SIGNAL / CUE_AS_DISTRACTOR: u7-i-default-4 (options). A distractor exactly repeats the visible cue. Inspect whether rejecting the cue alone gives away the answer.

- REVIEW_SIGNAL / CUE_AS_DISTRACTOR: u7-i-demonstrative-1 (options). A distractor exactly repeats the visible cue. Inspect whether rejecting the cue alone gives away the answer.

- REVIEW_SIGNAL / CUE_AS_DISTRACTOR: u7-i-demonstrative-2 (options). A distractor exactly repeats the visible cue. Inspect whether rejecting the cue alone gives away the answer.

- REVIEW_SIGNAL / CUE_AS_DISTRACTOR: u7-i-demonstrative-3 (options). A distractor exactly repeats the visible cue. Inspect whether rejecting the cue alone gives away the answer.

- REVIEW_SIGNAL / CUE_AS_DISTRACTOR: u7-i-place-2 (options). A distractor exactly repeats the visible cue. Inspect whether rejecting the cue alone gives away the answer.

- REVIEW_SIGNAL / CUE_AS_DISTRACTOR: u7-i-place-3 (options). A distractor exactly repeats the visible cue. Inspect whether rejecting the cue alone gives away the answer.

- REVIEW_SIGNAL / CUE_AS_DISTRACTOR: u7-i-question-1 (options). A distractor exactly repeats the visible cue. Inspect whether rejecting the cue alone gives away the answer.

- REVIEW_SIGNAL / CUE_AS_DISTRACTOR: u7-i-spelling-1 (options). A distractor exactly repeats the visible cue. Inspect whether rejecting the cue alone gives away the answer.

- REVIEW_SIGNAL / CUE_AS_DISTRACTOR: u8-i-agreement-1 (options). A distractor exactly repeats the visible cue. Inspect whether rejecting the cue alone gives away the answer.

- REVIEW_SIGNAL / CUE_AS_DISTRACTOR: u8-i-agreement-2 (options). A distractor exactly repeats the visible cue. Inspect whether rejecting the cue alone gives away the answer.

- REVIEW_SIGNAL / CUE_AS_DISTRACTOR: u8-i-agreement-3 (options). A distractor exactly repeats the visible cue. Inspect whether rejecting the cue alone gives away the answer.

- REVIEW_SIGNAL / CUE_AS_DISTRACTOR: u8-i-irregular-1 (options). A distractor exactly repeats the visible cue. Inspect whether rejecting the cue alone gives away the answer.

- REVIEW_SIGNAL / CUE_AS_DISTRACTOR: u8-i-irregular-2 (options). A distractor exactly repeats the visible cue. Inspect whether rejecting the cue alone gives away the answer.

- REVIEW_SIGNAL / CUE_AS_DISTRACTOR: u8-i-irregular-3 (options). A distractor exactly repeats the visible cue. Inspect whether rejecting the cue alone gives away the answer.

- REVIEW_SIGNAL / CUE_AS_DISTRACTOR: u8-i-plural-1 (options). A distractor exactly repeats the visible cue. Inspect whether rejecting the cue alone gives away the answer.

- REVIEW_SIGNAL / CUE_AS_DISTRACTOR: u8-i-plural-2 (options). A distractor exactly repeats the visible cue. Inspect whether rejecting the cue alone gives away the answer.

- REVIEW_SIGNAL / CUE_AS_DISTRACTOR: u8-i-plural-3 (options). A distractor exactly repeats the visible cue. Inspect whether rejecting the cue alone gives away the answer.

- REVIEW_SIGNAL / CUE_AS_DISTRACTOR: u8-i-plural-4 (options). A distractor exactly repeats the visible cue. Inspect whether rejecting the cue alone gives away the answer.

- REVIEW_SIGNAL / CUE_AS_DISTRACTOR: u8-i-plural-5 (options). A distractor exactly repeats the visible cue. Inspect whether rejecting the cue alone gives away the answer.

- REVIEW_SIGNAL / CUE_AS_DISTRACTOR: u8-i-plural-6 (options). A distractor exactly repeats the visible cue. Inspect whether rejecting the cue alone gives away the answer.

- REVIEW_SIGNAL / CUE_AS_DISTRACTOR: u8-i-spelling-1 (options). A distractor exactly repeats the visible cue. Inspect whether rejecting the cue alone gives away the answer.

- REVIEW_SIGNAL / CUE_AS_DISTRACTOR: u8-i-spelling-2 (options). A distractor exactly repeats the visible cue. Inspect whether rejecting the cue alone gives away the answer.

- REVIEW_SIGNAL / CUE_AS_DISTRACTOR: u8-i-spelling-3 (options). A distractor exactly repeats the visible cue. Inspect whether rejecting the cue alone gives away the answer.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u10-i-absence-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u10-i-absence-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u10-i-absence-3 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u10-i-absence-4 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u10-i-adjective-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u10-i-adjective-3 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u10-i-animate-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u10-i-animate-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u10-i-animate-3 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u10-i-have-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u10-i-have-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u10-i-have-3 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u10-i-have-4 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u10-i-preposition-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u10-i-preposition-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u10-i-preposition-3 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u10-i-pronoun-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u10-i-pronoun-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u10-i-pronoun-3 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u10-i-pronoun-4 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u11-i-past-aspect-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u11-i-past-aspect-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u11-i-past-be-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u11-i-past-be-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u11-i-past-read-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u11-i-past-read-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u11-i-reflexive-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u11-i-reflexive-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u12-i-aspect-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u12-i-aspect-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u12-i-dative-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u12-i-dative-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u12-i-future-imp-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u12-i-future-imp-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u12-i-future-perf-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u12-i-future-perf-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u12-i-prep-plural-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u12-i-prep-plural-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u12-i-spelling-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u12-i-spelling-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u13-i-infinitive-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u13-i-infinitive-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u13-i-past-aspect-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u13-i-past-aspect-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u13-i-report-frame-time (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u13-i-reported-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u13-i-reported-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u13-i-tense-keep-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u13-i-tense-keep-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u14-i-future-aspect-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u14-i-future-aspect-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u14-i-future-person-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u14-i-future-person-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u14-i-impersonal-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u14-i-impersonal-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u15-i-aspect-consolidate-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u15-i-aspect-consolidate-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u15-i-imperative-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u15-i-imperative-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u15-i-say-request-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u15-i-say-request-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u16-i-inst-means-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u16-i-inst-means-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u17-i-age-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u17-i-age-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u17-i-clock-productive-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u17-i-clock-productive-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u17-i-hours-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u17-i-hours-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u17-i-minutes-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u17-i-minutes-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u17-i-years-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u17-i-years-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u19-i-probability-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u19-i-probability-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u21-i-object-reference-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u21-i-object-reference-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u23-i-beginning-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u23-i-beginning-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u23-i-completion-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u23-i-completion-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u23-i-duration-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u23-i-duration-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u23-i-during-event-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u23-i-during-event-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u23-i-elapsed-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u23-i-elapsed-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u23-i-ranges-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u23-i-ranges-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u24-i-alternation-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u24-i-placement-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u24-i-placement-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u24-i-word-order-contrast-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u24-i-word-order-contrast-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u25-i-name-form-3 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u26-i-correspondence-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u26-i-correspondence-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u26-i-letter-writing-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u27-i-stress-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u27-i-stress-3 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u27-i-stress-4 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u28-i-readings-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u28-i-readings-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u29-i-adjective-function-a (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u29-i-adjective-function-p (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u30-i-capstone-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u30-i-capstone-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u30-i-particle-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u30-i-particle-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u4-i-nom-role-student (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u4-i-nom-role-train (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u5-i-decl-книга (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u5-i-decl-окно (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u5-i-indecl-кино (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u5-i-indecl-метро (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u5-i-indecl-такси (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u6-i-animacy-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u6-i-animacy-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u6-i-animacy-3 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u6-i-direction-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u6-i-direction-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u6-i-direction-3 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u6-i-feminine-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u6-i-feminine-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u6-i-object-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u6-i-object-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u6-i-object-3 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u6-i-possessive-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u6-i-possessive-3 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u6-i-pronoun-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u6-i-pronoun-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u6-i-pronoun-3 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u7-i-adverb-invariance-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u7-i-adverb-invariance-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u7-i-adverb-pairs-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u7-i-adverb-pairs-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u7-i-default-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u7-i-default-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u7-i-default-3 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u7-i-default-4 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u7-i-demonstrative-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u7-i-demonstrative-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u7-i-demonstrative-3 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u7-i-endings-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u7-i-endings-3 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u7-i-manner-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u7-i-manner-4 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u7-i-objectadj-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u7-i-objectadj-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u7-i-objectadj-3 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u7-i-place-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u7-i-place-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u7-i-place-3 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u7-i-question-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u7-i-question-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u7-i-question-3 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u7-i-spelling-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u7-i-spelling-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u8-i-agreement-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u8-i-agreement-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u8-i-agreement-3 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u8-i-availability-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u8-i-availability-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u8-i-availability-3 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u8-i-irregular-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u8-i-irregular-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u8-i-irregular-3 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u8-i-plural-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u8-i-plural-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u8-i-plural-3 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u8-i-plural-4 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u8-i-plural-5 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u8-i-plural-6 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u8-i-spelling-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u8-i-spelling-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u8-i-spelling-3 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u8-i-spelling-4 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u9-i-cardinal-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u9-i-cardinal-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u9-i-cardinal-3 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u9-i-cardinal-4 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u9-i-hundreds-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u9-i-hundreds-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u9-i-hundreds-3 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u9-i-odindva-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u9-i-odindva-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u9-i-odindva-3 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u9-i-odindva-4 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u9-i-odindva-5 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u9-i-pattern-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u9-i-pattern-4 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u9-i-quantity-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u9-i-quantity-4 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u9-i-quantity-5 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u9-i-quantity-6 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u9-i-quantity-7 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u9-i-quantity-8 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u9-i-quantity-9 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u9-i-teens-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u9-i-teens-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u9-i-teens-3 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u9-i-tens-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u9-i-tens-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u9-i-tens-3 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u9-i-thousands-1 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u9-i-thousands-2 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u9-i-thousands-3 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / FEWER_THAN_THREE_OPTIONS: u9-i-thousands-4 (options). Review diagnostic value and a bounded justification; option count alone does not prove invalidity.

- REVIEW_SIGNAL / IDENTICAL_REQUIRED_DISPLAY_TASK: u1-i-в-not-b, u2-i-в-not-b (prompt/cue/options/key). Required items have identical visible task signatures. Review context and construct before declaring a duplicate.

- REVIEW_SIGNAL / IDENTICAL_REQUIRED_DISPLAY_TASK: u1-i-у-not-y, u2-i-у-not-y (prompt/cue/options/key). Required items have identical visible task signatures. Review context and construct before declaring a duplicate.

- REVIEW_SIGNAL / IDENTICAL_REQUIRED_DISPLAY_TASK: u1-i-х-not-x, u2-i-х-not-x (prompt/cue/options/key). Required items have identical visible task signatures. Review context and construct before declaring a duplicate.

- REVIEW_SIGNAL / IDENTICAL_REQUIRED_DISPLAY_TASK: u1-i-я-identity, u2-i-я-identity (prompt/cue/options/key). Required items have identical visible task signatures. Review context and construct before declaring a duplicate.

- REVIEW_SIGNAL / IDENTICAL_REQUIRED_DISPLAY_TASK: u10-i-absence-3, u10-i-have-1 (prompt/cue/options/key). Required items have identical visible task signatures. Review context and construct before declaring a duplicate.

- REVIEW_SIGNAL / IDENTICAL_REQUIRED_DISPLAY_TASK: u10-i-absence-4, u10-i-have-4 (prompt/cue/options/key). Required items have identical visible task signatures. Review context and construct before declaring a duplicate.

- REVIEW_SIGNAL / IDENTICAL_REQUIRED_DISPLAY_TASK: u12-i-future-imp-1, u14-i-future-person-2 (prompt/cue/options/key). Required items have identical visible task signatures. Review context and construct before declaring a duplicate.

- REVIEW_SIGNAL / IDENTICAL_REQUIRED_DISPLAY_TASK: u13-i-infinitive-1, u15-i-aspect-consolidate-2 (prompt/cue/options/key). Required items have identical visible task signatures. Review context and construct before declaring a duplicate.

- REVIEW_SIGNAL / IDENTICAL_REQUIRED_DISPLAY_TASK: u13-i-infinitive-2, u15-i-aspect-consolidate-1 (prompt/cue/options/key). Required items have identical visible task signatures. Review context and construct before declaring a duplicate.

- REVIEW_SIGNAL / IDENTICAL_REQUIRED_DISPLAY_TASK: u26-i-address-notation-1, u30-i-address-marks-1 (prompt/cue/options/key). Required items have identical visible task signatures. Review context and construct before declaring a duplicate.

- REVIEW_SIGNAL / IDENTICAL_REQUIRED_DISPLAY_TASK: u26-i-address-notation-2, u30-i-address-marks-2 (prompt/cue/options/key). Required items have identical visible task signatures. Review context and construct before declaring a duplicate.

- REVIEW_SIGNAL / IDENTICAL_REQUIRED_DISPLAY_TASK: u7-i-spelling-1, u8-i-spelling-3 (prompt/cue/options/key). Required items have identical visible task signatures. Review context and construct before declaring a duplicate.

- REVIEW_SIGNAL / IDENTICAL_REQUIRED_DISPLAY_TASK: u7-i-spelling-2, u8-i-spelling-4 (prompt/cue/options/key). Required items have identical visible task signatures. Review context and construct before declaring a duplicate.

- STRUCTURAL_ERROR / LEARNER_MARKUP: ex-u13-reported-3 (display). A learner text field contains source-markup syntax; inspect the rendering and correct the governed text.

- STRUCTURAL_ERROR / LEARNER_MARKUP: u10-st-rem-adjective (body). A learner text field contains source-markup syntax; inspect the rendering and correct the governed text.

- STRUCTURAL_ERROR / LEARNER_MARKUP: u10-st-rem-preposition (body). A learner text field contains source-markup syntax; inspect the rendering and correct the governed text.

- STRUCTURAL_ERROR / LEARNER_MARKUP: u10-st-rem-pronoun (body). A learner text field contains source-markup syntax; inspect the rendering and correct the governed text.

- STRUCTURAL_ERROR / LEARNER_MARKUP: u10-st-teach-adjective-2 (body). A learner text field contains source-markup syntax; inspect the rendering and correct the governed text.

- STRUCTURAL_ERROR / LEARNER_MARKUP: u10-st-teach-preposition-2 (body). A learner text field contains source-markup syntax; inspect the rendering and correct the governed text.

- STRUCTURAL_ERROR / LEARNER_MARKUP: u10-st-teach-pronoun-2 (body). A learner text field contains source-markup syntax; inspect the rendering and correct the governed text.

- STRUCTURAL_ERROR / LEARNER_MARKUP: u11-st-rem-past-be (body). A learner text field contains source-markup syntax; inspect the rendering and correct the governed text.

- STRUCTURAL_ERROR / LEARNER_MARKUP: u11-st-teach-past-be-2 (body). A learner text field contains source-markup syntax; inspect the rendering and correct the governed text.

- STRUCTURAL_ERROR / LEARNER_MARKUP: u12-st-rem-dative (body). A learner text field contains source-markup syntax; inspect the rendering and correct the governed text.

- STRUCTURAL_ERROR / LEARNER_MARKUP: u12-st-rem-prep-plural (body). A learner text field contains source-markup syntax; inspect the rendering and correct the governed text.

- STRUCTURAL_ERROR / LEARNER_MARKUP: u12-st-rem-spelling (body). A learner text field contains source-markup syntax; inspect the rendering and correct the governed text.

- STRUCTURAL_ERROR / LEARNER_MARKUP: u12-st-teach-dative-2 (body). A learner text field contains source-markup syntax; inspect the rendering and correct the governed text.

- STRUCTURAL_ERROR / LEARNER_MARKUP: u12-st-teach-prep-plural-2 (body). A learner text field contains source-markup syntax; inspect the rendering and correct the governed text.

- STRUCTURAL_ERROR / LEARNER_MARKUP: u12-st-teach-spelling-2 (body). A learner text field contains source-markup syntax; inspect the rendering and correct the governed text.

- STRUCTURAL_ERROR / LEARNER_MARKUP: u14-st-rem-future-person (body). A learner text field contains source-markup syntax; inspect the rendering and correct the governed text.

- STRUCTURAL_ERROR / LEARNER_MARKUP: u14-st-rem-impersonal (body). A learner text field contains source-markup syntax; inspect the rendering and correct the governed text.

- STRUCTURAL_ERROR / LEARNER_MARKUP: u14-st-teach-future-person-2 (body). A learner text field contains source-markup syntax; inspect the rendering and correct the governed text.

- STRUCTURAL_ERROR / LEARNER_MARKUP: u14-st-teach-impersonal-2 (body). A learner text field contains source-markup syntax; inspect the rendering and correct the governed text.

- STRUCTURAL_ERROR / LEARNER_MARKUP: u15-st-rem-say-request (body). A learner text field contains source-markup syntax; inspect the rendering and correct the governed text.

- STRUCTURAL_ERROR / LEARNER_MARKUP: u15-st-teach-say-request-2 (body). A learner text field contains source-markup syntax; inspect the rendering and correct the governed text.

- STRUCTURAL_ERROR / LEARNER_MARKUP: u4-st-rem-present (body). A learner text field contains source-markup syntax; inspect the rendering and correct the governed text.

- STRUCTURAL_ERROR / LEARNER_MARKUP: u4-st-teach-present-1 (body). A learner text field contains source-markup syntax; inspect the rendering and correct the governed text.

- STRUCTURAL_ERROR / LEARNER_MARKUP: u6-st-rem-direction (body). A learner text field contains source-markup syntax; inspect the rendering and correct the governed text.

- STRUCTURAL_ERROR / LEARNER_MARKUP: u6-st-rem-object (body). A learner text field contains source-markup syntax; inspect the rendering and correct the governed text.

- STRUCTURAL_ERROR / LEARNER_MARKUP: u6-st-teach-direction-2 (body). A learner text field contains source-markup syntax; inspect the rendering and correct the governed text.

- STRUCTURAL_ERROR / LEARNER_MARKUP: u6-st-teach-object-2 (body). A learner text field contains source-markup syntax; inspect the rendering and correct the governed text.

- STRUCTURAL_ERROR / LEARNER_MARKUP: u7-st-rem-adverb-pairs (body). A learner text field contains source-markup syntax; inspect the rendering and correct the governed text.

- STRUCTURAL_ERROR / LEARNER_MARKUP: u7-st-rem-demonstrative (body). A learner text field contains source-markup syntax; inspect the rendering and correct the governed text.

- STRUCTURAL_ERROR / LEARNER_MARKUP: u7-st-rem-objectadj (body). A learner text field contains source-markup syntax; inspect the rendering and correct the governed text.

- STRUCTURAL_ERROR / LEARNER_MARKUP: u7-st-rem-place (body). A learner text field contains source-markup syntax; inspect the rendering and correct the governed text.

- STRUCTURAL_ERROR / LEARNER_MARKUP: u7-st-teach-adverb-pairs-2 (body). A learner text field contains source-markup syntax; inspect the rendering and correct the governed text.

- STRUCTURAL_ERROR / LEARNER_MARKUP: u7-st-teach-demonstrative-2 (body). A learner text field contains source-markup syntax; inspect the rendering and correct the governed text.

- STRUCTURAL_ERROR / LEARNER_MARKUP: u7-st-teach-objectadj-2 (body). A learner text field contains source-markup syntax; inspect the rendering and correct the governed text.

- STRUCTURAL_ERROR / LEARNER_MARKUP: u7-st-teach-place-2 (body). A learner text field contains source-markup syntax; inspect the rendering and correct the governed text.

- STRUCTURAL_ERROR / LEARNER_MARKUP: u8-st-rem-irregular (body). A learner text field contains source-markup syntax; inspect the rendering and correct the governed text.

- STRUCTURAL_ERROR / LEARNER_MARKUP: u8-st-teach-irregular-2 (body). A learner text field contains source-markup syntax; inspect the rendering and correct the governed text.

- REVIEW_SIGNAL / NO_CYRILLIC_IN_REQUIRED_DISPLAY: u13-i-tense-keep-2 (prompt/cue/options). The question displays no Cyrillic. Review the Russian-learning construct or make orientation explicitly nongating.

- REVIEW_SIGNAL / NO_CYRILLIC_IN_REQUIRED_DISPLAY: u25-i-diminutives-1 (prompt/cue/options). The question displays no Cyrillic. Review the Russian-learning construct or make orientation explicitly nongating.

- REVIEW_SIGNAL / NO_CYRILLIC_IN_REQUIRED_DISPLAY: u25-i-diminutives-2 (prompt/cue/options). The question displays no Cyrillic. Review the Russian-learning construct or make orientation explicitly nongating.

- REVIEW_SIGNAL / NO_CYRILLIC_IN_REQUIRED_DISPLAY: u25-i-name-form-3 (prompt/cue/options). The question displays no Cyrillic. Review the Russian-learning construct or make orientation explicitly nongating.

- REVIEW_SIGNAL / NO_CYRILLIC_IN_REQUIRED_DISPLAY: u26-i-letter-writing-2 (prompt/cue/options). The question displays no Cyrillic. Review the Russian-learning construct or make orientation explicitly nongating.

- REVIEW_SIGNAL / NO_CYRILLIC_IN_REQUIRED_DISPLAY: u26-i-postal-10 (prompt/cue/options). The question displays no Cyrillic. Review the Russian-learning construct or make orientation explicitly nongating.

- REVIEW_SIGNAL / NO_CYRILLIC_IN_REQUIRED_DISPLAY: u26-i-postal-3 (prompt/cue/options). The question displays no Cyrillic. Review the Russian-learning construct or make orientation explicitly nongating.

- REVIEW_SIGNAL / NO_CYRILLIC_IN_REQUIRED_DISPLAY: u26-i-postal-5 (prompt/cue/options). The question displays no Cyrillic. Review the Russian-learning construct or make orientation explicitly nongating.

- REVIEW_SIGNAL / NO_CYRILLIC_IN_REQUIRED_DISPLAY: u27-i-stress-4 (prompt/cue/options). The question displays no Cyrillic. Review the Russian-learning construct or make orientation explicitly nongating.

- REVIEW_SIGNAL / NO_CYRILLIC_IN_REQUIRED_DISPLAY: u29-i-register-4 (prompt/cue/options). The question displays no Cyrillic. Review the Russian-learning construct or make orientation explicitly nongating.

- REVIEW_SIGNAL / NO_CYRILLIC_IN_REQUIRED_DISPLAY: u29-i-register-5 (prompt/cue/options). The question displays no Cyrillic. Review the Russian-learning construct or make orientation explicitly nongating.

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u1-i-ю-identity (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u1-st-iotated

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u1-i-ё-identity (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u1-st-iotated

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u10-i-adjective-2 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u10-st-rem-adjective

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u10-i-preposition-1 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u10-st-rem-preposition

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u10-i-pronoun-1 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u10-st-rem-pronoun

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u10-i-pronoun-2 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u10-st-rem-pronoun

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u10-i-pronoun-3 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u10-st-rem-pronoun

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u10-i-pronoun-4 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u10-st-rem-pronoun

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u11-i-past-be-2 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u11-st-rem-past-be

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u11-i-past-read-2 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u11-st-rem-past-read

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u11-i-reflexive-1 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u11-st-rem-reflexive

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u11-i-reflexive-2 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u11-st-rem-reflexive

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u12-i-dative-1 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u12-st-rem-dative

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u12-i-dative-2 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u12-st-rem-dative

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u12-i-future-imp-2 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u12-st-rem-future-imp

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u12-i-prep-plural-1 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u12-st-rem-prep-plural

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u12-i-prep-plural-2 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u12-st-rem-prep-plural

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u14-i-future-aspect-1 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u14-st-rem-future-aspect

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u14-i-future-person-1 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u14-st-rem-future-person

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u15-i-say-request-1 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u15-st-rem-say-request

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u2-i-я-identity (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u2-st-review

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u29-i-register-4 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u29-register-remediate

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u3-i-name-chto-eto (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u3-st-rem-naming

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u3-i-name-kto-eto (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u3-st-rem-naming

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u3-i-phrase-да (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u3-st-rem-phrases

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u3-i-phrase-пожалуйста (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u3-st-rem-phrases

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u3-i-phrase-это (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u3-st-rem-phrases

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u4-i-pronoun-вы (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u4-st-rem-pronouns

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u4-i-pronoun-она (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u4-st-rem-pronouns

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u4-i-pronoun-они (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u4-st-rem-pronouns

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u4-i-pronoun-ты (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u4-st-rem-pronouns

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u4-i-stress-2114b12f (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u4-st-rem-stress

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u5-i-pattern-pattern-gde-zhivete (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u5-st-rem-questions

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u5-i-pattern-pattern-kak-dela (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u5-st-rem-questions

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u5-i-pattern-pattern-kto-eto (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u5-st-rem-questions

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u5-i-prep-o-sade (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u5-st-rem-prepositional

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u5-i-prep-v-moskve (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u5-st-rem-prepositional

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u5-i-q-gde (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u5-st-rem-questions

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u5-i-q-kak (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u5-st-rem-questions

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u5-i-q-kogda (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u5-st-rem-questions

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u5-i-q-pochemu (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u5-st-rem-questions

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u6-i-direction-3 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u6-st-rem-direction

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u6-i-feminine-1 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u6-st-rem-feminine

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u6-i-feminine-2 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u6-st-rem-feminine

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u6-i-object-2 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u6-st-rem-object

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u6-i-object-3 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u6-st-rem-object

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u6-i-pronoun-2 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u6-st-rem-pronoun

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u6-i-pronoun-3 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u6-st-rem-pronoun

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u6-i-third-2 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u6-st-rem-third

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u7-i-default-2 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u7-st-rem-default

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u7-i-default-3 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u7-st-rem-default

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u7-i-default-4 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u7-st-rem-default

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u7-i-demonstrative-2 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u7-st-rem-demonstrative

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u7-i-manner-1 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u7-st-rem-manner

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u7-i-manner-3 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u7-st-rem-manner

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u7-i-manner-4 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u7-st-rem-manner

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u7-i-place-1 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u7-st-rem-place

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u7-i-place-2 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u7-st-rem-place

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u7-i-place-3 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u7-st-rem-place

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u8-i-irregular-1 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u8-st-rem-irregular

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u8-i-irregular-2 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u8-st-rem-irregular

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u8-i-irregular-3 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u8-st-rem-irregular

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u9-i-cardinal-2 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u9-st-rem-cardinal

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u9-i-cardinal-3 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u9-st-rem-cardinal

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u9-i-cardinal-4 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u9-st-rem-cardinal

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u9-i-hundreds-1 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u9-st-rem-hundreds

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u9-i-hundreds-2 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u9-st-rem-hundreds

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u9-i-hundreds-3 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u9-st-rem-hundreds

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u9-i-teens-1 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u9-st-rem-teens

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u9-i-teens-2 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u9-st-rem-teens

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u9-i-tens-1 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u9-st-rem-tens

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u9-i-tens-2 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u9-st-rem-tens

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u9-i-tens-3 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u9-st-rem-tens

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u9-i-thousands-1 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u9-st-rem-thousands

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u9-i-thousands-2 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u9-st-rem-thousands

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u9-i-thousands-3 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u9-st-rem-thousands

- REVIEW_SIGNAL / REMEDIATION_TRANSFER_OR_GAP: u9-i-thousands-4 (remediation). Neither cue nor key was located in linked remediation. Review explanation adequacy rather than inserting answer scripts.
  Steps: u9-st-rem-thousands

- REVIEW_SIGNAL / TEACHING_TRANSFER_OR_GAP: u1-i-ю-identity (instruction). Neither cue nor key was located in linked teaching. Check the taught rule and legitimate transfer; this is not proof the content is untaught.
  Steps: u1-st-iotated

- REVIEW_SIGNAL / TEACHING_TRANSFER_OR_GAP: u1-i-ё-identity (instruction). Neither cue nor key was located in linked teaching. Check the taught rule and legitimate transfer; this is not proof the content is untaught.
  Steps: u1-st-iotated

- REVIEW_SIGNAL / TEACHING_TRANSFER_OR_GAP: u2-i-я-identity (instruction). Neither cue nor key was located in linked teaching. Check the taught rule and legitimate transfer; this is not proof the content is untaught.
  Steps: u2-st-review

- REVIEW_SIGNAL / TEACHING_TRANSFER_OR_GAP: u29-i-register-4 (instruction). Neither cue nor key was located in linked teaching. Check the taught rule and legitimate transfer; this is not proof the content is untaught.
  Steps: u29-register-teach-1, u29-register-teach-2

- REVIEW_SIGNAL / TEACHING_TRANSFER_OR_GAP: u7-i-manner-1 (instruction). Neither cue nor key was located in linked teaching. Check the taught rule and legitimate transfer; this is not proof the content is untaught.
  Steps: u7-st-teach-manner-1, u7-st-teach-manner-2, u7-st-teach-manner-3

- REVIEW_SIGNAL / TEACHING_TRANSFER_OR_GAP: u7-i-manner-3 (instruction). Neither cue nor key was located in linked teaching. Check the taught rule and legitimate transfer; this is not proof the content is untaught.
  Steps: u7-st-teach-manner-1, u7-st-teach-manner-2, u7-st-teach-manner-3

- REVIEW_SIGNAL / TEACHING_TRANSFER_OR_GAP: u7-i-manner-4 (instruction). Neither cue nor key was located in linked teaching. Check the taught rule and legitimate transfer; this is not proof the content is untaught.
  Steps: u7-st-teach-manner-1, u7-st-teach-manner-2, u7-st-teach-manner-3
