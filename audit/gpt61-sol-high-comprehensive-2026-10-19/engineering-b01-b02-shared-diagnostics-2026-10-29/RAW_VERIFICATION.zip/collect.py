from pathlib import Path
import json,subprocess,hashlib,zipfile,collections,shutil
R=Path('/workspace/russian-companion');W=Path(__file__).parent;D=R/'audit/gpt61-sol-high-comprehensive-2026-10-19/engineering-b01-b02-shared-diagnostics-2026-10-29'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=R,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain=v1','-z','--untracked-files=all'],cwd=R)
source=git('rev-parse','HEAD');reg=json.loads((W/'REGRESSION/RESULT.json').read_text());dis=json.loads((W/'DISCOVERY/RESULT.json').read_text());cli=json.loads((W/'CLI/RESULT.json').read_text());scope=json.loads((W/'SCOPE.json').read_text());con=json.loads((D/'CONSERVATION.json').read_text())
assert source==reg['sourceCommit']==dis['sourceCommit']==cli[0]['sourceCommit']==cli[1]['sourceCommit']
assert reg['testCounts']==dict(reported=56,passed=56,failed=0,errors=0,skipped=0),reg['testCounts']
assert reg['classes']==5 and reg['exitCode']==0
assert dis['syntheticDryRun'] and dis['testCounts']['reported']==56 and dis['testCounts']['passed']==0
assert reg['discoveryComparison']['exactSameMethodSet']
assert reg['tasks']['compileDebugSources']!='NOT_REACHED' and reg['tasks']['verifyReleaseGateAttachment']!='NOT_REACHED'
assert not any(reg['lintIssuesBySeverity'][k] for k in ['Fatal','Error'])
for p,h in {**con['existingTestHashes'],**con['protectedEvidenceHashes']}.items():assert sha(R/p)==h,p
for entry in json.loads((R/'app/src/test/resources/reviewed-curriculum-cyrillic.json').read_text())['files']:
 assert sha(R/'app'/entry['path'])==entry['sha256'],entry['path']
assert subprocess.check_output(['git','show',con['previousCommit']+':app/src/main/java/dev/russiancompanion/v2/curriculum/V2Validator.kt'],cwd=R)==(R/'app/src/main/java/dev/russiancompanion/v2/curriculum/V2Validator.kt').read_bytes()
assert cli[0]['gradleExit']==0 and cli[1]['gradleExit']==1
assert json.loads((W/'CLI/REPORT.json').read_text())==json.loads((W/'CLI/STRICT.json').read_text())
assert 'non-zero exit value 2' in (W/'CLI/STRICT.log').read_text()
asset=R/'app/src/main/assets/content/v2-curriculum.json';assert sha(asset)==con['packAssetSha256']==cli[0]['rawInputSha256']
# Archive complete raw files without discarding GC, CLI failures or discovery records.
paths=sorted(p for p in W.rglob('*') if p.is_file())
manifest={p.relative_to(W).as_posix():sha(p) for p in paths}
archive=D/'RAW_VERIFICATION.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
 for p in paths:z.write(p,p.relative_to(W).as_posix())
 z.writestr('MEMBER_SHA256.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for p,h in manifest.items():assert hashlib.sha256(z.read(p)).hexdigest()==h,p
for src,dst in [(W/'REGRESSION/RESULT.json','RUNTIME_RESULT.json'),(W/'DISCOVERY/RESULT.json','DISCOVERY_RESULT.json'),(W/'CLI/RESULT.json','CLI_RESULT.json'),(W/'COUNT_COMPARISON.json','COUNT_COMPARISON.json'),(W/'CLI/REPORT.json','CURRICULUM_DESIGN_BASELINE.json')]:shutil.copy2(src,D/dst)
summary=dict(sourceCommit=source,sourceRootTree=git('rev-parse','HEAD^{tree}'),inputTrees=reg['inputTrees'],testCounts=reg['testCounts'],classes=5,scope='Five full selected classes; NOT a complete suite',completeSuite=False,discoverySyntheticSkips=56,commandsIn='RAW_VERIFICATION.zip: DISCOVERY/CONTEXT.json, REGRESSION/CONTEXT.json and CLI/*_CONTEXT.json',lint=reg['lintIssuesBySeverity'],tasks=reg['tasks'],qualityReport=cli,reviewedValidatorAnd19ReferenceFilesUnchanged=True,all285PreexistingTestFilesUnchanged=True,newKotlinTestFiles=1,all155BindingRecordsUnchanged=True,all77LearnerArchivesUnchanged=True,protectedEvidenceUnchanged=True,sourceBindings='RECONCILIATION_PENDING',all59Findings='OPEN',independentAudit='INCOMPLETE',excludedScreenshotExporters={'VisualReviewCaptureTest':2,'Units35ChunkCaptureTest':2,'Units610ChunkCaptureTest':10,'Units1115GapCaptureTest':2},provisionalJvmDirective='-XX:CompileCommand=exclude,androidx/sqlite/driver/SupportSQLiteConnection.prepare',directiveAdopted=False,directiveIsTestExclusion=False,nativeRootCause='UNCONFIRMED',apkIdentityAndSignature='NO APK ASSEMBLED, INSTALLED OR SIGNED in this phase; prior APK evidence unchanged',physicalDeviceAcceptance='OUTSTANDING_LAST_AFTER_FINAL_COMPREHENSIVE_INDEPENDENT_AUDIT',rawArchive=dict(path=archive.name,bytes=archive.stat().st_size,sha256=sha(archive),members=len(manifest)+1,crcAndAllMemberSha256Verified=True),priorScopesSeparateNotSummed=True)
(D/'VERIFICATION.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(dict(sourceCommit=source,testCounts=reg['testCounts'],lint=reg['lintIssuesBySeverity'],archive=summary['rawArchive'])))
