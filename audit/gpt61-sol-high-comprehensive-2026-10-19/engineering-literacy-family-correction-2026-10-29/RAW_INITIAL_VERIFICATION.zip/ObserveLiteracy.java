import java.nio.file.*;
import java.io.*;
import java.util.*;
import dev.russiancompanion.v2.curriculum.*;
public class ObserveLiteracy {
 public static void main(String[] a) throws Exception {
  File root=new File(a[0]);
  var process=new ProcessBuilder("git","show","f653da03d1bc657e8acaeef52141552c531e42ce:app/src/main/assets/content/v2-curriculum.json").directory(root).start();
  String oldRaw=new String(process.getInputStream().readAllBytes(),java.nio.charset.StandardCharsets.UTF_8);
  if(process.waitFor()!=0)throw new AssertionError("Historical source unavailable");
  var old=V2PackLoader.INSTANCE.parse(oldRaw);
  var current=V2PackLoader.INSTANCE.parse(Files.readString(root.toPath().resolve("app/src/main/assets/content/v2-curriculum.json")));
  String source=dev.russiancompanion.release.ReleaseSourceDigestKt.computeReleaseSourceDigest(root,Collections.emptyMap());
  var v=V2Validator.INSTANCE;
  System.out.println("{\"sourceCommit\":\""+a[1]+"\",\"repositorySourceDigest\":\""+source+"\",\"oldPackContentReviewDigest\":\""+v.contentReviewDigest$app(old)+"\",\"newPackContentReviewDigest\":\""+v.contentReviewDigest$app(current)+"\",\"units\":[");
  for(int n=1;n<=30;n++) {
   String before=v.unitContentReviewDigest$app(old,n), after=v.unitContentReviewDigest$app(current,n);
   if((n<=2)==before.equals(after))throw new AssertionError("Unexpected unit identity delta "+n);
   System.out.println((n>1?",":"")+"{\"unit\":"+n+",\"before\":\""+before+"\",\"after\":\""+after+"\",\"changed\":"+!before.equals(after)+"}");
  }
  int wrongCalls=0,shown=0,literacyShown=0;
  for(var item:current.getItems())for(var option:item.getOptions())if(!option.equals(item.getAnswer())) {
   wrongCalls++;
   var text=dev.russiancompanion.v2.ui.V2AnswerFeedbackKt.selectedWrongOptionRationale(item,option);
   if(text!=null) {shown++;if(item.getId().startsWith("u1-")||item.getId().startsWith("u2-"))literacyShown++;}
  }
  if(literacyShown!=46)throw new AssertionError("Expected46new authored explanations, got"+literacyShown);
  System.out.println("],\"presenterWrongOptionCalls\":"+wrongCalls+",\"presenterShown\":"+shown+",\"presenterNotShown\":"+(wrongCalls-shown)+",\"literacyShown\":"+literacyShown+",\"JUnitMethodsExecuted\":0,\"independentAcceptance\":false}");
 }
}
