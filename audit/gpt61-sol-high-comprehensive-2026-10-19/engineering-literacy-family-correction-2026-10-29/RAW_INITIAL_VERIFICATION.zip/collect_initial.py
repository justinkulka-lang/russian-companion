from pathlib import Path
import subprocess,json,hashlib,zipfile,shutil
R=Path('/workspace/russian-companion');W=Path(__file__).parent;D=R/'audit/gpt61-sol-high-comprehensive-2026-10-19/engineering-literacy-family-correction-2026-10-29'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
x=json.loads((W/'REGRESSION/RESULT.json').read_text());d=json.loads((W/'DISCOVERY/RESULT.json').read_text());con=json.loads((D/'CONSERVATION.json').read_text());source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain=v1','-z','--untracked-files=all'],cwd=R)
assert source==x['sourceCommit']==d['sourceCommit']=='0107931bfee92fa932c93ae63d3f4a34080cb2bf'
assert x['testCounts']==dict(reported=24,passed=23,failed=1,errors=0,skipped=0),x['testCounts']
assert x['exitCode']==1 and x['classes']==6 and x['discoveryComparison']['exactSameMethodSet']
failed=[t for t in x['tests'] if t['outcome']=='FAILED'];assert len(failed)==1 and failed[0]['method']=='letterIdentityExplainsEachWrongValueWithoutGrantingRequiredCredit'
for p,h in {**con['preExistingTestHashes'],**con['protectedEvidenceHashes'],**con['archives']}.items():assert sha(R/p)==h,p
assert sha(R/'app/src/main/assets/content/v2-curriculum.json')=='a25b17d1f807f36f32ad820fdbb71e422d9d10a2d5b5a353134a3c3d338d7651'
ob=json.loads((W/'OBSERVATION.json').read_text());assert [u['unit'] for u in ob['units'] if u['changed']]==[1,2] and ob['literacyShown']==46
paths=[p for p in W.rglob('*') if p.is_file()];index={p.relative_to(W).as_posix():sha(p) for p in paths}
with zipfile.ZipFile(D/'RAW_INITIAL_VERIFICATION.zip','x',zipfile.ZIP_DEFLATED) as z:
 for p in paths:z.write(p,p.relative_to(W).as_posix())
 z.writestr('MEMBER_SHA256.json',json.dumps(index,indent=2)+'\n')
with zipfile.ZipFile(D/'RAW_INITIAL_VERIFICATION.zip') as z:
 assert z.testzip() is None
 for p,h in index.items():assert hashlib.sha256(z.read(p)).hexdigest()==h,p
for p,name in [(W/'REGRESSION/RESULT.json','INITIAL_RUNTIME_RESULT.json'),(W/'DISCOVERY/RESULT.json','INITIAL_DISCOVERY_RESULT.json'),(W/'OBSERVATION.json','COMPILED_IDENTITY_OBSERVATION.json')]:shutil.copy2(p,D/name)
if (W/'CLI/RESULT.json').exists():shutil.copy2(W/'CLI/RESULT.json',D/'CLI_RESULT.json')
(D/'INITIAL_OUTCOME.md').write_text(f'''# Initial literacy correction verification retained

Actual source`{source}`:24reported/23passed/1failed/0errors/0skips;6FULLclasses;Gradleexit1. All6unchanged quality methods now pass (including all3original defects), the historical capture method passed without re-export, all4new compatibility methods passed, existing7rationale/4optionUI methods passed and the new Unit2case-variant UI passed. The sole newUnit1UI fixture failed before rendering with NoSuchElementException: it requested u1-i-м-identity in a CHECK step, but that item occurs only in u1-st-cons-check/GUIDED. App behavior was not reached. Preserve this failure and all assertions; follow up with a genuinely checked letter-identity item, without changing production to satisfy the fixture. No24/24claim and no summing overlapping follow-ups.

All87archives decode/preserve under the actual tests; all10pinned scenarios retain their raw rows after named replacement/reopen and no longer grant current completion/credit or a current Unit3review under changed foundation digests. Fresh governed work completes1–3and creates schema2review bound to current owners while retaining old review rows. All288oldertestfiles/whole7methodbaseline/155bindingrecords remain exact. Tests observed only unit1/2contentdigests changing; unit3–30digests remain unchanged. Keys/IDs/native/provenance/source/rights data are exact, with4case task distractor/cue/kind changes and46new English explanations under pending review.

Compiled official observation: repositorysource`{ob['repositorySourceDigest']}`, packcontent`{ob['newPackContentReviewDigest']}`; neither is an approval. Presenter probe1063calls(not JUnit):626shown/437notshown, including46new literacy explanations. No full-course linguistic accuracy claim. Fresh discovery24synthetic skips/zero runtime passes; exact identities/events/XML. Lint{x['lintIssuesBySeverity']}; compileDebugSources and gate attachment completed. Exact commands/logs/classpath/probe code/XML/events/GC retained in RAW_INITIAL_VERIFICATION.zip. Source bindings remain PENDING after genuine content changes; do not manually refresh expected digests.

All59findings OPEN; auditINCOMPLETE. Four exporters16excluded; provisionalJITdirectiveunadopted/notatestexclusion/nativecauseUNCONFIRMED. NoAPKassembly/install/signing/newAPKidentity/signature,merge,freeze or release approval. Final comprehensive independent audit then physicalGalaxyS26Ultra airplane-mode/rebootLAST.
''')
print(json.dumps(dict(source=source,counts=x['testCounts'],lint=x['lintIssuesBySeverity'],newPackDigest=ob['newPackContentReviewDigest'])))
