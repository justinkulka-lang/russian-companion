from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,hashlib
R=Path('/workspace/russian-companion');W=Path(__file__).parent;O=W/'CLI';O.mkdir()
git=lambda *a:subprocess.check_output(['git',*a],cwd=R,text=True).strip()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not subprocess.check_output(['git','status','--porcelain=v1','-z','--untracked-files=all'],cwd=R)
source=git('rev-parse','HEAD');trees={p:git('rev-parse','HEAD:'+p) for p in ['app/src/main','app/src/test','catalog','docs','review','release']}
results=[]
for task,name in [('reportCurriculumDesign','REPORT'),('checkCurriculumDesign','STRICT')]:
 output=O/(name+'.json');args=[task,'-PcurriculumDesignOutput='+str(output),'--offline','--max-workers=2','--console=plain']
 context=dict(sourceCommit=source,inputTrees=trees,command=['./gradlew',*args],startedUtc=datetime.now(timezone.utc).isoformat(),activation='source /workspace/setup/android-env.sh',scope='Compiled design CLI, not JUnit tests, no APK',expectedExit=0 if name=='REPORT' else 'Gradle nonzero if signals remain; underlying process exit2')
 (O/(name+'_CONTEXT.json')).write_text(json.dumps(context,indent=2)+'\n')
 with (O/(name+'.log')).open('x') as log:
  p=subprocess.run(['bash','-c','source /workspace/setup/android-env.sh; exec ./gradlew "$@"','design-cli',*args],cwd=R,stdout=log,stderr=subprocess.STDOUT)
 (O/(name+'.exit')).write_text(str(p.returncode)+'\n')
 entry=dict(task=task,gradleExit=p.returncode,outputExists=output.exists(),sourceCommit=source)
 if output.exists():
  x=json.loads(output.read_text());entry.update(rawInputBytes=x['rawInputBytes'],rawInputSha256=x['rawInputSha256'],verdict=x['report']['verdict'],counts=x['report']['counts'],rules={k:sum(s['rule']==k for s in x['report']['signals']) for k in sorted(set(s['rule'] for s in x['report']['signals']))},authoredRequiredKeyPositions=x['report']['authoredRequiredKeyPositions'])
 results.append(entry)
 assert not subprocess.check_output(['git','status','--porcelain=v1','-z','--untracked-files=all'],cwd=R)
 assert git('rev-parse','HEAD')==source
(O/'RESULT.json').write_text(json.dumps(results,indent=2)+'\n')
(O/'SHA256.json').write_text(json.dumps({p.name:sha(p) for p in O.iterdir() if p.is_file() and p.name!='SHA256.json'},indent=2)+'\n')
print(json.dumps(results))
