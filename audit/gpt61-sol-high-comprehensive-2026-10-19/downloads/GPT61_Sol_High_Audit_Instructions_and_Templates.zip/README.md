Instructions and unfilled templates only. Authorized repository/history access required. Full source snapshot is a separate artifact.
