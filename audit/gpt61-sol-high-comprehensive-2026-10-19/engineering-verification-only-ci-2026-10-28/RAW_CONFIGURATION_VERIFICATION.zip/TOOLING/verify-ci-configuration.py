from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,hashlib,xml.etree.ElementTree as ET
import yaml
R=Path('/workspace/russian-companion');W=Path('/workspace/artifacts/verification-only-ci-2026-10-28');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();save=lambda n,v:(W/n).write_text(json.dumps(v,indent=2)+'\n');git=lambda *a:subprocess.check_output(['git',*a],cwd=R).decode().strip()
assert not subprocess.check_output(['git','status','--porcelain=v1','-z','--untracked-files=all'],cwd=R)
y=yaml.load((R/'.github/workflows/build.yml').read_text(),Loader=yaml.BaseLoader);steps=y['jobs']['verify']['steps'];run=next(s['run']for s in steps if s.get('name')=='Compile, lint, verify gate attachment, and run host tests');head,cmd=run.rsplit('          ./gradlew',1)if '          ./gradlew'in run else run.rsplit('./gradlew',1)
start=head.index("<<'GRADLE'\n")+len("<<'GRADLE'\n");end=head.index('\nGRADLE',start);init=W/'exporter-exclusions.gradle';init.write_text(head[start:end]+'\n')
assert 'assembleDebug'not in run and 'packageDebug'not in run and 'verifyReleaseGateAttachment'in run and 'testDebugUnitTest'in run
context={'sourceCommit':git('rev-parse','HEAD'),'inputTrees':{n:git('rev-parse','HEAD:'+n)for n in ['app/src/main','app/src/test','catalog','docs','review','release']},'workflowSha256':sha(R/'.github/workflows/build.yml'),'extractedInitSha256':sha(init),'startedUtc':datetime.now(timezone.utc).isoformat(),'testMethodsExecuted':0,'apkAssemblyInstallSigning':'NOT_RUN'};save('CONTEXT.json',context)
commands=[('TASK_GRAPH',['-I',str(init),'compileDebugSources','lintDebug','verifyReleaseGateAttachment','testDebugUnitTest','--continue','--dry-run','--offline','--console=plain']),('DISCOVERY',['-I',str(init),'-I',str(R/'audit/independent-gpt61-2026-10-12/broader-regression-2026-10-18/broader-tests.gradle'),'-Daudit.events.path='+str(W/'DISCOVERY_EVENTS.jsonl'),'testDebugUnitTest','--rerun','--test-dry-run','--offline','--max-workers=2','--console=plain'])]
results=[]
for label,args in commands:
 with(W/(label+'.log')).open('x')as out:p=subprocess.run(['bash','-c','source /workspace/setup/android-env.sh;exec ./gradlew "$@"','ci-config-check',*args],cwd=R,stdout=out,stderr=subprocess.STDOUT)
 results.append({'label':label,'command':['./gradlew',*args],'exitCode':p.returncode,'finishedUtc':datetime.now(timezone.utc).isoformat()});save('COMMAND_RESULTS.json',results);assert p.returncode==0,label
log=(W/'TASK_GRAPH.log').read_text();tasks=[x.split()[0]for x in log.splitlines()if x.startswith(':')];assert tasks and not any(t.split(':')[-1].lower().startswith(('assemble','package','bundle','sign','install','publish'))for t in tasks),tasks
(W/'DISCOVERY_XML').mkdir();rows=[]
for p in sorted((R/'app/build/test-results/testDebugUnitTest').glob('TEST-*.xml')):
 data=p.read_bytes();(W/'DISCOVERY_XML'/p.name).write_bytes(data)
 for t in ET.fromstring(data).findall('testcase'):assert t.find('skipped')is not None and t.find('failure')is None;rows.append({'testClass':t.get('classname'),'method':t.get('name')})
exclusions={'VisualReviewCaptureTest':2,'Units35ChunkCaptureTest':2,'Units610ChunkCaptureTest':10,'Units1115GapCaptureTest':2};assert not any(x['testClass'].split('.')[-1]in exclusions for x in rows)
assert len({(x['testClass'],x['method'])for x in rows})==len(rows)
result={'sourceCommit':context['sourceCommit'],'taskGraphHasNoApkAssemblyPackagingSigningInstallationPublishing':True,'taskGraph':tasks,'discoveredSyntheticSkips':len(rows),'classes':len({x['testClass']for x in rows}),'testMethodsExecuted':0,'runtimePasses':0,'exporterExclusions':exclusions,'expectedMethods':rows,'nativeDirectiveAdopted':False,'installedGradleArchiveIndependentlyHashed':False,'ciExecution':'NOT_EVIDENCED; prior runs blocked before runner by Actions budget','all48Findings':'OPEN','audit':'INCOMPLETE'};save('RESULT.json',result);print(json.dumps({k:v for k,v in result.items()if k not in ['taskGraph','expectedMethods']}));assert not subprocess.check_output(['git','status','--porcelain=v1','-z','--untracked-files=all'],cwd=R)
