from pathlib import Path
import json,hashlib,shutil,subprocess,zipfile,csv,collections,xml.etree.ElementTree as ET
R=Path('/workspace/russian-companion');W=Path(__file__).parent;D=R/'audit/gpt61-sol-high-comprehensive-2026-10-19/engineering-literacy-foundation-history-regression-2026-10-29'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
 return h.hexdigest()
con=json.loads((D/'CONSERVATION.json').read_text());ctx=json.loads((W/'REGRESSION/CONTEXT.json').read_text());scope=json.loads((W/'SCOPE.json').read_text());source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert source==ctx['sourceCommit'] and not subprocess.check_output(['git','status','--porcelain=v1','-z','--untracked-files=all'],cwd=R)
for key in ['testHashes','archives','protectedEvidenceHashes','currentRecordHashes']:
 for p,h in con[key].items():assert sha(R/p)==h,p
assert (W/'REGRESSION/RUN.exit').read_text().strip()=='1' and not (W/'REGRESSION/RESULT.json').exists()
rows=[];starts=[];failures=[]
for line in (W/'REGRESSION/EVENTS.jsonl').open():
 e=json.loads(line)
 if e['kind']=='START':starts.append((e['className'],e['name']))
 elif e['kind']=='RESULT':
  messages=e.get('exceptions',[]);msg=messages[0].get('message') if messages else None
  row=dict(testClass=e['className'],method=e['name'],resultEvent=e['resultType'],startMillis=e['startTime'],endMillis=e['endTime'],exceptionType=messages[0]['type'] if messages else None,messagePreview=msg[:350] if msg else '',messageUtf8Bytes=len(msg.encode()) if msg else 0,messageSha256=hashlib.sha256(msg.encode()).hexdigest() if msg else None)
  rows.append(row)
  if e['resultType']=='FAILURE':failures.append(row)
expected={(t['testClass'],t['method']) for t in scope['expectedMethods']};actual={(t['testClass'],t['method']) for t in rows};assert actual==expected==set(starts) and len(rows)==112
assert collections.Counter(r['resultEvent'] for r in rows)==dict(SUCCESS=74,FAILURE=38)
# Retain the actual stopped test output before another Gradle test task can replace it.
snapshot=W/'STOPPED_GRADLE_OUTPUT';shutil.copytree(R/'app/build/test-results/testDebugUnitTest',snapshot)
rejected=[]
for p in snapshot.glob('TEST-*.xml'):
 suite=ET.parse(p).getroot();rejected.append(dict(path=p.name,timestamp=suite.get('timestamp'),reason='Stale discovery XML; initial collector rejected timestamp before runtime start'))
assert len(rejected)==18
shutil.copy2(R/'app/build/reports/lint-results-debug.xml',W/'REGRESSION/LINT_CACHED.xml');issues=ET.parse(W/'REGRESSION/LINT_CACHED.xml').getroot().findall('issue');lint={s:sum(i.get('severity')==s for i in issues) for s in ['Fatal','Error','Warning','Hint']}
for label,data in [('RESULT_EVENTS.json',rows),('FAILURE_EVENTS.json',failures),('REJECTED_XML.json',rejected)]: (D/label).write_text(json.dumps(data,indent=2)+'\n')
with (D/'RESULT_EVENTS.csv').open('w',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n');writer.writeheader();writer.writerows(rows)
# Group the large raw streams separately; no messages truncated in retained raw evidence.
allfiles=[p for p in W.rglob('*') if p.is_file()];groups={'EVENTS':[W/'REGRESSION/EVENTS.jsonl'],'RUN_LOG':[W/'REGRESSION/RUN.log'],'BINARY':[p for p in snapshot.rglob('*') if p.is_file()],'OTHER':[]};taken={p for v in groups.values() for p in v};groups['OTHER']=[p for p in allfiles if p not in taken]
archiveIndex=[]
for label,paths in groups.items():
 target=D/('RAW_'+label+'.zip');members={p.relative_to(W).as_posix():dict(bytes=p.stat().st_size,sha256=sha(p)) for p in paths}
 with zipfile.ZipFile(target,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for p in paths:z.write(p,p.relative_to(W).as_posix())
  z.writestr('MEMBER_SHA256.json',json.dumps(members,indent=2)+'\n')
 with zipfile.ZipFile(target) as z:
  assert z.testzip() is None
  for name,v in members.items():
   h=hashlib.sha256()
   with z.open(name) as f:
    for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
   assert h.hexdigest()==v['sha256'],name
 archiveIndex.append(dict(path=target.name,bytes=target.stat().st_size,sha256=sha(target),members=members,crcAndMemberSha256Verified=True))
 print('ARCHIVED',target.name,target.stat().st_size,flush=True)
 assert target.stat().st_size<95*1024*1024,'Archive needs safe parts before Git publication'
(D/'RAW_INDEX.json').write_text(json.dumps(archiveIndex,indent=2)+'\n')
meta=dict(sourceCommit=source,inputTrees=ctx['inputTrees'],status='INCOMPLETE_FINAL_RUNTIME_REPORTS_UNAVAILABLE',underlyingGradleExit=1,observedFailure='Java heap space',eventCounts=dict(SUCCESS=74,FAILURE=38),resultEvents=112,classes=18,allExpectedMethodsHaveUniqueStartAndResultEvents=True,freshRuntimeXmlAvailable=False,staleDiscoveryXmlRejected=18,normalCollectorRefusedStaleXml=True,finalJUnitReportedCounts='NOT_CLAIMED',completeSuite=False,scopesNotSummed=True,lintCachedResult=lint,apkIdentityAndSignature='NO APK assembled/installed/signed in this phase',sourceBindings='PENDING',all59Findings='OPEN',physicalAcceptance='OUTSTANDING_LAST',exclusions=ctx['exclusions'],provisionalJvmDirectiveAdopted=False,provisionalJvmDirectiveIsTestExclusion=False,nativeRootCause='UNCONFIRMED',resourceDiagnosis='Large full-pack assertion messages observed. Exact heap allocation/report phase UNCONFIRMED; cgroup oom/oom_kill counters zero at observation.')
(D/'INCOMPLETE_RESULT.json').write_text(json.dumps(meta,indent=2)+'\n');shutil.copy2(W/'DISCOVERY/RESULT.json',D/'DISCOVERY_RESULT.json')
(D/'OUTCOME.md').write_text(f'''# Foundational-history regression stopped without final runtime reports

Actual source`{source}` emitted112unique expected result events across18selected classes:74SUCCESS/38FAILURE. Gradle then exited1 with`Java heap space`; no fresh runtime XML/final normal result was produced. The collector correctly rejected18stale dry-run XML files. This is **INCOMPLETE verification**, not a completed112-test suite or a reported74-pass result. Full original messages/events/logs/partial binary output are retained in four CRC/memberSHA-verified raw archives; JSON/CSV previews are derived indices only. CgroupOOM/OOMkill counters were zero; the exact heap-allocation phase remains unconfirmed. Visible oversized full-pack assertion messages are a reporting-resource hypothesis, distinct from the unconfirmed SQLite native issue.

Fresh discovery112synthetic skips/zero actual passes had matched the predicted method set. Underlying runtime start/result identities match those112exact methods; lack of final runtime XML remains explicit. Cached lint{lint}, compileDebugSources and release-gate attachment completed under --continue; preserve their actual task dispositions in the raw log. NoAPKassembled/installed/signed/no newAPKidentity/signature.

All290testfiles, main/catalog/content,155bindings,87archives and earlier failures remain unchanged. Failures concern changed foundation credit and old whole-pack historical assumptions; classify each from actual source before changing fixtures. Do not alter production eligibility or lower counters to satisfy old snapshots. Preserve original assertions/pins with explicit authentic historical models; retain actual-current controls and add current raw-history/runtime coverage. Source packages remainpending.

A separate unchanged V2Rebuild24-method class is planned because code inspection found explicit Unit1/2digestpins outside the static61candidate inventory. It has not executed at this checkpoint; keep future results separate. All59findingsOPEN/auditINCOMPLETE. Four screenshot exporters16methods excluded. ProvisionalSQLiteJITdirectiveunadopted/notatestexclusion/nativecauseUNCONFIRMED. Final independent comprehensive audit then physicalGalaxyS26Ultra airplane-mode/rebootLAST;no merge/freeze/releaseapproval.
''')
for p,prefix in [(R/'AGENTS.md','audit/gpt61-sol-high-comprehensive-2026-10-19/'),(R/'audit/content-corrections/CODEX_ENGINEERING_CONTINUATION.md','../gpt61-sol-high-comprehensive-2026-10-19/'),(R/'audit/content-corrections/CODEX_CHECKPOINT_2026-10-12.md','../gpt61-sol-high-comprehensive-2026-10-19/')]:p.write_text(f'Current checkpoint: [Foundational-history incomplete runtime preserved]({prefix}{D.name}/OUTCOME.md).Actual86e71758:112events/74SUCCESS/38FAILURE;GradleJavaheapspace/exit1/no freshfinalXML/18stalediscoveryXMLrejected. NOT a completed112-test result.290tests/content/155bindings/87archives conserved. Raw4archives/index retainfullmessages/binary. SeparateV2Rebuild24baselineprepared,notyetexecuted;inspect external literacy-foundation-mapping-baseline-2026-10-29. All59OPEN/four exporters16excluded/final audit then physicalLAST/noAPK/signing/merge/freeze/approval.\n\n'+p.read_text())
(D/'SHA256.json').write_text(json.dumps({p.name:sha(p) for p in D.iterdir() if p.is_file() and p.name!='SHA256.json'},indent=2)+'\n')
print(json.dumps(meta),flush=True)
