from pathlib import Path
import hashlib,json,zipfile
W=Path(__file__).parent;D=Path('/workspace/russian-companion/audit/gpt61-sol-high-comprehensive-2026-10-19/engineering-unit13-present-baseline-2026-10-27')
p=W/'persist_baseline.py';original=p.read_text();old="assert answers[0]['assignmentDigest']==a['digest'] and answers[0]['schema']==6"
assert original.count(old)==1
note=dict(kind='EVIDENCE_CHECKER_ERROR_NOT_APP_TEST_FAILURE',originalScriptSha256=hashlib.sha256(original.encode()).hexdigest(),originalFailingLine=old,actualAssignmentSchema=6,actualAnswerRecordSchema=1,backupFormatVersion=3,documentSchemaVersion=3,source='V2CumulativeReview.kt CUMULATIVE_REVIEW_SCHEMA=1 and answer validation lines754/777',change='Check answer schema1 independently of assignment schema6; preserve initial checker failure and raw evidence',newJUnitRuns=0,newGradleTasks=0)
with zipfile.ZipFile(D/'COLLECTOR_PRECHECK_1.zip','x',zipfile.ZIP_DEFLATED) as z:
 z.writestr('ORIGINAL_persist_baseline.py',original);z.writestr('ERROR.json',json.dumps(note,indent=2)+'\n')
(D/'COLLECTOR_PRECHECK_1.json').write_text(json.dumps(note,indent=2)+'\n')
fixed=original.replace(old,"assert answers[0]['assignmentDigest']==a['digest'] and answers[0]['schema']==1")
fixed=fixed.replace('backupFormatVersion=manifest[\'formatVersion\'],documentSchemaVersion=document[\'schemaVersion\'],recordingCount=0','backupFormatVersion=manifest[\'formatVersion\'],documentSchemaVersion=document[\'schemaVersion\'],answerRecordSchema=1,recordingCount=0')
fixed=fixed.replace('Backup format3 is distinct from assignment schema6.', 'Backup format3/document schema3, assignment schema6 and answer-record schema1 are separate identities.')
fixed=fixed.replace('Next large task: versioned Unit13v3/schema15 implementation from NEXT_TASK.md', 'Evidence-checker correction: initial collector incorrectly equated answer-record schema with assignment schema6. Actual answer schema1 is required by CUMULATIVE_REVIEW_SCHEMA; original checker/error are archived in COLLECTOR_PRECHECK_1.zip. Raw app outcomes/capture unchanged; no rerun.\n\nNext large task: versioned Unit13v3/schema15 implementation from NEXT_TASK.md')
p.write_text(fixed)
# Resume only after confirming the already-written raw evidence and identity. Never overwrite it.
import subprocess,xml.etree.ElementTree as ET,re,shutil
R=Path('/workspace/russian-companion');sha=lambda b:hashlib.sha256(b).hexdigest();git=lambda *a:subprocess.check_output(['git',*a],cwd=R,text=True).strip()
from datetime import datetime
from zoneinfo import ZoneInfo
prep=json.loads((D/'PREPARATION.json').read_text());base=prep['baselineSourceCommit']
c=json.loads((W/'REGRESSION/CONTEXT.json').read_text());r=json.loads((W/'REGRESSION/RESULT.json').read_text());S=c['sourceCommit'];assert git('rev-parse','HEAD')==S
assert all(x[3:].startswith(D.relative_to(R).as_posix()+'/') for x in git('status','--porcelain').splitlines())
with zipfile.ZipFile(D/'RAW_BASELINE.zip') as z:
 assert z.testzip() is None
 for f in json.loads((D/'RAW_BASELINE_INDEX.json').read_text()):assert sha(z.read(f['path']))==f['sha256'] and len(z.read(f['path']))==f['bytes']
cap=W/'REGRESSION/CAPTURE';identity=json.loads((D/'CAPTURE_IDENTITY.json').read_text());archive=D/'BASELINE_CURRENT_UNIT13_V2.zip'
assert archive.read_bytes()==(cap/'PARTIAL_UNIT13_V2.zip').read_bytes() and identity['producerCommit']==S
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 members=[dict(path=i.filename,bytes=i.file_size,crc32=f'{i.CRC:08x}',sha256=sha(z.read(i.filename))) for i in z.infolist()]
 manifest=json.loads(z.read('manifest.json'));document=json.loads(z.read('learner.json'))
a=next(x for x in document['reviewAssignments'] if x['targetUnit']==13);answers=[x for x in document['reviewAnswers'] if x['assignmentId']==a['id']]
assert a['schema']==6 and answers[0]['schema']==1 and len(answers)==1 and answers[0]['slotIndex']==0
assert a['policyDigest']=='7e5076dfb0def9c62d25787335555bd93136b98b2bf1c0d823a58cc1830a1a26'
assert a['slots'][1]['unitDigest']=='8c3ae9bbd682e069dbcd4dc579c30af36bbce321120ce7da804260e5a44d7033'
assert a['slots'][2]['unitDigest']=='1d4c25c25e20b7fb6629995fcfb66e29f02554e276c5a7f5ec69fb5ac0a2ca5c'
positive='actualCurrentV2PartialTaskRoundtripsReopensAndCompletesItsOwnObligation';negative='priorPrintAspectAndPastAnswersCannotReplaceFreshAssignedPresentAnswer';by={t['method']:t for t in r['tests']}
def save(n,v):(D/n).write_text(json.dumps(v,indent=2)+'\n')
__file__=str(p)
exec(compile(fixed[fixed.index("assert answers[0]['assignmentDigest']"):],str(p),'exec'),globals())
