from pathlib import Path
import json,zipfile,hashlib
W=Path(__file__).parent;D=Path('/workspace/russian-companion/audit/gpt61-sol-high-comprehensive-2026-10-19/engineering-unit13-present-baseline-2026-10-27');p=W/'persist_baseline.py';original=p.read_text()
old="archives=[p for p in protected if p.endswith('.zip')];assert len(archives)==73"
assert old in original
note=dict(kind='EVIDENCE_CHECKER_SCOPE_ERROR_NOT_APP_TEST_FAILURE',originalScriptSha256=hashlib.sha256(original.encode()).hexdigest(),originalFailingLine=old,actualProtectedZipFiles=85,declaredHistoricalArchiveScope=73,additionalProtectedDiagnosticZipFiles=12,change='Use explicit 73-archive inventory, retain hashes for all838 protected files; no app/test or raw result change',newJUnitRuns=0,newGradleTasks=0)
with zipfile.ZipFile(D/'COLLECTOR_PRECHECK_2.zip','x',zipfile.ZIP_DEFLATED) as z:z.writestr('ORIGINAL_persist_baseline.py',original);z.writestr('ERROR.json',json.dumps(note,indent=2)+'\n')
(D/'COLLECTOR_PRECHECK_2.json').write_text(json.dumps(note,indent=2)+'\n')
fixed=original.replace(old,"history=json.loads((R/'audit/gpt61-sol-high-comprehensive-2026-10-19/engineering-unit13-substantive-research-2026-10-27/HISTORICAL_UNIT13_UNIT14_INVENTORY.json').read_text())\narchiveHashes={x['path']:x['sha256'] for x in history['archives']};assert len(archiveHashes)==73\nassert all(protected[p]==h for p,h in archiveHashes.items())\nsave('PRIOR_ARCHIVE_HASHES.json',archiveHashes)\narchives=list(archiveHashes)")
oldWrite="with zipfile.ZipFile(D/'ORIGINAL_BASELINE_TEST.zip','x',zipfile.ZIP_DEFLATED) as z:z.write(R/prep['newTestFile'],prep['newTestFile'])"
fixed=fixed.replace(oldWrite,"if (D/'ORIGINAL_BASELINE_TEST.zip').exists():\n with zipfile.ZipFile(D/'ORIGINAL_BASELINE_TEST.zip') as z:assert sha(z.read(prep['newTestFile']))==prep['newTestSha256']\nelse:\n "+oldWrite)
fixed=fixed.replace('priorArchivesShaCrc=73,currentBindingsUnchanged=155','priorArchivesShaCrc=73,additionalProtectedDiagnosticZipFiles=12,currentBindingsUnchanged=155')
fixed=fixed.replace('Raw app outcomes/capture unchanged; no rerun.', 'A second collector scope assumption counted all85 protected ZIPs as the73 declared historical archives; COLLECTOR_PRECHECK_2.zip preserves the error. The checker now uses the explicit73-entry archive inventory and retains hashes for12 additional diagnostic ZIPs. Raw app outcomes/capture unchanged; no rerun.')
p.write_text(fixed)
v=W/'verify_saved_results.py';t=v.read_text().replace("archives=[p for p in protected if p.endswith('.zip')];assert len(archives)==73", "archiveHashes=read('PRIOR_ARCHIVE_HASHES.json');archives=list(archiveHashes);assert len(archives)==73\nassert all(protected[p]==h for p,h in archiveHashes.items())")
t=t.replace("assert {x['slotIndex'] for x in cap['partialAnswers']}=={0}","assert {x['slotIndex'] for x in cap['partialAnswers']}=={0}\n assert cap['answerRecordSchema']==1 and all(x['schema']==1 for x in cap['partialAnswers'])")
v.write_text(t)
# Re-check the saved raw bundle before resuming immutable-evidence collection.
resume=(W/'resume_collection.py').read_text();prefix=resume[resume.index('import subprocess,xml.etree.ElementTree'):resume.index('__file__=str(p)')]
exec(compile(prefix,str(W/'resume_collection.py'),'exec'),globals())
__file__=str(p)
exec(compile(fixed[fixed.index("assert answers[0]['assignmentDigest']"):],str(p),'exec'),globals())
