from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,traceback
R=Path('/workspace/russian-companion');W=Path(__file__).parent;source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert not subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True).strip();rows=[]
try:
 for script in ['prepare_generate.py','generate.py','review_proposal.py']:
  start=datetime.now(timezone.utc).isoformat()
  with (W/(script+'.log')).open('x') as out:p=subprocess.run(['python3',str(W/script)],cwd=R,stdout=out,stderr=subprocess.STDOUT)
  rows.append(dict(command=['python3',str(W/script)],startedUtc=start,finishedUtc=datetime.now(timezone.utc).isoformat(),exitCode=p.returncode));(W/'PIPELINE_COMMANDS.json').write_text(json.dumps(rows,indent=2)+'\n');assert p.returncode==0,(script,p.returncode)
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True).strip();(W/'GENERATION_PIPELINE_COMPLETION.json').write_text(json.dumps(dict(sourceCommit=source,completedUtc=datetime.now(timezone.utc).isoformat(),exitCode=0,proposalExists=(W/'PROPOSAL_REVIEW.json').exists(),trackedFilesEdited=False,JUnitMethodsExecuted=0),indent=2)+'\n')
except BaseException:
 (W/'GENERATION_PIPELINE_ERROR.json').write_text(json.dumps(dict(sourceCommit=source,atUtc=datetime.now(timezone.utc).isoformat(),traceback=traceback.format_exc(),commands=rows),indent=2)+'\n');raise
