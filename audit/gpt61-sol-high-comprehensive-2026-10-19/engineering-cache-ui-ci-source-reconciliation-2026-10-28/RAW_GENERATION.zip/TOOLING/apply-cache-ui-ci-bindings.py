from pathlib import Path
import json,hashlib,subprocess,zipfile,shutil
R=Path('/workspace/russian-companion');W=Path('/workspace/artifacts/cache-ui-ci-source-bindings-2026-10-28');B=R/'audit/gpt61-sol-high-comprehensive-2026-10-19';D=B/'engineering-cache-ui-ci-source-reconciliation-2026-10-28';CI=Path('/workspace/artifacts/verification-only-ci-2026-10-28');CID=B/'engineering-verification-only-ci-2026-10-28'
sha=lambda b:hashlib.sha256(b).hexdigest();read=lambda p:json.loads(p.read_text());save=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n');git=lambda *a:subprocess.check_output(['git',*a],cwd=R).decode().strip()
assert not subprocess.check_output(['git','status','--porcelain=v1','-z','--untracked-files=all'],cwd=R);ctx=read(W/'GENERATION_PREPARATION.json');review=read(W/'PROPOSAL_REVIEW.json');assert git('rev-parse','HEAD')==ctx['sourceCommit']==review['sourceCommit'];D.mkdir()
prior=read(B/'engineering-unit14-source-reconciliation-2026-10-28/APPLIED_RECORDS.json');archives=read(B/'engineering-unit14-source-reconciliation-2026-10-28/CONSERVATION.json')['archives'];tests={p.relative_to(R).as_posix():sha(p.read_bytes())for p in(R/'app/src/test').rglob('*')if p.is_file()};assert len(tests)==284
for n,h in prior['currentRecordHashes'].items():assert sha((R/n).read_bytes())==h,n
for n,h in archives.items():
 assert sha((R/n).read_bytes())==h
 with zipfile.ZipFile(R/n)as z:assert z.testzip()is None
protected={}
for folder in ['engineering-ui-feedback-onboarding-baseline-2026-10-28','engineering-ui-refined-baseline-2026-10-28','engineering-ui-feedback-onboarding-correction-2026-10-28','engineering-unit-identity-cache-baseline-2026-10-28','engineering-unit-identity-cache-correction-2026-10-28','engineering-unit14-downstream-fixture-followup-2026-10-28','engineering-unit14-broad-host-regression-2026-10-28']:
 for p in(B/folder).rglob('*'):
  if p.is_file():protected[p.relative_to(R).as_posix()]=sha(p.read_bytes())
ix={}
with zipfile.ZipFile(D/'HISTORICAL_PRIOR_CURRENT.zip','x',zipfile.ZIP_DEFLATED)as z:
 for row in review['files']:
  rel=row['path'];data=(R/rel).read_bytes();assert sha(data)==row['oldSha256']and sha((W/'PROPOSAL'/rel).read_bytes())==row['newSha256']
  if row['changed']:z.writestr(rel,data);ix[rel]={'bytes':len(data),'sha256':sha(data),'sourceCommit':ctx['sourceCommit'],'gitBlob':row['originalGitBlob'],'historical':True}
assert len(ix)==95;save(D/'HISTORICAL_PRIOR_CURRENT_INDEX.json',ix)
def archive(dest,files):
 index={}
 with zipfile.ZipFile(dest,'x',zipfile.ZIP_DEFLATED)as z:
  for n,p in sorted(files.items()):
   assert not n.lower().endswith('.pdf');data=p.read_bytes();z.writestr(n,data);index[n]={'bytes':len(data),'sha256':sha(data)}
 with zipfile.ZipFile(dest)as z:
  assert z.testzip()is None and set(z.namelist())==set(index)
  for n,v in index.items():assert sha(z.read(n))==v['sha256']and len(z.read(n))==v['bytes']
 save(dest.with_name(dest.stem+'_INDEX.json'),index)
files={}
for folder in ['CANDIDATE_1','CANDIDATE_2','PROPOSAL']:
 for p in(W/folder).rglob('*'):
  if p.is_file():files[p.relative_to(W).as_posix()]=p
for p in W.iterdir():
 if p.is_file():files['TOOLING/'+p.name]=p
files['INPUT_PROJECTION/release/acceptance/candidate.json']=W/'INPUT_PROJECTION/release/acceptance/candidate.json';files['TOOLING/generate-cache-ui-ci-bindings.py']=Path('/workspace/artifacts/generate-cache-ui-ci-bindings.py');files['TOOLING/apply-cache-ui-ci-bindings.py']=Path(__file__);archive(D/'RAW_GENERATION.zip',files)
for n in ['CONTEXT.json','GENERATION_PREPARATION.json','COMMAND_RESULTS.json','PROPOSAL_REVIEW.json']:shutil.copyfile(W/n,D/n)
for row in review['files']:
 if row['changed']:shutil.copyfile(W/'PROPOSAL'/row['path'],R/row['path'])
for n,h in tests.items():assert sha((R/n).read_bytes())==h
for n,h in protected.items():assert sha((R/n).read_bytes())==h
for n,h in archives.items():assert sha((R/n).read_bytes())==h
args=['/workspace/jdk21/bin/java','-cp',ctx['classpath'],'Digest',str(R)];p=subprocess.run(args,cwd=R,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);(D/'AFTER_APPLY_DIGEST.log').write_text(p.stdout);assert p.returncode==0 and ctx['newRepositorySourceDigest']in p.stdout.splitlines()
save(D/'CONSERVATION.json',{'sourceBeforeApply':ctx['sourceCommit'],'testHashes':tests,'archives':archives,'protectedEvidenceHashes':protected,'priorCurrentRecordHashes':prior['currentRecordHashes'],'currentRecordHashes':{r['path']:r['newSha256']for r in review['files']},'all30CurriculumSourceChoicesUnchanged':True,'unitPackReviewPackageMappingDigestsUnchanged':True,'repositorySourceDigest':ctx['newRepositorySourceDigest'],'packContentReviewDigest':json.loads((R/'review/unit-14/UNIT_14_REVIEW_MANIFEST.json').read_text())['packContentReviewDigest'],'historicalPriorVersions':95,'learnerArchives':77,'generationJUnitMethodsExecuted':0,'bindings':'CURRENT_ENGINEERING_RECONCILED_RUNTIME_PENDING','all48Findings':'OPEN','audit':'INCOMPLETE'})
# CI evidence is independent configuration/discovery only; no tests executed by it.
ciresult=read(CI/'RESULT.json');assert ciresult['discoveredSyntheticSkips']==1508 and ciresult['runtimePasses']==0
files={p.relative_to(CI).as_posix():p for p in CI.rglob('*')if p.is_file()};files['TOOLING/verify-ci-configuration.py']=Path('/workspace/artifacts/verify-ci-configuration.py');files['TOOLING/verify-ci-post-run.py']=Path('/workspace/artifacts/verify-ci-post-run.py');archive(CID/'RAW_CONFIGURATION_VERIFICATION.zip',files)
for n in ['CONTEXT.json','COMMAND_RESULTS.json','RESULT.json','INITIAL_CONSERVATIVE_GRAPH_CHECK_REFUSAL.json']:shutil.copyfile(CI/n,CID/n)
(CID/'COMPLETED_CONFIGURATION_CHECK.md').write_text('''# Local verification-only CI configuration checked

At0694fa730c3f768f53716ab55b1bd60a5f4201ff the exact workflow exporter-exclusion script was extracted and applied locally. Task graph contains no application APK assemble/package/sign/install/publish task. AGP resource packaging, class JAR bundles and local-test resource fixtures remain required compilation/test intermediates; the first overly broad prefix check rejected these and its refinement is retained. Both Gradle commands exited0. Fresh discovery contains1508synthetic skips across264classes,zero runtime passes; all four exporters/16methods absent. No actual CI execution/pass, APK assembly/install/newsigning or qualified acceptance is claimed. GitHub Actions budget still blocks runner assignment. Official expected wrapper checksum pinned; cached installed distribution archive has not been independently hashed. Provisional SQLite JIT directive not adopted by workflow.
''')
(D/'STATUS.md').write_text(f'''# Cache, UI and CI source bindings reconciled

Actual compiled generation source `{ctx['sourceCommit']}` observed repository source digest `{ctx['newRepositorySourceDigest']}`. Two fresh JVM renders match153files each and validate all30packages each. Exactly95of155current records change only the repository source-digest token;60worksheets remain byte-exact. All30curriculum source choices, pack/unit/review-package/mapping digests, source/rights/reviewer/owner/admission/approval fields remain unchanged. All95priorversions and Gitblobidentities archived as historical.284testfiles,77learnerarchives and all previous failures/raw evidence conserved. Candidate stays unfrozen/sourceCommitnull/artifactNOT_RECORDED/publicReleaseNOT_APPROVED. Source reconciliation is engineering bookkeeping, not independent acceptance. Generation executes zeroJUnitmethods. Runtime on reconciled inputs still pending.

Separate UI scopeff450b72:62/62passed;cache341444a1:25/25passed;initial/refined6methodbaselines each1pass/5fail preserved. No scopes summed. Local CI configuration discovery1508synthetic skips is zero runtime passes. Next fresh broad selected-host discovery/runtime must include all119previousfollow-up IDs,allcurrentcontrols and all284tests as applicable;retain exactly four exporters16methods exclusions. All48findingsOPEN/auditINCOMPLETE;finalindependentcomprehensiveClaudeaudit before physicalGalaxyS26Ultra airplane-mode/reboot acceptanceLAST. NoAPKassembly/install/newsigning/merge/freeze/formalreleaseapproval. Privatebookunread/unpackaged;environmentunchanged/publicationuser-confirmedindependentlyunobserved;SQLiteJITdirectiveunadopted/nativecauseUNCONFIRMED.
''')
for n in ['AGENTS.md','audit/content-corrections/CODEX_ENGINEERING_CONTINUATION.md','audit/content-corrections/CODEX_CHECKPOINT_2026-10-12.md']:
 p=R/n;rel=D.relative_to(R).as_posix()+'/STATUS.md';link=rel if n=='AGENTS.md'else'../'+rel.removeprefix('audit/')
 p.write_text(f'Current checkpoint: [Cache/UI/CI authentic source bindings reconciled]({link}).Two153renders/30packages/95repository-identity-only changes/60unchanged/95priorversionshistorical;284tests/77archives/rawfailures unchanged;all30curriculumsourcechoices/contentdigests retained. BindingsCURRENT_ENGINEERING_RECONCILED_RUNTIME_PENDING. Next fresh broaddiscovery/runtime includingall119 IDs;zeroactualtestsfromgeneration/CIconfiguration1508syntheticskips. Codex only;all48OPEN/auditINCOMPLETE/four exporters16excluded/physicalLAST/noAPK/signing/merge/freeze/approval.\n\n'+p.read_text())
for directory in [D,CID]:save(directory/'SHA256.json',{p.relative_to(directory).as_posix():sha(p.read_bytes())for p in sorted(directory.rglob('*'))if p.is_file()and p!=directory/'SHA256.json'})
allowed={r['path']for r in review['files']if r['changed']}|{'AGENTS.md','audit/content-corrections/CODEX_ENGINEERING_CONTINUATION.md','audit/content-corrections/CODEX_CHECKPOINT_2026-10-12.md'}
for row in subprocess.check_output(['git','status','--porcelain=v1','-z','--untracked-files=all'],cwd=R).decode().split('\0'):
 if row:assert row[3:]in allowed or row[3:].startswith(str(D.relative_to(R))+'/')or row[3:].startswith(str(CID.relative_to(R))+'/'),row
subprocess.run(['git','add',*allowed,str(D),str(CID)],cwd=R,check=True);subprocess.run(['git','diff','--cached','--check'],cwd=R,check=True);subprocess.run(['git','commit','-m','Reconcile cache UI and CI source bindings with authentic renders'],cwd=R,check=True)
print(json.dumps({'applied':95,'unchanged':60,'preservedTests':284,'preservedLearnerArchives':77,'sourceDigest':ctx['newRepositorySourceDigest']}))
