from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,shutil,hashlib,re
R=Path('/workspace/russian-companion');W=Path('/workspace/artifacts/cache-ui-ci-source-bindings-2026-10-28');OLD=Path('/workspace/artifacts/unit14-source-reconciliation-2026-10-28');W.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();save=lambda n,v:(W/n).write_text(json.dumps(v,indent=2)+'\n');git=lambda *a:subprocess.check_output(['git',*a],cwd=R).decode().strip();assert not subprocess.check_output(['git','status','--porcelain=v1','-z','--untracked-files=all'],cwd=R)
context={'sourceCommit':git('rev-parse','HEAD'),'inputTrees':{n:git('rev-parse','HEAD:'+n)for n in ['app/src/main','app/src/test','catalog','docs','review','release']},'startedUtc':datetime.now(timezone.utc).isoformat(),'JUnitMethodsExecuted':0};save('CONTEXT.json',context);commands=[]
def run(label,args,gradle=False):
 start=datetime.now(timezone.utc).isoformat()
 with(W/(label+'.log')).open('x')as out:p=subprocess.run(['bash','-c','source /workspace/setup/android-env.sh;exec ./gradlew "$@"','binding-compile',*args]if gradle else args,cwd=R,stdout=out,stderr=subprocess.STDOUT)
 commands.append({'label':label,'command':['./gradlew',*args]if gradle else args,'startedUtc':start,'finishedUtc':datetime.now(timezone.utc).isoformat(),'exitCode':p.returncode});save('COMMAND_RESULTS.json',commands);assert p.returncode==0,label
 return(W/(label+'.log')).read_text()
run('COMPILE_CURRENT_SOURCE',['compileDebugUnitTestKotlin','--offline','--max-workers=2','--console=plain'],True)
base=json.loads((OLD/'GENERATION_PREPARATION.json').read_text());cp=base['classpath'].replace(str(OLD),str(W),1)
for n in ['Digest.java','GeneratePendingEvidence.java']:shutil.copyfile(OLD/n,W/n)
run('DIGEST_COMPILE',['/workspace/jdk21/bin/javac','-cp',cp,str(W/'Digest.java')]);out=run('DIGEST',['/workspace/jdk21/bin/java','-cp',cp,'Digest',str(R)]);values=re.findall(r'(?m)^[0-9a-f]{64}$',out);assert len(values)==1;digest=values[0]
old=json.loads((R/'release/acceptance/candidate.json').read_text());oldDigest=old['sourceDigest'];assert oldDigest=='487d9118d7154dd59162dbb7024f1349bc53d5b7bf89e9d79022d97eaa1eeb9a'and digest!=oldDigest
P=W/'INPUT_PROJECTION';P.mkdir()
for p in(OLD/'INPUT_PROJECTION').iterdir():
 if p.name=='release':shutil.copytree(R/'release',P/'release')
 else:(P/p.name).symlink_to(R/p.name,target_is_directory=(R/p.name).is_dir())
assert not(P/'.git').exists();original=(R/'release/acceptance/candidate.json').read_bytes();assert original.count(oldDigest.encode())==1;(P/'release/acceptance/candidate.json').write_bytes(original.replace(oldDigest.encode(),digest.encode()))
indexes=[]
for i,folder in enumerate([x for x in cp.split(':')if Path(x).is_dir()and '/app/build/'in x],1):
 root=Path(folder);index={p.relative_to(root).as_posix():sha(p)for p in sorted(root.rglob('*'))if p.is_file()};save(f'COMPILED_INDEX_{i}.json',index);indexes.append({'directory':folder,'files':len(index),'indexSha256':sha(W/f'COMPILED_INDEX_{i}.json')})
ctx={**context,'classpath':cp,'oldRepositorySourceDigest':oldDigest,'newRepositorySourceDigest':digest,'actualCurriculumChangeCommitRetained':'d72afd1232857a857624c20c58f4bcd3cb5c8564','engineeringChanges':['341444a1744cbc6a9cdb711671bd7f99c31669cf','ff450b7215d5f7ab24f7e9b10d7b831430e5af82',context['sourceCommit']],'compiledDirectories':indexes,'dependencyJarHashes':{p:sha(Path(p))for p in cp.split(':')if p.endswith('.jar')},'generatorSha256':sha(W/'GeneratePendingEvidence.java'),'rawCurriculumSHA256':sha(R/'app/src/main/assets/content/v2-curriculum.json'),'privateReferenceRead':False};save('GENERATION_PREPARATION.json',ctx)
run('GENERATOR_COMPILE',['/workspace/jdk21/bin/javac','-cp',cp,str(W/'GeneratePendingEvidence.java')])
for n in [1,2]:run('RENDER_'+str(n),['/workspace/jdk21/bin/java','-Xmx2g','-cp',cp,'GeneratePendingEvidence',str(P),str(W/f'CANDIDATE_{n}'),digest,str(R)])
a,b=W/'CANDIDATE_1',W/'CANDIDATE_2';paths=sorted(p.relative_to(a).as_posix()for p in a.rglob('*')if p.is_file());assert len(paths)==153 and paths==sorted(p.relative_to(b).as_posix()for p in b.rglob('*')if p.is_file())
O=W/'PROPOSAL';O.mkdir();rows=[]
for rel in paths:
 data=(a/rel).read_bytes();assert data==(b/rel).read_bytes();dest=O/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
extra={'release/acceptance/candidate.json':(P/'release/acceptance/candidate.json').read_bytes()};rel='audit/curriculum-readiness/V2_CURRICULUM_GAP_CLOSURE_DOSSIER_v1.0.md';data=(R/rel).read_bytes();assert data.count(oldDigest.encode())==1;extra[rel]=data.replace(oldDigest.encode(),digest.encode())
for rel,data in extra.items():dest=O/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
for rel in sorted(paths+list(extra)):
 before=(R/rel).read_bytes();after=(O/rel).read_bytes();assert after==before.replace(oldDigest.encode(),digest.encode()),('Unexpected non-repository-identity delta',rel)
 if rel.endswith('_WORKSHEET.tsv'):assert before==after
 if rel.endswith('_REVIEW_MANIFEST.json'):
  oldM=json.loads(before);newM=json.loads(after);assert oldM['curriculumSourceCommit']==newM['curriculumSourceCommit'];assert {k for k in oldM if oldM[k]!=newM[k]}=={'repositorySourceDigest'}
 rows.append({'path':rel,'changed':before!=after,'oldSha256':hashlib.sha256(before).hexdigest(),'newSha256':hashlib.sha256(after).hexdigest(),'oldBytes':len(before),'newBytes':len(after),'originalGitBlob':git('rev-parse',context['sourceCommit']+':'+rel)})
assert len(rows)==155 and sum(x['changed']for x in rows)==95
candidate=json.loads((O/'release/acceptance/candidate.json').read_text());assert not candidate['frozen']and candidate['sourceCommit']is None and candidate['publicRelease']=='NOT_APPROVED'
save('PROPOSAL_REVIEW.json',{'sourceCommit':context['sourceCommit'],'oldRepositorySourceDigest':oldDigest,'newRepositorySourceDigest':digest,'twoFreshRendersIdentical':True,'renderedFiles':153,'proposedFiles':155,'changedFiles':95,'unchangedFiles':60,'onlyRepositorySourceDigestTokenChanges':True,'all30CurriculumSourceChoicesUnchanged':True,'allPackUnitReviewPackageMappingDigestsUnchanged':True,'allReviewerOwnerRightsSourceAdmissionApprovalFieldsUnchanged':True,'JUnitMethodsExecuted':0,'files':rows});assert not subprocess.check_output(['git','status','--porcelain=v1','-z','--untracked-files=all'],cwd=R)
print(json.dumps({'sourceCommit':context['sourceCommit'],'newRepositorySourceDigest':digest,'changed':95,'unchanged':60,'trackedFilesApplied':False}))
