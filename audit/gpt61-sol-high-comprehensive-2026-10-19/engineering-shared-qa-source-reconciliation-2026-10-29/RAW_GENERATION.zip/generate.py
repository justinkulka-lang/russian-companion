from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,hashlib,shutil,re,zipfile
R=Path('/workspace/russian-companion');W=Path(__file__).parent;P=Path('/workspace/artifacts/cache-ui-ci-source-bindings-2026-10-28');D=R/'audit/gpt61-sol-high-comprehensive-2026-10-19/engineering-b01-b02-shared-diagnostics-2026-10-29'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=R,text=True).strip()
now=lambda:datetime.now(timezone.utc).isoformat()
save=lambda name,value:(W/name).write_text(json.dumps(value,indent=2)+'\n')
assert not subprocess.check_output(['git','status','--porcelain=v1','-z','--untracked-files=all'],cwd=R)
source=git('rev-parse','HEAD');trees={p:git('rev-parse','HEAD:'+p) for p in ['app/src/main','app/src/test','catalog','docs','review','release']}
con=json.loads((D/'CONSERVATION.json').read_text());old='b64b6ab8e57eef7f08ea7a603f10cd5d635c930e4c2445783c0698657dd16125'
protected={**con['protectedEvidenceHashes'],**con['existingTestHashes']}
for name in ['app/src/test/java/dev/russiancompanion/v2/CurriculumDesignDiagnosticsTest.kt']:protected[name]=sha(R/name)
for p,h in protected.items():assert sha(R/p)==h,p
save('CONTEXT.json',dict(sourceCommit=source,inputTrees=trees,startedUtc=now(),oldRepositorySourceDigest=old,all59Findings='OPEN',audit='INCOMPLETE',sourceBindings='PENDING',JUnitMethodsExecuted=0,privateReferenceRead=False,protectedEvidenceHashes=protected,currentRecordHashes=con['currentRecordHashes'],archives=con['archives']))
commands=[]
def run(label,args):
 started=now()
 with (W/(label+'.log')).open('x') as out:p=subprocess.run(args,cwd=R,stdout=out,stderr=subprocess.STDOUT)
 commands.append(dict(label=label,command=args,startedUtc=started,finishedUtc=now(),exitCode=p.returncode));save('COMMAND_RESULTS.json',commands)
 assert p.returncode==0,(label,p.returncode)
run('COMPILE_CURRENT_SOURCE',['bash','-c','source /workspace/setup/android-env.sh; exec ./gradlew compileDebugUnitTestKotlin --offline --max-workers=2 --console=plain'])
cp=json.loads((P/'GENERATION_PREPARATION.json').read_text())['classpath'].replace(str(P),str(W))
for path in cp.split(':'):assert Path(path).exists(),path
for f in ['Digest.java','GeneratePendingEvidence.java']:shutil.copy2(P/f,W/f)
for name in ['Digest','GeneratePendingEvidence']:run(name+'_COMPILE',['/workspace/jdk21/bin/javac','-cp',cp,str(W/(name+'.java'))])
run('DIGEST',['/workspace/jdk21/bin/java','-cp',cp,'Digest',str(R)])
digests=re.findall(r'(?m)^([a-f0-9]{64})$',(W/'DIGEST.log').read_text());assert len(digests)==1;new=digests[0];assert new!=old
indexes={}
for part in cp.split(':'):
 p=Path(part)
 if p.is_dir() and p!=W:
  index={f.relative_to(p).as_posix():sha(f) for f in sorted(p.rglob('*')) if f.is_file()};indexes[part]=index
save('COMPILED_INDEX.json',indexes)
projection=W/'INPUT_PROJECTION';projection.mkdir()
for child in R.iterdir():
 if child.name in ['.git','release']:continue
 (projection/child.name).symlink_to(child,target_is_directory=child.is_dir())
shutil.copytree(R/'release',projection/'release')
candidate=projection/'release/acceptance/candidate.json';current=candidate.read_text();assert old in current;candidate.write_text(current.replace(old,new))
proposedCandidate=json.loads(candidate.read_text());assert proposedCandidate['frozen']==False and proposedCandidate['sourceCommit'] is None and proposedCandidate['publicRelease']=='NOT_APPROVED' and proposedCandidate['artifact']['status']=='NOT_RECORDED',proposedCandidate
save('GENERATION_PREPARATION.json',dict(sourceCommit=source,inputTrees=trees,classpath=cp,oldRepositorySourceDigest=old,newRepositorySourceDigest=new,rawCurriculumSha256=con['packAssetSha256'],projectionCandidateSha256=sha(candidate),generatorSha256=sha(W/'GeneratePendingEvidence.java'),digestProbeSha256=sha(W/'Digest.java'),dependencyJarHashes={p:sha(Path(p)) for p in cp.split(':') if Path(p).is_file()},compiledIndexSha256=sha(W/'COMPILED_INDEX.json'),JUnitMethodsExecuted=0,privateReferenceRead=False))
for n in [1,2]:run('RENDER_'+str(n),['/workspace/jdk21/bin/java','-Xmx2g','-cp',cp,'GeneratePendingEvidence',str(projection),str(W/('CANDIDATE_'+str(n))),new,str(R)])
first=W/'CANDIDATE_1';second=W/'CANDIDATE_2';rendered={p.relative_to(first).as_posix():sha(p) for p in first.rglob('*') if p.is_file()};assert len(rendered)==153
assert rendered=={p.relative_to(second).as_posix():sha(p) for p in second.rglob('*') if p.is_file()}
proposal=W/'PROPOSAL';proposal.mkdir();rows=[]
for path,h in con['currentRecordHashes'].items():
 original=(R/path).read_bytes();assert sha(R/path)==h,path
 expected=original.replace(old.encode(),new.encode())
 if path in rendered:assert (first/path).read_bytes()==expected,path
 else:assert path in ['release/acceptance/candidate.json','audit/curriculum-readiness/V2_CURRICULUM_GAP_CLOSURE_DOSSIER_v1.0.md'],path
 target=proposal/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(expected)
 rows.append(dict(path=path,changed=original!=expected,oldSha256=h,newSha256=sha(target),oldBytes=len(original),newBytes=len(expected),originalGitBlob=git('rev-parse',source+':'+path)))
assert sum(r['changed'] for r in rows)==95 and len(rows)==155
with zipfile.ZipFile(W/'HISTORICAL_PRIOR_CURRENT.zip','x',zipfile.ZIP_DEFLATED) as z:
 for row in rows:
  if row['changed']:z.write(R/row['path'],row['path'])
save('HISTORICAL_PRIOR_CURRENT_INDEX.json',[r for r in rows if r['changed']])
for p,h in protected.items():assert sha(R/p)==h,p
assert not subprocess.check_output(['git','status','--porcelain=v1','-z','--untracked-files=all'],cwd=R)
assert git('rev-parse','HEAD')==source
save('PROPOSAL_REVIEW.json',dict(sourceCommit=source,oldRepositorySourceDigest=old,newRepositorySourceDigest=new,twoFreshRendersIdentical=True,renderedFiles=153,proposedFiles=155,changedFiles=95,unchangedFiles=60,onlyRepositorySourceDigestTokenChanges=True,all30CurriculumSourceChoicesUnchanged=True,allPackUnitReviewPackageMappingDigestsUnchanged=True,allReviewerOwnerRightsSourceAdmissionApprovalFieldsUnchanged=True,JUnitMethodsExecuted=0,files=rows))
print(json.dumps(dict(sourceCommit=source,newDigest=new,rendered=153,changed=95,unchanged=60,applied=False)))
