from pathlib import Path
import subprocess,json,hashlib,zipfile,shutil
R=Path('/workspace/russian-companion');W=Path(__file__).parent;D=R/'audit/gpt61-sol-high-comprehensive-2026-10-19/engineering-shared-qa-source-reconciliation-2026-10-29'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=R,text=True).strip()
x=json.loads((W/'PROPOSAL_REVIEW.json').read_text());ctx=json.loads((W/'CONTEXT.json').read_text());prep=json.loads((W/'GENERATION_PREPARATION.json').read_text())
assert git('rev-parse','HEAD')==x['sourceCommit'] and not subprocess.check_output(['git','status','--porcelain=v1','-z','--untracked-files=all'],cwd=R)
assert x['twoFreshRendersIdentical'] and x['onlyRepositorySourceDigestTokenChanges'] and x['changedFiles']==95
for p,h in ctx['protectedEvidenceHashes'].items():assert sha(R/p)==h,p
for row in x['files']:
 assert sha(R/row['path'])==row['oldSha256'] and sha(W/'PROPOSAL'/row['path'])==row['newSha256'],row['path']
 assert (R/row['path']).read_bytes().replace(x['oldRepositorySourceDigest'].encode(),x['newRepositorySourceDigest'].encode())==(W/'PROPOSAL'/row['path']).read_bytes()
D.mkdir()
for row in x['files']:
 if row['changed']:shutil.copyfile(W/'PROPOSAL'/row['path'],R/row['path'])
# Observe the actual repository after application through the compiled official implementation.
afterCommand=['/workspace/jdk21/bin/java','-cp',prep['classpath'],'Digest',str(R)]
(W/'AFTER_APPLY_CONTEXT.json').write_text(json.dumps(dict(command=afterCommand,sourceCommit=x['sourceCommit'],workingTree='95 reviewed binding token changes; source inputs unchanged',JUnitMethodsExecuted=0),indent=2)+'\n')
with (W/'AFTER_APPLY_DIGEST.log').open('x') as out:p=subprocess.run(afterCommand,cwd=R,stdout=out,stderr=subprocess.STDOUT)
assert p.returncode==0 and x['newRepositorySourceDigest'] in (W/'AFTER_APPLY_DIGEST.log').read_text()
for row in x['files']:assert sha(R/row['path'])==row['newSha256']
for p,h in ctx['protectedEvidenceHashes'].items():
 if p not in ctx['currentRecordHashes']:assert sha(R/p)==h,p
# Require exactly95 tracked binding modifications before adding the evidence packet.
status=subprocess.check_output(['git','status','--porcelain=v1','-z','--untracked-files=all'],cwd=R).split(b'\0');paths={row[3:].decode() for row in status if row};assert paths=={r['path'] for r in x['files'] if r['changed']},paths
for name in ['CONTEXT.json','GENERATION_PREPARATION.json','PROPOSAL_REVIEW.json','COMMAND_RESULTS.json','AFTER_APPLY_DIGEST.log','AFTER_APPLY_CONTEXT.json','HISTORICAL_PRIOR_CURRENT.zip','HISTORICAL_PRIOR_CURRENT_INDEX.json']:shutil.copyfile(W/name,D/name)
# Include only generation-owned raw inputs/outputs, not unrelated remote PR drafts.
raw=[p for p in W.iterdir() if p.is_file() and (p.suffix in ['.java','.class','.log'] or p.name in ['generate.py','apply.py','COMPILED_INDEX.json'])]
for folder in ['CANDIDATE_1','CANDIDATE_2','PROPOSAL']:raw += [p for p in (W/folder).rglob('*') if p.is_file()]
index={p.relative_to(W).as_posix():sha(p) for p in raw}
with zipfile.ZipFile(D/'RAW_GENERATION.zip','x',zipfile.ZIP_DEFLATED) as z:
 for p in raw:z.write(p,p.relative_to(W).as_posix())
 z.writestr('MEMBER_SHA256.json',json.dumps(index,indent=2)+'\n')
with zipfile.ZipFile(D/'RAW_GENERATION.zip') as z:
 assert z.testzip() is None
 for name,h in index.items():assert hashlib.sha256(z.read(name)).hexdigest()==h,name
with zipfile.ZipFile(D/'HISTORICAL_PRIOR_CURRENT.zip') as z:
 assert z.testzip() is None and len(z.namelist())==95
 for row in x['files']:
  if row['changed']:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['oldSha256']
protected={p:h for p,h in ctx['protectedEvidenceHashes'].items() if p not in ctx['currentRecordHashes'] and not p.startswith('app/src/test/')}
# Preserve this phase's collected failures and runtime evidence in future guards too.
for p in (R/'audit/gpt61-sol-high-comprehensive-2026-10-19/engineering-b01-b02-shared-diagnostics-2026-10-29').iterdir():
 if p.is_file():protected[p.relative_to(R).as_posix()]=sha(p)
tests={p:sha(R/p) for p in subprocess.check_output(['git','ls-files','-z','app/src/test'],cwd=R,text=True).split('\0') if p}
con=dict(sourceBeforeApply=x['sourceCommit'],testHashes=tests,archives=ctx['archives'],protectedEvidenceHashes=protected,priorCurrentRecordHashes=ctx['currentRecordHashes'],currentRecordHashes={r['path']:r['newSha256'] for r in x['files']},all30CurriculumSourceChoicesUnchanged=True,unitPackReviewPackageMappingDigestsUnchanged=True,repositorySourceDigest=x['newRepositorySourceDigest'],packContentReviewDigest='39c3563ba1b149b36977ae0fc2c0f920e282101e9e7870c06d141fe1a10e65ec',historicalPriorVersions=95,learnerArchives=77,generationJUnitMethodsExecuted=0,bindings='CURRENT_ENGINEERING_RECONCILED_RUNTIME_PENDING',all59Findings='OPEN',audit='INCOMPLETE')
(D/'CONSERVATION.json').write_text(json.dumps(con,indent=2)+'\n')
(D/'STATUS.md').write_text(f'''# Shared QA source bindings reconciled

Compiled generation source `{x['sourceCommit']}` observed official repository source digest `{x['newRepositorySourceDigest']}`. Two fresh JVM renders match153files each and validate all30packages each. Exactly95of155current records change solely by the authentic repository digest token;60worksheets remain byte-exact. All30curriculum source choices and all pack/unit/review-package/mapping digests, reviewer/owner/rights/source/admission/approval fields remain unchanged. All95prior versions are archived with original Gitblob identities. After application the actual repository returns the same compiled official digest.

All286test files (285Kotlin and one reference JSON),77learner archives and previous failures/evidence remain unchanged. Pack digest `39c3563ba1b149b36977ae0fc2c0f920e282101e9e7870c06d141fe1a10e65ec` and raw assetSHA `02202d37e0aa2c51182e4db22feff177124b6db2c270a67a93ef85e188916c19` are unchanged. Candidate unfrozen/sourceCommitnull/artifactNOT_RECORDED/publicReleaseNOT_APPROVED. This is bookkeeping, not independent acceptance. Generation executes zeroJUnit methods. The previous source-pinned56/56focused verification remains separate; no runtime claim is made for the newly reconciled review/release trees. Bindings CURRENT_ENGINEERING_RECONCILED_RUNTIME_PENDING.

All59findings OPEN/auditINCOMPLETE. Four screenshot exporters16methods explicitly excluded from host verification: VisualReviewCaptureTest2, Units35ChunkCaptureTest2, Units610ChunkCaptureTest10, Units1115GapCaptureTest2. No PDF read or private content in this packet. Final independent comprehensive audit precedes physical GalaxyS26Ultra airplane-mode/reboot acceptance LAST. No APK assembly/install/signing, merge, freeze or release approval.
''')
(D/'NEXT_TASK.md').write_text('''# Next large task: construct-family curriculum corrections

Read the verified shared assessment/teaching diagnostic baseline and the whole-curriculum independent audit's BATCHED_CORRECTION_WORK_ORDER.csv. All59findings remain OPEN. This reconciliation preserves current content; it does not correct teaching, checks or rights. No job is active after generation/application is complete.

Begin B01/B02/B03 content work by construct family across the course: adjudicate exact task/cue collisions and weak checks, replace answer scripts with rules and legitimate worked examples, repair per-option rationale accuracy/remediation and learner markup under governed source/English records. Preserve false-positive controls, stress/case/homographs, all old source evidence and learner histories; explicitly retire content IDs only with correct stale-credit behavior. Do not bulk-swap answer keys or invent quotations. Mandatory foundation coverage and variance/owner/rights acceptance still follow the existing Master Authority/Amendment1, which does not require hiring an outside professor. Do not resume a per-unit schema campaign; generic pack-declared cumulative review with legacy1–16readers follows adequate item pools.

The56/56focused run at0772171f used pre-reconciliation review/release trees. No new full-suite result exists. Plan fresh host discovery/runtime on a stable corrected milestone; the earlier broad5a3411a7 remains1508reported/1507passed/1physicalskip, separate from B03baseline7/initial70/followup12/new56. Do not sum scopes. No broad rerun merely for docs. Preserve all failure evidence and original assertions. The provisional SQLite JIT directive is unadopted, not a test exclusion, and native cause remains UNCONFIRMED.

One agent, existing checkout, OPEN DraftPR64. Four screenshot exporters16excluded. Final comprehensive independent app/curriculum audit first, then actual GalaxyS26Ultra airplane-mode/reboot LAST. No merge, freeze, APK assembly/install/signing or release approval.
''')
for p,prefix in [(R/'AGENTS.md','audit/gpt61-sol-high-comprehensive-2026-10-19/'),(R/'audit/content-corrections/CODEX_ENGINEERING_CONTINUATION.md','../gpt61-sol-high-comprehensive-2026-10-19/'),(R/'audit/content-corrections/CODEX_CHECKPOINT_2026-10-12.md','../gpt61-sol-high-comprehensive-2026-10-19/')]:
 p.write_text(f'Current checkpoint: [Shared QA source identity reconciled]({prefix}{D.name}/STATUS.md). Official digest{x["newRepositorySourceDigest"][:12]};two153renders/95digest-onlychanges/60unchanged/95historicalversions;286tests/77archives conserved. Bindings CURRENT_ENGINEERING_RECONCILED_RUNTIME_PENDING;zero generationJUnit. Prior0772171f56/56focused passed, not complete suite. Read NEXT_TASK.md for construct-family corrections. All59OPEN/auditINCOMPLETE/four exporters16excluded/final audit then physicalLAST/noAPK/signing/merge/freeze/approval.\n\n'+p.read_text())
(D/'SHA256.json').write_text(json.dumps({p.name:sha(p) for p in sorted(D.iterdir()) if p.is_file() and p.name!='SHA256.json'},indent=2)+'\n')
print(json.dumps(dict(changed=95,unchanged=60,historical95=True,newDigest=x['newRepositorySourceDigest'],evidenceDirectory=str(D))))
