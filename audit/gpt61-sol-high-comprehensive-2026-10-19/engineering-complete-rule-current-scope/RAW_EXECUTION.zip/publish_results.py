from pathlib import Path
import json,hashlib,zipfile,subprocess,shutil
R=Path('/workspace/russian-companion');W=Path(__file__).parent;D=R/'audit/gpt61-sol-high-comprehensive-2026-10-19/engineering-complete-rule-current-scope';O=W/'VERIFIED'
git=lambda *a:subprocess.check_output(['git',*a],cwd=R,text=True).strip();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
x=json.loads((O/'RESULT.json').read_text());c=json.loads((O/'CONTEXT.json').read_text());assert not git('status','--porcelain') and git('rev-parse','HEAD')==c['sourceCommit'];assert c['sourceCommit'].startswith('c55ba69f')
assert x['testCounts']==dict(reported=10,passed=10,failed=0,errors=0,skipped=0) and x['exitCode']==int((O/'RUN.exit').read_text())==0 and x['classes']==4 and x['allSelectedMethodsReported'] and x['selectedFreshXmlAndEventsMatch'] and x['eventOutcomeCountsMatchXml']
base='bcc895cc13647941a8e938b5ccb0d124285a71c1';path='app/src/test/java/dev/russiancompanion/v2/CompleteRuleCorrectionTest.kt';assert git('diff','--name-only',base,'HEAD').splitlines()==[path]
old=(W/'BEFORE_TEST.kt').read_text();assert old==subprocess.check_output(['git','show',base+':'+path],cwd=R,text=True)
new=(R/path).read_text()
for start,end in [('    @Test fun coordinatedKeyAndApplicationEditsCannotReverseTheFrozenContext()', '    @Test fun historicalFragmentAttemptIsRetainedButCannotCreditTheCompleteRule()'),('    @Test fun historicalFragmentAttemptIsRetainedButCannotCreditTheCompleteRule()', '    private val historicalJson')]:
 assert old[old.index(start):old.index(end)].strip() in new
D.mkdir();save=lambda n,v:(D/n).write_text(json.dumps(v,indent=2)+'\n');(D/'VERIFIED').mkdir()
for n in ['CONTEXT.json','RESULT.json','RESULTS.csv','RUN.exit','LINT.xml']:shutil.copy2(O/n,D/'VERIFIED'/n)
for n in ['CUE_SOURCE.json','CODE_CHANGE.patch','run_verified.py','resources.gradle']:shutil.copy2(W/n,D/n)
index=[]
with zipfile.ZipFile(D/'RAW_EXECUTION.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(W.rglob('*')):
  if p.is_file():
   n=p.relative_to(W).as_posix();z.write(p,n);index.append(dict(path=n,bytes=p.stat().st_size,sha256=sha(p)))
with zipfile.ZipFile(D/'RAW_EXECUTION.zip') as z:
 assert z.testzip() is None
 for v in index:assert hashlib.sha256(z.read(v['path'])).hexdigest()==v['sha256']
save('RAW_EXECUTION_INDEX.json',dict(archive='RAW_EXECUTION.zip',bytes=(D/'RAW_EXECUTION.zip').stat().st_size,sha256=sha(D/'RAW_EXECUTION.zip'),members=index,crcAndAllMemberHashesVerified=True))
hist=R/'audit/gpt61-sol-high-comprehensive-2026-10-19/engineering-pending-evidence-reconciliation';prior=json.loads((hist/'CONSERVATION.json').read_text());archives=prior['all66ArchiveHashesMatched'];assert len(archives)==66
for p,h in archives.items():assert sha(R/p)==h,p
hi=json.loads((hist/'HISTORICAL_GENERATED_EVIDENCE_INDEX.json').read_text());assert sha(hist/hi['archive'])==hi['archiveSha256']
with zipfile.ZipFile(hist/hi['archive']) as z:
 assert z.testzip() is None
 for v in hi['members']:assert hashlib.sha256(z.read(v['path'])).hexdigest()==v['sha256']
for v in json.loads((hist/'PROPOSAL_REVIEW.json').read_text())['files']:assert sha(R/v['path'])==v['newSha256']
assert sha(R/'release/acceptance/candidate.json')==prior['candidateUnchangedSha256'] and not(R/'audit/final-curriculum-audit').exists()
for p in ['app/src/main','catalog','docs','review']:assert git('rev-parse','HEAD:'+p)==git('rev-parse',base+':'+p)
save('CONSERVATION.json',dict(baseline=base,testedCommit=c['sourceCommit'],onlyOneTestFileChanged=path,originalTwoMutationHistoryMethodsByteIdentical=True,mainCatalogDocsReviewUnchanged=True,all66ArchiveHashesMatched=archives,all64AuthenticHistoriesPreserved=True,historical167FileArchiveCrcAndEveryMemberHashVerified=True,current154GeneratedHashesUnchanged=True,candidateUnchangedSha256=prior['candidateUnchangedSha256'],oldUnit7RestoreCause='UNCONFIRMED',physicalAcceptance='OUTSTANDING_LAST'))
unit7=R/'audit/gpt61-sol-high-comprehensive-2026-10-19/engineering-unit7-prerequisite-history';oldstatus=json.loads((unit7/'REGRESSION_DISPOSITION.json').read_text());targeted={'dev.russiancompanion.v2.CompleteRuleCorrectionTest#completeChoicesExplainTheCasesAndAllTeachingPrecedesPractice','dev.russiancompanion.v2.CompleteRuleCorrectionTest#availabilityPlayerShowsCompleteRulesWithItsFullRussianCue'}
rows=[]
for v in oldstatus['observations']:
 v=dict(v)
 if v['identity'] in targeted:v['engineeringDisposition']='SCOPED_HISTORICAL_CONTRACT_CURRENT_ADMISSION_AND_EVERY_CUE_VERIFIED_NOT_INDEPENDENT_CLOSURE'
 rows.append(v)
assert len(rows)==14 and sum(v['engineeringDisposition']=='OPEN_UNCHANGED_NOT_RERUN' for v in rows)==10
save('REGRESSION_DISPOSITION.json',dict(originalLedger=oldstatus['originalLedger'],originalLedgerSha256=oldstatus['originalLedgerSha256'],priorUnit7DispositionSha256=sha(unit7/'REGRESSION_DISPOSITION.json'),observations=rows,scopedEngineeringReconciliations=4,remaining=10,external17FindingStatusesUnchanged=True,completeSuite=False))
summary=f"Complete-rule/current-scope correction verified at `{c['sourceCommit']}`:10selected host methods/4classes,10passed/0failed/0errors/0skipped,exit0. Full CompleteRule class6/6 plus4existing Unit8sequence/mutation/UI methods;not the full Unit8history class or complete suite. Original14item option/case/teaching contract retained on actual1ab25bc6 source;current full validation remains required. Current10retained Unit10items exactly match original;four Unit8items/unit/provenance exactly match genuinefe919656 positive-existence implementation;whole current pack matchesb7e53230. Current teaching-before-practice/full-repair checks execute. Both legitimate Russian cue instances and each distinct prompt/all choices verified;no UI/app change. Original mutation/history methods byte-identical. Original14failure ledger immutable;four scoped engineering reconciliations across separate commits/scopes,10remainingOPEN. Prior Unit7four-method scope remains separate,not summed. All66archives/64histories/167historical generated members/154current generated hashes/candidate conserved. AuditINCOMPLETE;external17findings unclosed;physicalLAST;no assembly/install/signing/merge/freeze/approval."
report=f'''# Complete-rule history and current cue scope

{summary}

The original wording method expected all14items to begin “In this line,” and mention case analysis. The later genuine fe919656 correction deliberately replaced4Unit8items with bounded positive-existence recognition and removed analyzed absence/genitive from that active chain. Historical1ab25bc6 data assertions remain executable,including14items/case feedback/teaching order/complete remediation. Its final full validator now checks the current pack so obsolete Unit8 absence analysis is not readmitted. A new current method requires all10unchanged Unit10items to equal original source,and all4changed Unit8items/unit/provenance to equal the actual positive-existence implementation. Whole current decoded pack is bound exactly to last asset implementationb7e53230. Current teaching order/remediation and full current validation execute;existing negative tests reject restoration of old analysis or coordinated forged tuples. No productive grammar capability is inferred from bounded recognition.

The UI failure was an invalid uniqueness assumption. Current independent questions u8-i-availability-1 and3 legitimately share “В Москве́ есть ста́рые зда́ния”;V2QuestionCue renders one cue per item. CUE_SOURCE records the exact step/item/cue identities. Shared test helper now asserts the exact expected number of cue nodes from that step,scrolls/displays every instance,and checks each distinct item prompt and every answer choice by its item-specific tag. It does not choose first(),hide a cue or change app rendering. Both availability and possession routes execute. The two original coordinated-mutation/history method bodies remain byte-identical;only one test file changed.

## Actual validation

Tested source`{c['sourceCommit']}`:10reported/10passed/0failed/0errors/0skipped,4classes,exit0. Exact selectors/command/cwd/source/root/input/init/runner/test hashes,timing/resources and every method are in VERIFIED/CONTEXT.json/RESULT.json. Fresh XML/RESULT events/selector identities/outcomes reconcile exactly. Full six-method CompleteRule class and two-method Unit8ExistenceSequence class executed;only restoringTheOriginalAnalysisOrForgingTheNewTupleFailsClosed from Unit8ExistenceHistoryTest executed,plus the single Unit8ExistenceUi test. No full Unit8history-class pass is claimed. Two6GiBworkers/recycle4classes;detached runner,no queued mutations or automatic publication. Original baseline failures remain in the immutable three-scope regression archives;the unchanged pre-edit test file is retained in the raw ZIP and matches baselinebcc895cc exactly.

Task states:{json.dumps(x['tasks'],sort_keys=True)}. Lint:{json.dumps(x['lintIssuesBySeverity'],sort_keys=True)}. UP-TO-DATE is not fresh analysis. Gate attachment executed/PASS,not release approval. Four screenshot exporters/16methods explicitly excluded:VisualReviewCaptureTest2,Units35ChunkCaptureTest2,Units610ChunkCaptureTest10,Units1115GapCaptureTest2. No instrumented/device/exporter result. Configured APK dev.russiancompanion/2.0.0-dev/code5;no assembly/install/signing/new hash/signature.

## Conserved evidence and next large task

RAW_EXECUTION.zip passed CRC/every-member-SHA checks. All66original archives/64authentic histories,167historical generated members,154current generated hashes,candidate and main/catalog/docs/review trees remain exact. No production/native/source/rights/policy/schema/approval-field changes. Original14regression observations remain immutable;REGRESSION_DISPOSITION records2earlier Unit7 and2current scoped engineering reconciliations,not independent finding closure. Ten engineering failures remainOPEN:six conservation comparisons and four digest assertions. These current10passed methods and prior Unit7fourpassed methods are separate committed scopes,not a fresh14all-pass run or complete-suite result. Original17external findings and CC003contextual application gap retain qualified-review status. Old Unit7 restore-refusal cause remainsUNCONFIRMED.

Next large task is source-by-source reconciliation of those ten retained comparisons,with no blind hash/count refresh or lost negative assertions. Read NEXT_LARGE_TASK.md. Finish engineering,then final comprehensive independent nonphysical audit/recheck;actual Galaxy S26 Ultra airplane-mode/reboot acceptanceLAST/outstanding. Original historical audit/fourCSV remain unavailable. Private Penguin was not used/copied to app/Git branch/assets/packet. Environment config unchanged/saved earlier,publication user-confirmed independently unverified. Older mainff539220562pass/1skip and420f41ff691sourceannotations/handoff execution unverified remain separate commits/scopes. No merge,freeze,formal stage advancement,owner acceptance or release approval.
'''
(D/'ENGINEERING_CHANGE_REPORT.md').write_text(report)
(D/'NEXT_LARGE_TASK.md').write_text('# Next large task:ten historical conservation/digest failures\n\n'+summary+'\n\nUse one agent/existing checkout/PR64. Read REGRESSION_DISPOSITION.json and the immutable current-host-regression-2026-10-21/CONTINUATION_2_COMPLETE/NEXT_LARGE_TASK.md for the six exact conservation and four exact digest method identities. Those ten are unchanged/not rerun in this scope. The separate Unit7 conservation failure is among them. Trace before/implementation/current source objects and real correction boundaries before editing. Preserve original contracts/pins historically,add exact current implementation guards,and execute later validator/mutation/refusal assertions. Do not weaken language/source/rights/approval requirements or simply refresh expected values. Archive any changed evidence before mutation. All original failed/raw/history bytes remain immutable;four prior scoped engineering reconciliations do not close external findings. Final independent comprehensive nonphysical audit FIRST;physical Galaxy S26 Ultra acceptance LAST. No approval question is pending. No active test job remains.\n')
for n in ['CODEX_ENGINEERING_CONTINUATION.md','CODEX_CHECKPOINT_2026-10-12.md']:
 with (R/'audit/content-corrections'/n).open('a') as f:f.write('\n\n## Complete-rule current scope verified\n\n'+summary+' Read engineering-complete-rule-current-scope/ENGINEERING_CHANGE_REPORT.md under audit/gpt61-sol-high-comprehensive-2026-10-19/.\n')
p=R/'AGENTS.md';p.write_text(p.read_text().replace('# Codex continuation\n','# Codex continuation\n\nCurrent engineering checkpoint: [complete-rule/current-cue scope verified](audit/gpt61-sol-high-comprehensive-2026-10-19/engineering-complete-rule-current-scope/ENGINEERING_CHANGE_REPORT.md). '+summary+' Next large task:six conservation/four digest comparisons;read NEXT_LARGE_TASK.md there.\n',1))
save('SHA256.json',{p.relative_to(D).as_posix():sha(p) for p in sorted(D.rglob('*')) if p.is_file() and p.name!='SHA256.json'})
print(summary)
