import java.nio.file.*;
import java.security.*;
import java.util.*;
import dev.russiancompanion.v2.curriculum.*;
import dev.russiancompanion.v2.ui.V2AnswerFeedbackKt;
public class RationaleExposureProbe {
 static String sha(String s) throws Exception {
  return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(s.getBytes(java.nio.charset.StandardCharsets.UTF_8)));
 }
 public static void main(String[] args) throws Exception {
  var p=V2PackLoader.INSTANCE.parse(Files.readString(Path.of(args[0])));
  StringBuilder rows=new StringBuilder("item_id\toption_index\tauthored_sha256\tdisplayed_sha256\n");
  for(var item:p.getItems())for(int n=0;n<item.getOptions().size();n++){
   var selected=item.getOptions().get(n);if(selected.equals(item.getAnswer()))continue;
   var authored=n<item.getDistractorRationales().size()?item.getDistractorRationales().get(n):"";
   var displayed=V2AnswerFeedbackKt.selectedWrongOptionRationale(item,selected);
   if(displayed!=null&&!displayed.equals(authored))throw new AssertionError("Presenter changed authored bytes");
   rows.append(item.getId()).append('\t').append(n).append('\t').append(sha(authored)).append('\t').append(displayed==null?"NOT_SHOWN":sha(displayed)).append('\n');
  }
  Files.writeString(Path.of(args[1]),rows.toString());
  System.out.println("Observed presentation helper for every wrong option;not JUnit/test count/linguistic acceptance.");
 }
}
