from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import subprocess,json,hashlib,shutil,csv,re,unicodedata
R=Path('/workspace/russian-companion');W=Path('/workspace/artifacts/b03-rationale-quality-correction-2026-10-29');sha=lambda b:hashlib.sha256(b).hexdigest();save=lambda n,v:(W/n).write_text(json.dumps(v,indent=2)+'\n');old=Path('/workspace/artifacts/cache-ui-ci-source-bindings-2026-10-28');base=json.loads((old/'GENERATION_PREPARATION.json').read_text());cp=base['classpath'].replace(str(old),str(W),1);shutil.copyfile('/workspace/artifacts/RationaleExposureProbe.java',W/'RationaleExposureProbe.java');commands=[]
for label,args in [('EXPOSURE_COMPILE',['/workspace/jdk21/bin/javac','-cp',cp,str(W/'RationaleExposureProbe.java')]),('EXPOSURE_PROBE',['/workspace/jdk21/bin/java','-Xmx2g','-cp',cp,'RationaleExposureProbe',str(R/'app/src/main/assets/content/v2-curriculum.json'),str(W/'PRESENTATION_EXPOSURE.tsv')])]:
 with(W/(label+'.log')).open('x')as f:p=subprocess.run(args,cwd=R,stdout=f,stderr=subprocess.STDOUT)
 commands.append({'label':label,'command':args,'exitCode':p.returncode,'finishedUtc':datetime.now(timezone.utc).isoformat()});save('EXPOSURE_COMMANDS.json',commands);assert p.returncode==0,label
pack=json.loads((R/'app/src/main/assets/content/v2-curriculum.json').read_text());items={i['id']:i for i in pack['items']};actual={(r['item_id'],int(r['option_index'])):r for r in csv.DictReader((W/'PRESENTATION_EXPOSURE.tsv').open(),delimiter='\t')};assert len(actual)==sum(sum(x!=i['answer']for x in i['options'])for i in pack['items'])
def norm(s):return unicodedata.normalize('NFC',re.sub('[́̀]','',unicodedata.normalize('NFD',s or''))).strip().lower()
optionCounts=Counter();affected={};hidden=Counter();shown=0
fragments=['does not match the category or whole-phrase meaning requested here','is a different meaning or construction and does not match','This differs from the meaning or structure requested in this context','This is a different time relation','This differs from the classification or conversational function']
for (iid,n),ob in actual.items():
 i=items[iid];r=(i.get('distractorRationales')or[]);r=r[n]if n<len(r)else'';flags=[]
 if not r.strip():flags.append('MISSING')
 else:
  m=re.search(r'pairs the shown form "([^"]+)"',r)
  if m and i.get('promptLetter')and norm(m[1])!=norm(i['promptLetter']):flags.append('SHOWN_FORM_MISMATCH')
  if r.strip().startswith('Rejected reading:'):flags.append('UNINFORMATIVE')
  if any(s in r for s in fragments):flags.append('TEMPLATE')
 for flag in flags:
  optionCounts[flag]+=1;affected.setdefault(flag,set()).add(iid);assert ob['displayed_sha256']=='NOT_SHOWN',(iid,n,flag)
 if ob['displayed_sha256']!='NOT_SHOWN':shown+=1;assert ob['displayed_sha256']==ob['authored_sha256']
 else:hidden['notShown']+=1
summary={'sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip(),'sourceInputTrees':{n:subprocess.check_output(['git','rev-parse','HEAD:'+n],cwd=R).decode().strip()for n in ['app/src/main','app/src/test','catalog','docs','review','release']},'kind':'READ_ONLY_COMPILED_PRESENTATION_OBSERVATION_NOT_ADDITIONAL_JUNIT_EXECUTION','actualWrongOptionCalls':len(actual),'shownUnchangedAuthoredRationales':shown,'notShown':hidden['notShown'],'knownAuditFlagsByAffectedItems':{k:len(v)for k,v in affected.items()},'knownAuditFlagsByWrongOption':dict(optionCounts),'knownFlaggedWrongOptionsStillShown':0,'audit91MeansAffectedItemsNot91WrongOptions':True,'guardIsNotLinguisticValidation':True,'all59Findings':'OPEN','audit':'INCOMPLETE','sourceBindings':'RECONCILIATION_PENDING','newJUnitMethodsExecutedByProbe':0};save('EXPOSURE_RESULT.json',summary);print(json.dumps(summary))
