"""Exclusive post-run evidence collector; no app/test edits or new test execution."""
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import subprocess,json,time,os,hashlib,traceback
R=Path('/workspace/russian-companion');W=Path('/workspace/artifacts/cache-ui-ci-broad-host-regression-2026-10-28');D=R/'audit/gpt61-sol-high-comprehensive-2026-10-19/engineering-cache-ui-ci-broad-host-regression-2026-10-28';source='5a3411a76b88753617ea18b3e1a54f44f6923b9f';now=lambda:datetime.now(timezone.utc).isoformat();save=lambda n,v:(W/n).write_text(json.dumps(v,indent=2)+'\n');git=lambda *a:subprocess.check_output(['git',*a],cwd=R).decode().strip()
try:
 assert git('rev-parse','HEAD')==source and not(W/'AUTO_RESULT.json').exists()and not(W/'AUTO_ERROR.txt').exists()
 with(W/'POST_RUN_OWNER.json').open('x')as f:json.dump({'pid':os.getpid(),'sourceCommit':source,'startedUtc':now(),'ownership':'Exclusive post-run collection, audit-docs-only commit, normal push and DraftPR64 update. Root must not collect/edit while active. No additional test launch or app/test edits.','collector':'/workspace/artifacts/finish-cache-ui-broad.py'},f,indent=2)
 while not(W/'REGRESSION_COMPLETION.json').exists():
  p=W/'REGRESSION/EVENTS.jsonl';e=[]
  if p.exists():
   for line in p.read_text().splitlines():
    try:e.append(json.loads(line))
    except json.JSONDecodeError:pass
  d=[x for x in e if x.get('kind')=='RESULT'];save('POST_RUN_MONITOR.json',{'observedUtc':now(),'sourceCommit':source,'partialEvents':len(d),'outcomes':dict(Counter(x['resultType']for x in d)),'finalResult':False});time.sleep(15)
 assert(W/'REGRESSION/RESULT.json').exists(),'Execution ended without final verified result; preserve raw run for manual recovery'
 assert git('rev-parse','HEAD')==source and not subprocess.check_output(['git','status','--porcelain=v1','-z','--untracked-files=all'],cwd=R)
 subprocess.run(['python3','/workspace/artifacts/finish-cache-ui-broad.py'],cwd=R,check=True)
 commit=git('rev-parse','HEAD');parent=git('rev-parse','HEAD^');assert parent==source
 changed=git('diff','--name-only',source,commit).splitlines();pointers={'AGENTS.md','audit/content-corrections/CODEX_ENGINEERING_CONTINUATION.md','audit/content-corrections/CODEX_CHECKPOINT_2026-10-12.md'};assert all(n in pointers or n.startswith(str(D.relative_to(R))+'/')for n in changed)
 subprocess.run(['git','push','origin','cursor/content-audit-corrections-964f'],cwd=R,check=True)
 remote=git('ls-remote','origin','refs/heads/cursor/content-audit-corrections-964f').split()[0];assert remote==commit
 j=json.loads((D/'REGRESSION_RESULT.json').read_text());c=j['testCounts'];sub=json.loads((D/'FOLLOWUP_119_SUBSET.json').read_text())['outcomes'];body=f'''Codex-only engineering continuation. Current evidence commit `{commit}`; actual broad execution source `{source}`.

This batch corrects cold/evicted unit-identity cache recomputation, displays selected authored wrong-option rationale beside unchanged common feedback across lessons/labs/reviews, and restores onboarding page/choices without automatic submission. CI now verifies only, explicitly excludes the four screenshot exporters, retains source/test/lint reports, and creates no candidate APK. Gradle wrapper pins the observed official expected distribution checksum (no independent hash of installed cached archive claimed).

Actual broad selected JVM host scope: **{c['reported']} reported / {c['passed']} passed / {c['failed']} failed / {c['errors']} errors / {c['skipped']} skipped**, {j['classes']} classes, Gradle exit {j['exitCode']}. Whole debug JVM task, no class/method filters. Fresh discovery, final XML and event identities/outcomes match. All119previouslyselected follow-up methods are included in this same run: {json.dumps(sub)}; these are a subset, not119additional executions. Exact skipped IDs and every full failure are preserved. This is not a complete app-suite audit.

Separate focused scopes (not added together): cache341444a1:25/25passed; UIff450b72:62/62passed; CIcontractdba6d873:1/1passed. Initial/refined UI6methodbaselines each1pass/5fail, cold/evicted failures, original1499broad60failures, and interrupted119run remain immutable. UIcollector61vs62inventory refusal and successful independent62XML/event reconciliation are explicitly retained; no test was changed to reconcile that count. CI's original candidate-workflow assertions remain against exact historical bytes, with current verification-only controls added.

Lint severities in broad run: {json.dumps(j['lintIssuesBySeverity'])}; see REGRESSION_RESULT.json for compilation/gate-attachment task/cache outcomes. All284testfiles,155bindings,77learnerarchives and protected prior evidence stayed exact during execution. Two authentic compiled source renders matched153files/30packages each; only repository identity changed in95records,60worksheets unchanged,all30curriculum source choices/content digests/reviewer/rights/owner/approval fields retained. Repository digest b64b6ab8e57eef7f08ea7a603f10cd5d635c930e4c2445783c0698657dd16125 is distinct from pack content digest.

Current report and next task: audit/gpt61-sol-high-comprehensive-2026-10-19/engineering-cache-ui-ci-broad-host-regression-2026-10-28/REPORT.md and NEXT_TASK.md; durable discovery pointers in AGENTS.md and audit/content-corrections/CODEX_ENGINEERING_CONTINUATION.md. Original counts562/691 and all earlier scopes are different historical producers/scopes, not complete-current-app results.

All48independentfindingsOPEN; auditINCOMPLETE. Final independent comprehensive Claude Code audit remains required, then actualGalaxyS26Ultra airplane-mode/reboot acceptanceLAST. Four exporters16methods excluded:VisualReviewCaptureTest2,Units35ChunkCaptureTest2,Units610ChunkCaptureTest10,Units1115GapCaptureTest2. Provisional host SQLite JIT directive unadopted/notatestexclusion;nativecause and originalUnit7restorecause UNCONFIRMED. NoAPKassembly/install/newsigning/merge/freeze/formalreleaseapproval;APKidentity/signaturenull. PrivatePenguin outside appbranch/assets/packets. Environmentunchanged/publicationuser-confirmedindependentlyunobserved.

GitHubActions runs40803595665/40803585701 had runner_id0/nosteps: Actions budget prevents use. Host verification is not CI execution. Qualified linguistic/source/rights/owner decisions remain outstanding.
''';(W/'PR64_BODY_COMPLETED.md').write_text(body)
 out=subprocess.check_output(['gh','api','--method','PATCH','repos/justinkulka-lang/russian-companion/pulls/64','-F','body=@'+str(W/'PR64_BODY_COMPLETED.md')],cwd=R);(W/'PR64_COMPLETED.json').write_bytes(out);pr=json.loads(out);assert pr['head']['sha']==commit and pr['draft']and pr['state']=='open'
 save('AUTO_RESULT.json',{'finishedUtc':now(),'actualSource':source,'evidenceCommit':commit,'remoteCommit':remote,'counts':c,'classes':j['classes'],'exitCode':j['exitCode'],'followup119Subset':sub,'pr64OpenDraft':True,'prBodySha256':hashlib.sha256(body.encode()).hexdigest(),'all48Findings':'OPEN','audit':'INCOMPLETE','physicalAcceptance':'OUTSTANDING_LAST','appOrTestsEditedByWorker':False,'newExecutionLaunchedByWorker':False})
except BaseException:
 (W/'AUTO_ERROR.txt').write_text(traceback.format_exc());raise
