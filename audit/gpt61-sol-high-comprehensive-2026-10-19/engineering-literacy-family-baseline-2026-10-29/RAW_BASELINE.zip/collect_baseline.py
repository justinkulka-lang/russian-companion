from pathlib import Path
import json,hashlib,zipfile,subprocess,shutil
R=Path('/workspace/russian-companion');W=Path(__file__).parent;D=R/'audit/gpt61-sol-high-comprehensive-2026-10-19/engineering-literacy-family-baseline-2026-10-29'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
x=json.loads((W/'REGRESSION/RESULT.json').read_text());dis=json.loads((W/'DISCOVERY/RESULT.json').read_text());con=json.loads((D/'CONSERVATION.json').read_text());head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head==x['sourceCommit']==dis['sourceCommit']
assert not subprocess.check_output(['git','status','--porcelain=v1','-z','--untracked-files=all'],cwd=R)
assert x['testCounts']==dict(reported=7,passed=4,failed=3,errors=0,skipped=0),x['testCounts']
assert x['exitCode']==1 and x['classes']==2 and x['discoveryComparison']['exactSameMethodSet']
failed={t['method'] for t in x['tests'] if t['outcome']=='FAILED'};assert failed=={'unitOneRequiredChecksExplainEachWrongOptionByItsValue','unitTwoRequiredChecksExplainEachWrongOptionByItsValue','unitTwoRequiredReviewDoesNotRepeatAnEntireUnitOneDisplayTask'}
assert x['lintIssuesBySeverity']['Error']==0 and x['lintIssuesBySeverity']['Fatal']==0
for k in ['testHashes','archives','protectedEvidenceHashes','currentRecordHashes']:
 for p,h in con[k].items():assert sha(R/p)==h,p
caps=W/'REGRESSION/CAPTURES';files=list(caps.glob('*.zip'));assert len(files)==10
scenario=D/'SCENARIOS';scenario.mkdir();identities=[]
for p in sorted(files):
 meta=json.loads(p.with_suffix('.IDENTITY.json').read_text());assert meta['producerCommit']==head and meta['curriculumSourceCommit']=='f653da03d1bc657e8acaeef52141552c531e42ce'
 assert meta['zipSHA256']==sha(p) and meta['zipBytes']==p.stat().st_size and meta['syntheticLearner'] and not meta['oldArchiveRelabelled']
 with zipfile.ZipFile(p) as z:assert z.testzip() is None
 for source in [p,p.with_suffix('.IDENTITY.json')]:shutil.copy2(source,scenario/source.name)
 identities.append(dict(label=p.stem,sha256=sha(p),bytes=p.stat().st_size,completedUnits=meta['completedUnits'],profileUnit=meta['profileUnit'],reviewSchemas=meta['reviewSchemas']))
# Full raw baseline and fetched source/licence evidence; draft correction is not shipped as implemented here.
raw=[p for p in W.rglob('*') if p.is_file() and 'CORRECTION_DRAFT' not in p.parts]
index={p.relative_to(W).as_posix():sha(p) for p in raw}
with zipfile.ZipFile(D/'RAW_BASELINE.zip','x',zipfile.ZIP_DEFLATED) as z:
 for p in raw:z.write(p,p.relative_to(W).as_posix())
 z.writestr('MEMBER_SHA256.json',json.dumps(index,indent=2)+'\n')
with zipfile.ZipFile(D/'RAW_BASELINE.zip') as z:
 assert z.testzip() is None
 for p,h in index.items():assert hashlib.sha256(z.read(p)).hexdigest()==h,p
for a,b in [(W/'REGRESSION/RESULT.json','RUNTIME_RESULT.json'),(W/'DISCOVERY/RESULT.json','DISCOVERY_RESULT.json'),(W/'GITHUB_UNICODE_FETCH.json','GITHUB_UNICODE_FETCH.json'),(W/'UNICODE_FETCH.json','DIRECT_UNICODE_FETCH_FAILURE.json')]:shutil.copy2(a,D/b)
(D/'CAPTURE_INDEX.json').write_text(json.dumps(identities,indent=2)+'\n')
(D/'COMPLETED_BASELINE.md').write_text(f'''# Literacy-family baseline reproduced

Actual source `{head}`: **7reported/4passed/3failed/0errors/0skips**, two full classes, Gradleexit1. Three genuine audit quality failures: required Unit1wrong-option explanations missing36entries; Unit2missing10entries; four exact Unit1task repeats in Unit2. Three current controls and the one history-capture method passed. Fresh discovery7synthetic skips/zero runtime passes; runtimeXML/events exact. This is not a complete-suite result or an acceptance result. Preserve all original assertions/failures.

One passing JUnit method exercised ten genuine synthetic-learner history scenarios using unchanged actual sourcef653da03/rawasset02202d37. Every archive decoded, replaced a named database, reopened with exact document/review/completion rows and expected eligibility. Ten scenarios are NOT ten tests. SCENARIOS/ holds ten original ZIPs and identities; CAPTURE_INDEX.json records actual hashes and profiles. The prior77archives remain byte-exact, bringing retained archives in this engineering lineage to87. No old archive was relabelled and no device evidence was created.

CompileDebugSources and release-gate attachment passed. Lint{x['lintIssuesBySeverity']}. Exact commands/inputtrees/source/exclusions/GC/log/XML/events in RAW_BASELINE.zip. NoAPKassembly/install/signing/newAPKidentity or signature. No production/catalog/content/binding/policy/schema changes; all286oldertestfiles/155bindings/prior77archives remain exact. Two new classes add seven methods. All59findings OPEN/auditINCOMPLETE; native causeUNCONFIRMED and provisional JITdirective unadopted/not a test exclusion.

Unicode.org direct requests were blocked by proxyHTTP403. Official unicode-org/icu GitHub mirror at8eca245c7484ac6cc179e3e5f7c1ea7680810f39 returned actualUnicodeData and LICENSE; remote Gitblob/actualSHA verified. This is letter-name/case research only, not phonetic, linguistic or rights acceptance. Full fetched bytes, licence and identities are retained in RAW_BASELINE.zip. No private book consulted or reproduced.

Next apply only the researched46authored explanations/four actual case-form variants and coherent Unit2instruction, then verify all unchanged quality tests and explicit historical/current-credit boundaries. Missing audio/pronunciation/true decoding and other foundational issues remainOPEN. Four screenshot exporters16methods excluded. Final comprehensive independent audit then GalaxyS26Ultra airplane-mode/rebootLAST. No merge/freeze/releaseapproval.
''')
for p,prefix in [(R/'AGENTS.md','audit/gpt61-sol-high-comprehensive-2026-10-19/'),(R/'audit/content-corrections/CODEX_ENGINEERING_CONTINUATION.md','../gpt61-sol-high-comprehensive-2026-10-19/'),(R/'audit/content-corrections/CODEX_CHECKPOINT_2026-10-12.md','../gpt61-sol-high-comprehensive-2026-10-19/')]:p.write_text(f'Current checkpoint: [Literacy-family baseline reproduced]({prefix}{D.name}/COMPLETED_BASELINE.md).Actual5892c1f3:7reported/4pass/3realqualityfailures;2FULLclasses;exit1. One passing method captures10genuine histories/all decode+namedreplace+reopen;87archives now retained. Source/content/286oldertests/155bindings unchanged. Preserve assertions/failures;next researched bounded correction/current-credit verification. All59OPEN/four exporters16excluded/final audit then physicalLAST/noAPK/signing/merge/freeze/approval.\n\n'+p.read_text())
(D/'SHA256.json').write_text(json.dumps({p.relative_to(D).as_posix():sha(p) for p in D.rglob('*') if p.is_file() and p.name!='SHA256.json'},indent=2)+'\n')
print(json.dumps(dict(source=head,counts=x['testCounts'],captures=10,lint=x['lintIssuesBySeverity'])))
