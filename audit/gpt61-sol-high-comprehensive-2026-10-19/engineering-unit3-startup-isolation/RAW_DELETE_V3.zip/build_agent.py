from pathlib import Path
import subprocess,zipfile,json,hashlib,sys,time
old=Path(__file__).parent;w=Path('/workspace/artifacts/unit3-refusal-trace-2026-10-21-v3');w.mkdir();sdir=w/'agent-src/audittrace';sdir.mkdir(parents=True);cdir=w/'agent-classes';cdir.mkdir()
a=(old/'agent-src/audittrace/Agent.java').read_text();t=(old/'agent-src/audittrace/RefusalTraceProbe.java').read_text()
a=a.replace('inst.appendToBootstrapClassLoaderSearch(new JarFile(helper));inst.addTransformer','inst.appendToBootstrapClassLoaderSearch(new JarFile(helper));inst.redefineModule(Object.class.getModule(),Set.of(Class.forName("org.robolectric.internal.bytecode.RefusalTraceProbe",true,null).getModule()),Map.of(),Map.of(),Set.of(),Map.of());inst.addTransformer')
a=a.replace('if(name==null||!(', 'if(name==null||!(name.equals("java/io/File")||name.equals("java/nio/file/Files")||')
a=a.replace(' }});}', ' }},true);inst.retransformClasses(java.io.File.class,java.nio.file.Files.class);}')
a=a.replace('return n.contains("replaceGovernedLearner")','return n.contains("recoverInterruptedReplacementLocked")||n.contains("deleteReplacementJournal")||n.contains("sweepOrphanRecordingFiles")||n.equals("close")||n.contains("replaceGovernedLearner")')
a=a.replace('String id=name.replace(\'/\',\'.\')+"#"+m.name+m.desc;boolean test=', '''String id=name.replace('/','.')+"#"+m.name+m.desc;
 if(name.equals("java/io/File")||name.equals("java/nio/file/Files")){
  if(!(m.name.equals("delete")||m.name.equals("deleteIfExists")))continue;
  if(name.equals("java/io/File")&&!m.desc.equals("()Z"))continue;
  if(name.equals("java/nio/file/Files")&&!m.desc.startsWith("(Ljava/nio/file/Path;)"))continue;
  AbstractInsnNode[] ins=m.instructions.toArray();InsnList entry=new InsnList();entry.add(new VarInsnNode(Opcodes.ALOAD,0));entry.add(new LdcInsnNode(id));entry.add(new MethodInsnNode(Opcodes.INVOKESTATIC,"org/robolectric/internal/bytecode/RefusalTraceProbe","deleting","(Ljava/lang/Object;Ljava/lang/String;)V",false));m.instructions.insert(entry);
  for(var n:ins)if(n.getOpcode()==Opcodes.IRETURN||n.getOpcode()==Opcodes.RETURN){InsnList v=new InsnList();if(n.getOpcode()==Opcodes.IRETURN)v.add(new InsnNode(Opcodes.DUP));v.add(new VarInsnNode(Opcodes.ALOAD,0));v.add(new LdcInsnNode(id));v.add(new MethodInsnNode(Opcodes.INVOKESTATIC,"org/robolectric/internal/bytecode/RefusalTraceProbe",n.getOpcode()==Opcodes.IRETURN?"deleted":"deletedVoid",n.getOpcode()==Opcodes.IRETURN?"(ZLjava/lang/Object;Ljava/lang/String;)V":"(Ljava/lang/Object;Ljava/lang/String;)V",false));m.instructions.insertBefore(n,v);}
  count++;changed.add(id+":DELETE");continue;
 }
 boolean test=''')
t=t.replace('public static void enter(String method,int line,Object self){emit("ENTER",method,line,"",self);}', '''private static String stack(){StringBuilder b=new StringBuilder();for(var s:Thread.currentThread().getStackTrace())b.append(s).append(" | ");return b.toString();}
 private static boolean wanted(Object p){String s=String.valueOf(p);return s.contains("robolectric-Unit3GenderTeachingTest")||s.contains("backup-replace-recordings");}
 public static void deleting(Object p,String m){if(wanted(p))emit("DELETE_ENTER",m,-1,String.valueOf(p)+" | "+stack(),null);}
 public static void deleted(boolean ok,Object p,String m){if(wanted(p))emit(ok?"DELETE_SUCCESS":"DELETE_FALSE",m,-1,String.valueOf(p),null);}
 public static void deletedVoid(Object p,String m){if(wanted(p))emit("DELETE_SUCCESS",m,-1,String.valueOf(p),null);}
 public static void enter(String method,int line,Object self){emit("ENTER",method,line,"self="+System.identityHashCode(self)+" | "+stack(),self);}''')
(sdir/'Agent.java').write_text(a);(sdir/'RefusalTraceProbe.java').write_text(t)
flags=['--add-exports','java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED','--add-exports','java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED']
subprocess.run(['/workspace/jdk21/bin/javac',*flags,'-d',str(cdir),str(sdir/'Agent.java'),str(sdir/'RefusalTraceProbe.java')],check=True)
with zipfile.ZipFile(w/'trace-helper.jar','w') as z:z.write(cdir/'org/robolectric/internal/bytecode/RefusalTraceProbe.class','org/robolectric/internal/bytecode/RefusalTraceProbe.class')
with zipfile.ZipFile(w/'trace-agent.jar','w') as z:
 z.writestr('META-INF/MANIFEST.MF','Manifest-Version: 1.0\nPremain-Class: audittrace.Agent\nCan-Retransform-Classes: true\n\n')
 for p in (cdir/'audittrace').glob('Agent*.class'):z.write(p,p.relative_to(cdir).as_posix())
(w/'AGENT_BUILD.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [sdir/'Agent.java',sdir/'RefusalTraceProbe.java',w/'trace-helper.jar',w/'trace-agent.jar']},indent=2)+'\n')
(w/'build_agent.py').write_text(Path(__file__).read_text())
(w/'run.py').write_text((old/'run.py').read_text().replace('TRACED_CONTROL_V2','TRACED_DELETE_V3'))
(w/'resources.gradle').write_text((old/'resources.gradle').read_text().replace('unit3-refusal-trace-2026-10-21-v2/','unit3-refusal-trace-2026-10-21-v3/'))
r=Path('/workspace/russian-companion');assert not subprocess.check_output(['git','status','--porcelain'],cwd=r,text=True)
with (w/'LAUNCHER.log').open('wb') as out:p=subprocess.Popen([sys.executable,str(w/'run.py'),'TRACED_DELETE_V3'],stdin=subprocess.DEVNULL,stdout=out,stderr=subprocess.STDOUT,start_new_session=True,close_fds=True)
(w/'SESSION.json').write_text(json.dumps({'pid':p.pid,'sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'launchedEpoch':time.time(),'scope':'9diagnostic methods;File/Files deletion trace added;not original refusal proof','automaticMutationOrPublicationQueued':False},indent=2)+'\n');print('Detached deletion tracer PID',p.pid)
