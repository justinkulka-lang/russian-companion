from pathlib import Path
import subprocess,zipfile,json,hashlib,sys,time
old=Path(__file__).parent;w=Path('/workspace/artifacts/unit3-refusal-trace-2026-10-21-v4');w.mkdir();sdir=w/'agent-src/audittrace';sdir.mkdir(parents=True);cdir=w/'agent-classes';cdir.mkdir()
a=(old/'agent-src/audittrace/Agent.java').read_text();t=(old/'agent-src/audittrace/RefusalTraceProbe.java').read_text()
a=a.replace('return n.contains("recoverInterruptedReplacementLocked")','return n.equals("open")||n.equals("openInMemory")||n.equals("openNamed")||n.contains("recoverInterruptedReplacementLocked")')
t=t.replace('+q(Thread.currentThread().getName())+', '+q(Thread.currentThread().getName())+",\\\"threadId\\\":"+Thread.currentThread().threadId()+",\\\"receiverId\\\":"+System.identityHashCode(receiver)+')
oldresult='value.getClass().getName()+(value instanceof Enum<?>?":"+value.toString():"")';newresult='value.getClass().getName()+"@"+System.identityHashCode(value)+(value instanceof Enum<?>?":"+value.toString():"")';assert oldresult in t;t=t.replace(oldresult,newresult)
(sdir/'Agent.java').write_text(a);(sdir/'RefusalTraceProbe.java').write_text(t)
flags=['--add-exports','java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED','--add-exports','java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED']
subprocess.run(['/workspace/jdk21/bin/javac',*flags,'-d',str(cdir),str(sdir/'Agent.java'),str(sdir/'RefusalTraceProbe.java')],check=True)
with zipfile.ZipFile(w/'trace-helper.jar','w') as z:z.write(cdir/'org/robolectric/internal/bytecode/RefusalTraceProbe.class','org/robolectric/internal/bytecode/RefusalTraceProbe.class')
with zipfile.ZipFile(w/'trace-agent.jar','w') as z:
 z.writestr('META-INF/MANIFEST.MF','Manifest-Version: 1.0\nPremain-Class: audittrace.Agent\nCan-Retransform-Classes: true\n\n')
 for p in (cdir/'audittrace').glob('Agent*.class'):z.write(p,p.relative_to(cdir).as_posix())
(w/'AGENT_BUILD.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [sdir/'Agent.java',sdir/'RefusalTraceProbe.java',w/'trace-helper.jar',w/'trace-agent.jar']},indent=2)+'\n')
(w/'generation_recipe.py').write_text(Path(__file__).read_text());(w/'run.py').write_text((old/'run.py').read_text().replace('TRACED_DELETE_V3','TRACED_STARTUP_V4'));(w/'resources.gradle').write_text((old/'resources.gradle').read_text().replace('unit3-refusal-trace-2026-10-21-v3/','unit3-refusal-trace-2026-10-21-v4/'))
r=Path('/workspace/russian-companion');assert not subprocess.check_output(['git','status','--porcelain'],cwd=r,text=True)
with (w/'LAUNCHER.log').open('wb') as out:p=subprocess.Popen([sys.executable,str(w/'run.py'),'TRACED_STARTUP_V4'],stdin=subprocess.DEVNULL,stdout=out,stderr=subprocess.STDOUT,start_new_session=True,close_fds=True)
(w/'SESSION.json').write_text(json.dumps({'pid':p.pid,'sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'launchedEpoch':time.time(),'scope':'9diagnostic methods;store/open/thread identity added','automaticMutationOrPublicationQueued':False},indent=2)+'\n');print('Detached startup tracer PID',p.pid)
