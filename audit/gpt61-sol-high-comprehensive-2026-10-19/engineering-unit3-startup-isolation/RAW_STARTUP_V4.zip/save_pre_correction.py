from pathlib import Path
import json,hashlib,zipfile,shutil,subprocess
R=Path('/workspace/russian-companion');B=R/'audit/gpt61-sol-high-comprehensive-2026-10-19';D=B/'engineering-unit3-startup-isolation';D.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();save=lambda n,v:(D/n).write_text(json.dumps(v,indent=2)+'\n')
attempts=[('HARNESS_V1','/workspace/artifacts/unit3-refusal-trace-2026-10-21','TRACED_CONTROL'),('PATH_V2','/workspace/artifacts/unit3-refusal-trace-2026-10-21-v2','TRACED_CONTROL_V2'),('DELETE_V3','/workspace/artifacts/unit3-refusal-trace-2026-10-21-v3','TRACED_DELETE_V3'),('STARTUP_V4','/workspace/artifacts/unit3-refusal-trace-2026-10-21-v4','TRACED_STARTUP_V4')];records=[]
for label,path,mode in attempts:
 w=Path(path);o=w/mode;x=json.loads((o/'RESULT.json').read_text());c=json.loads((o/'CONTEXT.json').read_text());assert x['sourceCommit']==c['sourceCommit']=='640c32075e34f4917d9f92b5509e8261fa05fb59';assert x['selectedFreshXmlAndEventsMatch'] and x['eventOutcomeCountsMatchXml'];dest=D/'DIAGNOSTICS'/label;dest.mkdir(parents=True)
 for n in ['RESULT.json','CONTEXT.json','RESULTS.csv','RUN.exit']:shutil.copy2(o/n,dest/n)
 archive=D/('RAW_'+label+'.zip');idx=[]
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
  for p in sorted(w.rglob('*')):
   if p.is_file():n=p.relative_to(w).as_posix();z.write(p,n);idx.append(dict(path=n,bytes=p.stat().st_size,sha256=sha(p)))
 with zipfile.ZipFile(archive) as z:
  assert z.testzip() is None
  for row in idx:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
 save('RAW_'+label+'_INDEX.json',dict(archive=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,members=idx,crcAndAllMemberHashesVerified=True))
 records.append(dict(label=label,sourceCommit=x['sourceCommit'],counts=x['testCounts'],classes=x['classes'],exitCode=x['exitCode'],classification='EXTERNAL_HARNESS_FAILURE_HELPER_CLASS_NOT_VISIBLE;original assertions not reached' if label=='HARNESS_V1' else 'TRACED_DIAGNOSTIC_NOT_UNINSTRUMENTED_ACCEPTANCE',inputTrees=c['inputTrees']))
w=Path(attempts[-1][1])/attempts[-1][2];p=next((w/'TRACE').glob('trace-*.jsonl'));rs=[json.loads(l) for l in p.read_text().splitlines()];target='dev.russiancompanion.v2.Unit3GenderTeachingTest#freshTeachingAndAnswersReestablishCompletionWithoutRelabellingOldAssignments()V';failed=[(i,x) for i,x in enumerate(rs) if x['test']==target and x['kind']=='ARETURN' and '#replaceGovernedLearnerBody(' in x['method'] and ':UNCHANGED' in x['value']];assert len(failed)==1;end,bad=failed[0]
recover=[(i,x) for i,x in enumerate(rs[:end]) if x['test']==target and x['kind']=='ENTER' and '#recoverInterruptedReplacementLocked' in x['method'] and 'sweepOrphan' in x['value']];assert len(recover)==1;ri,rec=recover[0];assert rec['receiverId']!=bad['receiverId'] and rec['threadId']!=bad['threadId']
open_return=[(i,x) for i,x in enumerate(rs) if x['kind']=='ARETURN' and '#open(' in x['method'] and x['value'].endswith('@'+str(rec['receiverId']))];assert len(open_return)==1;oi,oret=open_return[0]
open_enter=[(i,x) for i,x in enumerate(rs[:oi]) if x['kind']=='ENTER' and '#open(' in x['method'] and x['threadId']==oret['threadId']];ei,oe=open_enter[-1];assert 'RussianCompanionApplication.openStore' in oe['value'] and 'onCreate$lambda' in oe['value']
deletion=[(i,x) for i,x in enumerate(rs[ri:end],ri) if x['kind']=='DELETE_SUCCESS' and x['threadId']==rec['threadId'] and x['value'].endswith('backup-replace-recordings.json')];assert len(deletion)==1;di,de=deletion[0]
mark=[(i,x) for i,x in enumerate(rs[di:end],di) if x['kind']=='IRETURN' and '#markReplacementJournalCommitted' in x['method'] and x['value']=='0'];assert len(mark)==1
indices=sorted(set([ei,ri,di-1,di,oi,mark[0][0],end]));save('DECISIVE_TRACE.json',dict(traceArchive='RAW_STARTUP_V4.zip',tracePath=p.relative_to(Path(attempts[-1][1])).as_posix(),traceSha256=sha(p),sourceCommit=records[-1]['sourceCommit'],rows=[dict(oneBasedLine=i+1,event=rs[i]) for i in indices],startupStoreId=rec['receiverId'],testStoreId=bad['receiverId'],startupStoreThread=rec['threadId'],testStoreThread=bad['threadId'],diagnosticCause='Background application startup store recovers/deletes another test-owned store active journal on shared recording root;commit-marker missing causes rollback/UNCHANGED',originalBroadRunCause='Untraced historical observation;mechanism reproduced in same original method with identical app/test/catalog/docs/review inputs,not a retroactive trace',oldUnit7Cause='UNCONFIRMED',testLabelLimit='Global current test entry is a hint;async startup begins before test entry. Correlation uses returned store identity,thread,call stack and exact root path.'))
save('PRE_CORRECTION_SCOPES.json',dict(scopes=records,scopesNotSummed=True,original1323RegressionUnchanged=True,expectedCounts={'HARNESS_V1':'0pass/9harnessfail','PATH_V2':'8pass/1fail','DELETE_V3':'9pass','STARTUP_V4':'7pass/2fail'},physicalAcceptance='OUTSTANDING_LAST'))
p=R/'app/src/test/java/dev/russiancompanion/v2/Unit3GenderTeachingTest.kt';old=p.read_text();anchor='    @get:Rule val compose = createComposeRule()\n';insert='''
    @Before fun finishApplicationStartupBeforeOwningTheRecordingRoot() {
        (context().applicationContext as dev.russiancompanion.RussianCompanionApplication).closeStartupStoreForTests()
    }
''';assert old.count(anchor)==1;new=old.replace(anchor,anchor+insert);p.write_text(new);assert new.replace(insert,'',1)==old
save('METHOD_BOUNDARIES.json',dict(path=p.relative_to(R).as_posix(),originalCommit='640c32075e34f4917d9f92b5509e8261fa05fb59',oldSha256=hashlib.sha256(old.encode()).hexdigest(),newSha256=sha(p),exactOnlyInsertion=insert,removingSingleInsertionRestoresEveryOriginalByte=True,allSevenOriginalTestBodiesUnchanged=True,productionCodeChanged=False,backupBytesOrAssertionsChanged=False))
(D/'SOURCE_CHANGE.patch').write_text(subprocess.check_output(['git','diff','--',str(p.relative_to(R))],cwd=R,text=True))
(D/'STATUS.md').write_text('''# Unit3 startup isolation correction — verification pending

Traced source640c32075e34f4917d9f92b5509e8261fa05fb59 reproduces the original Unit3 fresh-teaching assertion and a separate older-policy assertion. DECISIVE_TRACE.json links application-startup open result/store identity to a competing sweep deleting the active test-owned journal,followed by commit-marker false and rollback/UNCHANGED. Same five input trees as6ab9d87e broad source. Original broad run has no return-path trace;do not invent it or assign this cause to old Unit7.

Only change:add existing closeStartupStoreForTests in Unit3@Before,waiting for application startup/open/sweep and closing its store before test fixtures own the shared recordings directory. All original source bytes/test bodies/assertions restored by removing this one insertion. No production/policy/schema/asset changes. First tracer attempt9harnessfail duehelpervisibility;preserved separately. Then traced scopes8pass/1fail,9pass,7pass/2fail with nine selected methods each,not summed;two existing fault controls are synthetic and not spontaneous app failures. A current tracer label alone is not async identity;use actual store/thread/root/stack correlation.

Corrected-source verification PENDING. Run the same nine-method traced controls then a separate uninstrumented four-class25method scope before recording an engineering reconciliation. Preserve all66archives/64histories/167historical-generated/154current-generated/candidate bytes. Original1323reported/1321pass/1fail/1physicalskip remains immutable. AuditINCOMPLETE;17qualified external findings unclosed. Physical acceptanceLAST after final comprehensive independent nonphysical audit/recheck;no assembly/install/signing/merge/freeze/approval.
''')
summary='Unit3 startup isolation correction prepared,verificationPENDING:external tracer reproduces original assertion and ties competing journal deletion to background application startup store;single@Before uses existing startup-wait/close helper,all7original test bodies/assertions unchanged,production untouched. See engineering-unit3-startup-isolation/STATUS.md and DECISIVE_TRACE.json. Original broad failure retained;oldUnit7causeUNCONFIRMED;physicalLAST;no release approval.'
p=R/'AGENTS.md';p.write_text(p.read_text().replace('# Codex continuation\n','# Codex continuation\n\nCurrent engineering checkpoint: [Unit3 startup isolation prepared](audit/gpt61-sol-high-comprehensive-2026-10-19/engineering-unit3-startup-isolation/STATUS.md). '+summary+'\n',1))
for name in ['CODEX_ENGINEERING_CONTINUATION.md','CODEX_CHECKPOINT_2026-10-12.md']:
 with (R/'audit/content-corrections'/name).open('a') as f:f.write('\n\n## Unit3 startup isolation prepared\n\n'+summary+'\n')
save('SHA256_PRE_CORRECTION.json',{p.relative_to(D).as_posix():sha(p) for p in sorted(D.rglob('*')) if p.is_file() and p.name!='SHA256_PRE_CORRECTION.json'})
subprocess.run(['git','diff','--check'],cwd=R,check=True)
subprocess.run(['git','add','--','AGENTS.md','audit/content-corrections/CODEX_ENGINEERING_CONTINUATION.md','audit/content-corrections/CODEX_CHECKPOINT_2026-10-12.md','app/src/test/java/dev/russiancompanion/v2/Unit3GenderTeachingTest.kt',str(D.relative_to(R))],cwd=R,check=True)
subprocess.run(['git','commit','-m','Isolate Unit3 fixtures from the application startup sweep'],cwd=R,check=True)
print(subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip())
