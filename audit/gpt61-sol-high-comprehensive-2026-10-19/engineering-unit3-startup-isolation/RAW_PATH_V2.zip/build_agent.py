from pathlib import Path
import subprocess,zipfile,json,hashlib
W=Path(__file__).parent;S=W/'agent-src/audittrace';S.mkdir(parents=True);C=W/'agent-classes';C.mkdir()
(S/'RefusalTraceProbe.java').write_text(r'''package org.robolectric.internal.bytecode;
import java.io.*;import java.nio.file.*;import java.time.Instant;import java.util.*;
public final class RefusalTraceProbe {
 private static volatile String test="UNATTRIBUTED";
 private static String q(Object o){String s=String.valueOf(o);StringBuilder b=new StringBuilder("\"");for(char c:s.toCharArray()){switch(c){case '"':b.append("\\\"");break;case '\\':b.append("\\\\");break;case '\n':b.append("\\n");break;case '\r':b.append("\\r");break;case '\t':b.append("\\t");break;default:if(c<32)b.append(String.format("\\u%04x",(int)c));else b.append(c);}}return b.append('"').toString();}
 private static String stat(File f){if(f==null)return "null";File[] a=f.listFiles();StringBuilder b=new StringBuilder(f.getAbsolutePath()+"[exists="+f.exists()+",dir="+f.isDirectory()+",len="+f.length()+"]");if(a!=null){Arrays.sort(a,Comparator.comparing(File::getName));for(int i=0;i<Math.min(20,a.length);i++)b.append(" ").append(a[i].getName()).append(":").append(a[i].isDirectory()?"D":"F").append(":").append(a[i].length());}return b.toString();}
 private static String root(Object receiver){try{if(receiver==null)return "STATIC";var f=receiver.getClass().getDeclaredField("recordingRoot");f.setAccessible(true);File r=(File)f.get(receiver);if(r==null)return "NO_ROOT";return stat(r)+" | "+stat(new File(r.getParentFile(),"backup-replace-"+r.getName()+"-workspace"))+" | "+stat(new File(r.getParentFile(),"backup-replace-"+r.getName()+".json"));}catch(Throwable t){return "ROOT_OBSERVATION_UNAVAILABLE:"+t.getClass().getName();}}
 private static synchronized void emit(String kind,String method,int line,String value,Object receiver){try{String d=System.getProperty("audit.refusal.trace");if(d==null)return;long pid=ProcessHandle.current().pid();String row="{\"atUtc\":"+q(Instant.now())+",\"nano\":"+System.nanoTime()+",\"pid\":"+pid+",\"thread\":"+q(Thread.currentThread().getName())+",\"test\":"+q(test)+",\"kind\":"+q(kind)+",\"method\":"+q(method)+",\"line\":"+line+",\"value\":"+q(value)+",\"rootMetadata\":"+q(root(receiver))+"}\n";Files.writeString(Path.of(d,"trace-"+pid+".jsonl"),row,StandardOpenOption.CREATE,StandardOpenOption.APPEND);}catch(Throwable t){System.err.println("AUDIT_TRACE_ERROR "+t.getClass().getName());}}
 public static void test(String name){test=name;emit("TEST_ENTER",name,-1,"",null);}
 public static void enter(String method,int line,Object self){emit("ENTER",method,line,"",self);}
 public static void result(Object value,String method,int line,Object self){emit("ARETURN",method,line,value==null?"null":value.getClass().getName()+(value instanceof Enum<?>?":"+value.toString():""),self);}
 public static void integer(int value,String method,int line,Object self){emit("IRETURN",method,line,Integer.toString(value),self);}
 public static void caught(Throwable t,String method,int line,Object self){StringBuilder b=new StringBuilder(t.getClass().getName()+":"+String.valueOf(t.getMessage()));if(b.length()>400)b.setLength(400);StackTraceElement[] s=t.getStackTrace();for(int i=0;i<Math.min(12,s.length);i++)b.append(" | ").append(s[i]);emit("CAUGHT",method,line,b.toString(),self);}
}''')
(S/'Agent.java').write_text(r'''package audittrace;
import java.lang.instrument.*;import java.security.*;import java.nio.file.*;import java.util.*;import java.util.jar.*;
import jdk.internal.org.objectweb.asm.*;import jdk.internal.org.objectweb.asm.tree.*;
public final class Agent {
 private static String dir;
 public static void premain(String helper,Instrumentation inst)throws Exception{dir=System.getProperty("audit.refusal.trace");if(dir==null)throw new IllegalStateException("audit.refusal.trace required");Files.createDirectories(Path.of(dir));inst.appendToBootstrapClassLoaderSearch(new JarFile(helper));inst.addTransformer(new ClassFileTransformer(){public byte[] transform(ClassLoader loader,String name,Class<?> type,ProtectionDomain domain,byte[] bytes)throws IllegalClassFormatException{
 if(name==null||!(name.equals("dev/russiancompanion/data/local/LocalStore")||name.startsWith("dev/russiancompanion/data/local/LocalStore$")||name.startsWith("dev/russiancompanion/v2/")&&name.endsWith("Test")))return null;
 try{return patch(loader,name,bytes);}catch(Throwable t){System.err.println("AUDIT_AGENT_TRANSFORM_ERROR "+name+" "+t);throw new IllegalClassFormatException(t.toString());}
 }});}
 private static boolean target(String n){return n.contains("replaceGovernedLearner")||n.contains("replaceDocumentOnly")||n.contains("referencesResolve")||n.contains("copyRecordingFiles")||n.contains("stageIncomingRecordings")||n.contains("writeReplacementJournal")||n.contains("writeJournalAtomically")||n.contains("publishStagedRecordings")||n.contains("rollbackReplacementFiles")||n.contains("markReplacementJournalCommitted");}
 private static void self(InsnList x,MethodNode m){if((m.access&Opcodes.ACC_STATIC)!=0)x.add(new InsnNode(Opcodes.ACONST_NULL));else x.add(new VarInsnNode(Opcodes.ALOAD,0));}
 private static InsnList call(String kind,MethodNode m,String id,int line){InsnList x=new InsnList();x.add(new LdcInsnNode(id));x.add(new LdcInsnNode(line));self(x,m);x.add(new MethodInsnNode(Opcodes.INVOKESTATIC,"org/robolectric/internal/bytecode/RefusalTraceProbe",kind,kind.equals("enter")?"(Ljava/lang/String;ILjava/lang/Object;)V":kind.equals("integer")?"(ILjava/lang/String;ILjava/lang/Object;)V":kind.equals("caught")?"(Ljava/lang/Throwable;Ljava/lang/String;ILjava/lang/Object;)V":"(Ljava/lang/Object;Ljava/lang/String;ILjava/lang/Object;)V",false));return x;}
 private static String sha(byte[] b)throws Exception{return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(b));}
 private static byte[] patch(ClassLoader loader,String name,byte[] bytes)throws Exception{
 ClassNode c=new ClassNode(Opcodes.ASM8);new ClassReader(bytes).accept(c,0);int count=0;List<String> changed=new ArrayList<>();
 for(MethodNode m:c.methods){if(m.instructions.size()==0)continue;String id=name.replace('/','.')+"#"+m.name+m.desc;boolean test=m.visibleAnnotations!=null&&m.visibleAnnotations.stream().anyMatch(a->a.desc.equals("Lorg/junit/Test;"));
 if(test){InsnList x=new InsnList();x.add(new LdcInsnNode(id));x.add(new MethodInsnNode(Opcodes.INVOKESTATIC,"org/robolectric/internal/bytecode/RefusalTraceProbe","test","(Ljava/lang/String;)V",false));m.instructions.insert(x);count++;changed.add(id+":TEST");}
 if(!name.startsWith("dev/russiancompanion/data/local/LocalStore")||!target(m.name))continue;
 AbstractInsnNode[] original=m.instructions.toArray();int line=-1;for(var a:original)if(a instanceof LineNumberNode l){line=l.line;break;}m.instructions.insert(call("enter",m,id,line));Set<AbstractInsnNode> handlers=new HashSet<>();for(TryCatchBlockNode t:m.tryCatchBlocks){AbstractInsnNode a=t.handler;while(a!=null&&a.getOpcode()<0)a=a.getNext();if(a!=null)handlers.add(a);}
 for(AbstractInsnNode a:original){if(a instanceof LineNumberNode l)line=l.line;if(handlers.contains(a)){InsnList x=new InsnList();x.add(new InsnNode(Opcodes.DUP));x.add(call("caught",m,id,line));m.instructions.insertBefore(a,x);}int op=a.getOpcode();if(op==Opcodes.ARETURN||op==Opcodes.IRETURN){InsnList x=new InsnList();x.add(new InsnNode(Opcodes.DUP));x.add(call(op==Opcodes.ARETURN?"result":"integer",m,id,line));m.instructions.insertBefore(a,x);}}
 count++;changed.add(id+":PATH");}
 if(count==0)return null;ClassWriter cw=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(cw);byte[] out=cw.toByteArray();String stem=ProcessHandle.current().pid()+"-"+Integer.toHexString(System.identityHashCode(loader))+"-"+name.replace('/','_');Path p=Path.of(dir,"classes");Files.createDirectories(p);Files.write(p.resolve(stem+".incoming.class"),bytes);Files.write(p.resolve(stem+".traced.class"),out);Files.writeString(p.resolve(stem+".identity.txt"),"incomingSha256="+sha(bytes)+"\ntracedSha256="+sha(out)+"\n"+String.join("\n",changed)+"\n");return out;
 }
}''')
flags=['--add-exports','java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED','--add-exports','java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED']
subprocess.run(['/workspace/jdk21/bin/javac',*flags,'-d',str(C),str(S/'RefusalTraceProbe.java'),str(S/'Agent.java')],check=True)
with zipfile.ZipFile(W/'trace-helper.jar','w') as z:z.write(C/'org/robolectric/internal/bytecode/RefusalTraceProbe.class','org/robolectric/internal/bytecode/RefusalTraceProbe.class')
with zipfile.ZipFile(W/'trace-agent.jar','w') as z:
 z.writestr('META-INF/MANIFEST.MF','Manifest-Version: 1.0\nPremain-Class: audittrace.Agent\n\n')
 for p in (C/'audittrace').glob('Agent*.class'):z.write(p,p.relative_to(C).as_posix())
(W/'AGENT_BUILD.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [S/'Agent.java',S/'RefusalTraceProbe.java',W/'trace-helper.jar',W/'trace-agent.jar']},indent=2)+'\n')
print('Built external diagnostic agent/helper;repository unchanged')
