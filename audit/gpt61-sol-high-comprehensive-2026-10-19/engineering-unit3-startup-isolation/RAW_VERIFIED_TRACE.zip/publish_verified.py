from pathlib import Path
import json,hashlib,zipfile,shutil,subprocess
R=Path('/workspace/russian-companion');W=Path(__file__).parent;B=R/'audit/gpt61-sol-high-comprehensive-2026-10-19';D=B/'engineering-unit3-startup-isolation';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();save=lambda n,v:(D/n).write_text(json.dumps(v,indent=2)+'\n');git=lambda *a:subprocess.check_output(['git',*a],cwd=R,text=True).strip()
assert git('rev-parse','HEAD')=='73dfdb66aca623e9221da57913a1e04af2ecfe32' and not git('status','--porcelain');scopes=[]
for label,o,root,expected in [('VERIFIED_TRACE',W/'VERIFIED_TRACE',W,9),('VERIFIED_NEIGHBORS',W/'neighbors/VERIFIED_NEIGHBORS',W/'neighbors',25)]:
 x=json.loads((o/'RESULT.json').read_text());c=json.loads((o/'CONTEXT.json').read_text());assert x['sourceCommit']==c['sourceCommit']==git('rev-parse','HEAD') and x['exitCode']==0 and x['testCounts']==dict(reported=expected,passed=expected,failed=0,errors=0,skipped=0);assert x['selectedFreshXmlAndEventsMatch'] and x['eventOutcomeCountsMatchXml'] and x['allSelectedMethodsReported']
 for n,h in json.loads((o/'SHA256.json').read_text()).items():assert sha(o/n)==h,n
 assert all(git('rev-parse','HEAD:'+p)==h for p,h in c['inputTrees'].items());dest=D/label;dest.mkdir()
 for n in ['RESULT.json','CONTEXT.json','RESULTS.csv','RUN.exit','LINT.xml']:shutil.copy2(o/n,dest/n)
 for n in ['run.py','resources.gradle','SESSION.json']:shutil.copy2(root/n,dest/n)
 archive=D/('RAW_'+label+'.zip');idx=[]
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
  for p in sorted(root.rglob('*')):
   if not p.is_file() or (label=='VERIFIED_TRACE' and p.is_relative_to(W/'neighbors')):continue
   n=p.relative_to(root).as_posix();z.write(p,n);idx.append(dict(path=n,bytes=p.stat().st_size,sha256=sha(p)))
 with zipfile.ZipFile(archive) as z:
  assert z.testzip() is None
  for row in idx:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
 save('RAW_'+label+'_INDEX.json',dict(archive=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,members=idx,crcAndAllMemberHashesVerified=True))
 scopes.append(dict(name=label,sourceCommit=x['sourceCommit'],counts=x['testCounts'],classes=x['classes'],exitCode=x['exitCode'],tasks=x['tasks'],lintIssuesBySeverity=x['lintIssuesBySeverity'],externalJavaAgent=label=='VERIFIED_TRACE'))
shutil.copy2(W/'POST_CORRECTION_TRACE_PROOF.json',D/'POST_CORRECTION_TRACE_PROOF.json');td=D/'TRACER_SOURCE';td.mkdir()
for name in ['Agent.java','RefusalTraceProbe.java']:shutil.copy2(W/'agent-src/audittrace'/name,td/name)
(td/'MANIFEST.MF').write_text('Manifest-Version: 1.0\nPremain-Class: audittrace.Agent\nCan-Retransform-Classes: true\n\n')
(td/'BUILD.md').write_text('''# External diagnostic tracer build

JDK21 only;uses that JDK internal ASM,not a project dependency. Run outside checkout. Compile:

```sh
javac --add-exports java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED --add-exports java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED -d classes Agent.java RefusalTraceProbe.java
jar --create --file trace-helper.jar -C classes org/robolectric/internal/bytecode/RefusalTraceProbe.class
jar --create --file trace-agent.jar --manifest MANIFEST.MF -C classes audittrace
```

Activate Android environment as recorded in CONTEXT.json. Copy/review the diagnostic resources.gradle with explicit new absolute agent/helper/trace paths. Do not replace saved environment setup with this tracer. These are external diagnostic helpers only;never app assets/dependencies. The uninstrumented scope has no javaagent. Raw archives include the exact binaries used,their hashes and incoming/transformed class bytes/identities. A rebuild can have different JAR timestamps/hash;record its actual identity. Original generation scripts in raw archives are historical recipes using explicit prior-attempt paths,not portable startup commands.

The agent instruments selected test entry points and LocalStore replacement/open/recovery/return/catch paths. Final version also traces successful/failed File/Files deletions matching Unit3 temporary or backup-journal paths. It records metadata,not learner document or private-book contents. It appends a bootstrap helper and adds a java.base read edge so JDK deletion methods can call that helper. Instrumented execution perturbs timing and is diagnostic,not uninstrumented acceptance. Global current test label is an entry hint;async calls beginning before test entry must be correlated by PID/thread/store return identity/exact root/call stack,as DECISIVE_TRACE.json demonstrates.
''')
bounds=json.loads((D/'METHOD_BOUNDARIES.json').read_text());p=R/bounds['path'];old=subprocess.check_output(['git','show',bounds['originalCommit']+':'+bounds['path']],cwd=R);assert p.read_bytes().replace(bounds['exactOnlyInsertion'].encode(),b'',1)==old;assert sha(p)==bounds['newSha256'];assert git('diff','--name-only',bounds['originalCommit'],'HEAD','--','app/src/test')==bounds['path']
base=json.loads((B/'post-reconciliation-host-regression-2026-10-21/REGRESSION/CONTEXT.json').read_text());assert all(git('rev-parse','HEAD:'+k)==v for k,v in base['inputTrees'].items() if k!='app/src/test')
prior=json.loads((B/'post-reconciliation-host-regression-2026-10-21/CONSERVATION.json').read_text());
for n,h in prior['all66ArchiveHashesMatched'].items():assert sha(R/n)==h
hist=B/'engineering-pending-evidence-reconciliation';hi=json.loads((hist/'HISTORICAL_GENERATED_EVIDENCE_INDEX.json').read_text());assert sha(hist/hi['archive'])==hi['archiveSha256']
with zipfile.ZipFile(hist/hi['archive']) as z:
 assert z.testzip() is None
 for row in hi['members']:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
for row in json.loads((hist/'PROPOSAL_REVIEW.json').read_text())['files']:assert sha(R/row['path'])==row['newSha256']
assert sha(R/'release/acceptance/candidate.json')==prior['candidateUnchangedSha256'];assert not [p for p in git('ls-files').splitlines() if p.lower().endswith('.pdf')]
save('CONSERVATION.json',dict(testedSource=git('rev-parse','HEAD'),original66ArchiveHashesReverified=True,original64HistoriesPreserved=True,historical167FileArchiveCrcAllMemberHashesReverified=True,current154GeneratedFileHashesReverified=True,candidateSha256=prior['candidateUnchangedSha256'],allFourProductionCatalogDocsReviewTreesMatchOriginalBroadSource=True,onlyTestFileChanged=bounds['path'],allOriginalBytesExceptSingleBeforeInsertionUnchanged=True,apkAssemblyInstallSigning=False,oldUnit7Cause='UNCONFIRMED',physicalAcceptance='OUTSTANDING_LAST'))
save('VERIFIED_SCOPES.json',dict(scopes=scopes,scopesOverlapNotSummed=True,original1323RegressionResultUnchanged=True,completeSuite=False,qualifiedExternal17FindingsUnclosed=True))
report='''# Unit3 fixture startup isolation — scoped verification completed

Tested source `73dfdb66aca623e9221da57913a1e04af2ecfe32`. The only code change is one Unit3GenderTeachingTest@Before using the existing RussianCompanionApplication.closeStartupStoreForTests helper. It waits for default application startup/open/sweep and closes that background store before the test owns its in-memory learner database and shared recordings directory. All seven original test bodies/assertions and every other byte of that source file remain exact after removing this one insertion. No production/application/policy/schema/curriculum/backup change,no assertion retries or outcome relaxation. METHOD_BOUNDARIES.json and SOURCE_CHANGE.patch preserve review evidence. Existing helper/convention:RussianCompanionApplication.kt:41,Unit13PastTeachingTest.kt:155 and Unit7CurrentPrerequisiteHistoryTest.kt.

## Diagnosis and limits

At pre-correction source640c3207 (same five input trees as original broad6ab9d87e),the external tracer reproduced the original freshTeachingAndAnswersReestablishCompletionWithoutRelabellingOldAssignments assertion as well as a separate older-policy method. DECISIVE_TRACE.json binds actual returned startup-store identity to RussianCompanionApplication.onCreate/openStore call stack;different store/thread identities operate on the same exact Unit3 temporary recording root. The startup sweep calls recoverInterruptedReplacementLocked,successfully deletes the active test journal (LocalStore.kt:2089),and removes the workspace. The test-owned store then returnsfalse at markReplacementJournalCommitted:1972 and rolls back/returnsUNCHANGED:1566. No caught exception accounts for that refusal;the captured journal-deletion/false-return chain does. This diagnoses the traced reproductions. The original uninstrumented broad run has no equivalent trace;its raw observation stays immutable,not retroactively instrumented. Old Unit7 restore-refusal cause remains UNCONFIRMED.

Diagnostic sequence,all before correction and all separately preserved:HARNESS_V1 nine reported/zero passed/nine helper-loading failures,exit1;original assertions not reached,no app-defect inference. PATH_V2 nine reported/eightpassed/oneUnit3older-policyfailure,exit1;commit-marker journalmissing/rollback path captured. DELETE_V3 ninepassed,exit0;filesystem deletion caller tracing added,not a fix. STARTUP_V4 nine reported/sevenpassed/twoUnit3failures,exit1;exact startup-store/thread/deletion correlation and original failing assertion reproduced. Two existing BackupLicense fault-control methods deliberately inject failure;their expected refusals are controls,not spontaneous defects. Instrumentation records metadata and perturbs timing;these are diagnostic runs. Async labels alone do not establish ownership:use store return identity/thread/PID/root/call stack. Original class7/7 and neighbor25/25 prior passing attempts remain separate in engineering-unit3-replacement-diagnosis;none erases the broad failure.

## Corrected-source verification

- VERIFIED_TRACE:9selected methods/2classes,9passed/0failed/0errors/0skipped,exit0. Full unchanged seven Unit3test bodies plus two existing BackupLicense synthetic fault controls. Exact same final agent/helper binaries as STARTUP_V4. POST_CORRECTION_TRACE_PROOF.json records all25Unit3replacement calls returningREPLACED with no other store's same-root recovery inside any replacement window. Those25calls are internal observations,not25extra test methods. Synthetic fault refusals/exception remain separately observable and asserted.
- VERIFIED_NEIGHBORS:25selected methods/4fullclasses,25passed/0failed/0errors/0skipped,exit0,without any Javaagent. Includes Unit30InstructionTest,Unit3GenderTeachingTest,Unit4NominativeRoleTest,Unit4PresentTeachingTest;single6GiBworker/forkEvery4. These are neighboring-context checks,not exact original broad worker/PID reconstruction.

Both scopes have fresh XML/RESULT event/selector identity and outcome agreement,actual exits,source/input/init/runner hashes and per-method records. They overlap and are not summed. The original1323reported/1321passed/1failed/0errors/1physicalskip,219class,exit1 broad result remains unchanged. This is a scoped engineering reconciliation,not a fresh all-class/broad/complete-suite result or independent acceptance. A new fresh discovery/uninterrupted selected-host regression is the next large task.

LintDebug and gateattachment passed in both scopes. Traced corrected-source run executed compileDebugUnitTestKotlin and lintAnalyzeDebugUnitTest;main compilation/analysis UP-TO-DATE. Later neighbor compilation/lint analysis UP-TO-DATE;exact states are in VERIFIED_SCOPES.json. Retained lint0fatal/0errors/20warnings/1hint. Gateattachment is not release approval. APK configureddev.russiancompanion/2.0.0-dev/code5,current artifact/hash/signature NOT_ESTABLISHED;no assembly/install/signing.

Four screenshot exporters/16methods remain explicitly excluded:VisualReviewCaptureTest2,Units35ChunkCaptureTest2,Units610ChunkCaptureTest10,Units1115GapCaptureTest2. No WRITE_* regeneration. All66original archives/64histories,167historical-generated archive members,154current-generated files and candidate identity reverified;main/catalog/docs/review trees match original broad source. Only the Unit3fixture setup changes the test tree. Raw diagnostic and verification archives are CRC/every-member-SHA verified;all prior failed scopes retained. No private PenguinPDF in app branch/assets/outputs;reference/source qualification remains independent.

This fixes test fixture ownership;it does not change or certify production multi-store recovery arbitration. Original17qualified external findings and CC003 contextual/native/source/rights gaps remain unclosed. AuditINCOMPLETE. Final comprehensive independent nonphysical audit/recheck precedes actual Galaxy S26 Ultra airplane-mode/reboot acceptance,which staysLAST/outstanding. No merge,freeze,formal advancement,owner or release approval. Environment install/start settings remain saved/unchanged;publication user-confirmed independently unverified. No active job or automatic publisher.
'''
(D/'ENGINEERING_CHANGE_REPORT.md').write_text(report)
(D/'NEXT_LARGE_TASK.md').write_text('''# Next large task: fresh corrected-source discovery and uninterrupted host regression

Read ENGINEERING_CHANGE_REPORT.md,DECISIVE_TRACE.json,METHOD_BOUNDARIES.json,POST_CORRECTION_TRACE_PROOF.json and VERIFIED_SCOPES.json here. Only Unit3@Before changed;all seven original test bodies/fixture bytes and production inputs preserved. Corrected source73dfdb66aca623e9221da57913a1e04af2ecfe32 has traced9/9 and separate uninstrumented25/25 scoped passes,not a new broad result. Original broad6ab9d87e1323reported/1321pass/1fail/1physicalskip,exit1 remains immutable;its untracedexactpath is not retroactively proven. Traced same-input reproduction identifies startup-store journal deletion;oldUnit7causeUNCONFIRMED.

Use oneagent/existingcheckout/PR64. No active test job or automatic publisher. First verify clean currentsource/four unchanged production trees/only expected testsetup change,then fresh hostdiscovery and exact method identity comparison. Expect no testmethod additions from a@Before,butprove discovery rather than assuming1323/219. Preserve original discovery/results,all66archives/64histories/generated evidence/candidate. Keep fourexporters/16methods excluded explicitly. Use established detached runner/two6GiBmaximum forks/recycle4/GC logs and appropriate currentresource observations. Run without Javaagent for genuine current hostregression;do not copy synthetic discovery skips into runtime pass counts. No source/input edits while active. Capture underlying exit,freshXML/events/method/outcome agreement and exact command/task/lint/cache states before publishing. Preserve every failure and stopcause uncertainty;no retry-until-success or assertion relaxation. New failure scopes remain separate;do not sum focused/overlapping/stopped scopes into complete-suite claims.

After the fresh regression,continue final comprehensive independent nonphysical audit/recheck preparation against exact correctedsource,private reference and all unread file/entity/book/source/rights/70execution-request scope. Test success does not close original17qualified findings. Missing originalaudit/fourCSVs and Claudeoutputs remain unavailable. Private reference stays outside appbranch/assets/packets. Physical Galaxy S26 Ultra airplane-mode/reboot acceptanceLAST. No APK assembly/install/signing/merge/freeze/formal advancement/owner or release approval.
''')
summary='Unit3 startup isolation verified at73dfdb66aca623e9221da57913a1e04af2ecfe32:traced9methods/2classes9passed and separate uninstrumented25methods/4classes25passed,zero failures/errors/skips,exit0each. Same final tracer reproduces original assertion before correction and links background startup-store recovery to active test-journal deletion;postfix25replacement calls allREPLACED,no competing same-root recovery in their windows. Only@Before existing startup-wait/close helper added;all7original test bodies/assertions exact,production untouched. Scopes overlap/not summed;original1323broad failure immutable,no fresh broad/complete-suite/independent acceptance claim. OldUnit7causeUNCONFIRMED. All66archives/64histories/167historical-generated/154current-generated/candidate conserved. Nextlarge:fresh discovery and uninterrupted uninstrumented hostregression. AuditINCOMPLETE;17qualified findings unclosed;physicalLAST;no assembly/signing/merge/freeze/approval.'
(D/'COMPLETED_STATUS.md').write_text('# Unit3 fixture startup isolation verified\n\n'+summary+'\n\nRead ENGINEERING_CHANGE_REPORT.md and NEXT_LARGE_TASK.md. The original STATUS.md remains historical pre-verification planning evidence;no active job or automatic publisher.\n')
p=R/'AGENTS.md';p.write_text(p.read_text().replace('# Codex continuation\n','# Codex continuation\n\nCurrent engineering checkpoint: [Unit3 startup isolation verified](audit/gpt61-sol-high-comprehensive-2026-10-19/engineering-unit3-startup-isolation/COMPLETED_STATUS.md). '+summary+' Read NEXT_LARGE_TASK.md there;no active job.\n',1))
for name in ['CODEX_ENGINEERING_CONTINUATION.md','CODEX_CHECKPOINT_2026-10-12.md']:
 with (R/'audit/content-corrections'/name).open('a') as f:f.write('\n\n## Unit3 startup isolation verified\n\n'+summary+' Read audit/gpt61-sol-high-comprehensive-2026-10-19/engineering-unit3-startup-isolation/NEXT_LARGE_TASK.md.\n')
save('SHA256_CURRENT.json',{p.relative_to(D).as_posix():sha(p) for p in sorted(D.rglob('*')) if p.is_file() and p.name!='SHA256_CURRENT.json'})
print(summary)
