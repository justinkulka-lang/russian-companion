from pathlib import Path
import subprocess,json,datetime,os,traceback
w=Path(__file__).parent
r=Path('/workspace/russian-companion')
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(name,value):
 with (w/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
try:
 source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()
 with (w/'RUNNER.log').open('xb') as out:
  p=subprocess.Popen(['python3',str(w/'run.py'),'REGRESSION'],cwd=r,stdin=subprocess.DEVNULL,stdout=out,stderr=subprocess.STDOUT)
  save('RUNNER_PROCESS.json',dict(pid=p.pid,supervisorPid=os.getpid(),sourceCommit=source,startedUtc=now(),argv=p.args))
  code=p.wait()
 (w/'LAUNCHER.exit').write_text(str(code)+'\n')
 save('LAUNCHER_COMPLETION.json',dict(runnerExitCode=code,finishedUtc=now(),gradleExit=(w/'REGRESSION/RUN.exit').read_text().strip() if (w/'REGRESSION/RUN.exit').exists() else None,validatedResultExists=(w/'REGRESSION/RESULT.json').exists(),manifestExists=(w/'REGRESSION/SHA256.json').exists(),sourceCommit=source))
except BaseException:
 (w/'SUPERVISOR_ERROR.txt').write_text(traceback.format_exc());raise
