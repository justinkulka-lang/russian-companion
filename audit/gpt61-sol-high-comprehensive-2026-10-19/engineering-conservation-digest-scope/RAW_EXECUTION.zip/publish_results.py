from pathlib import Path
import json,hashlib,zipfile,subprocess,shutil
R=Path('/workspace/russian-companion');W=Path(__file__).parent;D=R/'audit/gpt61-sol-high-comprehensive-2026-10-19/engineering-conservation-digest-scope';O=W/'VERIFIED'
git=lambda *a:subprocess.check_output(['git',*a],cwd=R,text=True).strip();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
x=json.loads((O/'RESULT.json').read_text());c=json.loads((O/'CONTEXT.json').read_text());assert not git('status','--porcelain') and git('rev-parse','HEAD')==c['sourceCommit']=='3346e47620da7c51bec85738df4b5c71b83b0578'
assert x['testCounts']==dict(reported=21,passed=21,failed=0,errors=0,skipped=0) and x['exitCode']==int((O/'RUN.exit').read_text())==0 and x['classes']==12 and x['allSelectedMethodsReported'] and x['selectedFreshXmlAndEventsMatch'] and x['eventOutcomeCountsMatchXml']
base='daf0b7f63ffad33c2c793377df9886e3d1396341';review=json.loads((W/'CODE_REVIEW.json').read_text());changed=git('diff','--name-only',base,'HEAD').splitlines();assert set(changed)=={v['path'] for v in review}|{'app/src/test/java/dev/russiancompanion/v2/RecordedCurriculumConservationScope.kt'}
for v in review:assert sha(R/v['path'])==v['newSha256'] and v['allOriginalLiteralDigestsUnchanged']
boundaries=json.loads((W/'METHOD_BOUNDARIES.json').read_text());assert len(boundaries)==10 and all(v['allBytesOutsideThatMethodIdentical'] for v in boundaries)
D.mkdir();save=lambda n,v:(D/n).write_text(json.dumps(v,indent=2)+'\n');(D/'VERIFIED').mkdir()
for n in ['CONTEXT.json','RESULT.json','RESULTS.csv','RUN.exit','LINT.xml']:shutil.copy2(O/n,D/'VERIFIED'/n)
for n in ['CODE_CHANGE.patch','CODE_REVIEW.json','METHOD_BOUNDARIES.json','SOURCE_RECONCILIATION.json','run_verified.py','resources.gradle']:shutil.copy2(W/n,D/n)
index=[]
with zipfile.ZipFile(D/'RAW_EXECUTION.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(W.rglob('*')):
  if p.is_file():
   n=p.relative_to(W).as_posix();z.write(p,n);index.append(dict(path=n,bytes=p.stat().st_size,sha256=sha(p)))
with zipfile.ZipFile(D/'RAW_EXECUTION.zip') as z:
 assert z.testzip() is None
 for v in index:assert hashlib.sha256(z.read(v['path'])).hexdigest()==v['sha256']
save('RAW_EXECUTION_INDEX.json',dict(archive='RAW_EXECUTION.zip',bytes=(D/'RAW_EXECUTION.zip').stat().st_size,sha256=sha(D/'RAW_EXECUTION.zip'),members=index,crcAndAllMemberHashesVerified=True))
hist=R/'audit/gpt61-sol-high-comprehensive-2026-10-19/engineering-pending-evidence-reconciliation';prior=json.loads((hist/'CONSERVATION.json').read_text());archives=prior['all66ArchiveHashesMatched'];assert len(archives)==66
for p,h in archives.items():assert sha(R/p)==h,p
hi=json.loads((hist/'HISTORICAL_GENERATED_EVIDENCE_INDEX.json').read_text());assert sha(hist/hi['archive'])==hi['archiveSha256']
with zipfile.ZipFile(hist/hi['archive']) as z:
 assert z.testzip() is None
 for v in hi['members']:assert hashlib.sha256(z.read(v['path'])).hexdigest()==v['sha256']
for v in json.loads((hist/'PROPOSAL_REVIEW.json').read_text())['files']:assert sha(R/v['path'])==v['newSha256']
assert sha(R/'release/acceptance/candidate.json')==prior['candidateUnchangedSha256'] and not(R/'audit/final-curriculum-audit').exists()
for p in ['app/src/main','catalog','docs','review']:assert git('rev-parse','HEAD:'+p)==git('rev-parse',base+':'+p)
save('CONSERVATION.json',dict(baseline=base,testedCommit=c['sourceCommit'],onlyTenTestMethodsAndNewHelperChanged=changed,allBytesOutsideTargetedMethodsUnchanged=True,allOriginalLiteralDigestsUnchanged=True,mainCatalogDocsReviewAndAllPriorTrackedEvidenceUnchanged=True,all66ArchiveHashesMatched=archives,all64AuthenticHistoriesPreserved=True,historical167FileArchiveCrcAndEveryMemberHashVerified=True,current154GeneratedHashesUnchanged=True,candidateUnchangedSha256=prior['candidateUnchangedSha256'],oldUnit7RestoreCause='UNCONFIRMED',physicalAcceptance='OUTSTANDING_LAST'))
previous=R/'audit/gpt61-sol-high-comprehensive-2026-10-19/engineering-complete-rule-current-scope/REGRESSION_DISPOSITION.json';status=json.loads(previous.read_text());executed={v['testClass']+'#'+v['method']:v for v in x['tests']};rows=[];targeted=[]
for v in status['observations']:
 v=dict(v)
 if v['engineeringDisposition']=='OPEN_UNCHANGED_NOT_RERUN':
  assert executed[v['identity']]['outcome']=='PASSED';targeted.append(v['identity']);v['engineeringDisposition']='SCOPED_HISTORICAL_CONSERVATION_CURRENT_SOURCE_AND_NEGATIVE_ASSERTIONS_VERIFIED_NOT_INDEPENDENT_CLOSURE';v['scopedVerificationSource']=c['sourceCommit']
 rows.append(v)
assert len(targeted)==10 and len(rows)==14
save('REGRESSION_DISPOSITION.json',dict(originalLedger=status['originalLedger'],originalLedgerSha256=status['originalLedgerSha256'],priorDispositionSha256=sha(previous),observations=rows,scopedEngineeringReconciliations=14,remainingUnreconciledObservationsFromThisLedger=0,newBroadRegressionStillRequired=True,external17FindingStatusesUnchanged=True,completeSuite=False))
summary='Historical conservation/digest scope verified at `3346e47620da7c51bec85738df4b5c71b83b0578`:21selected host methods/12classes,21passed/0failed/0errors/0skipped,exit0. All10remaining methods plus11existing current teaching/source-rejection/governance checks execute. Original literal pins unchanged;every byte outside the10targeted method bodies unchanged,new exact-source helper only. Historical contracts bind genuine asset implementations;current pack/unit definitions/items/examples/provenance/capabilities match recorded implementation sources. Old Unit7package pin reconstructed with recorded7d92d881 source;current package/current governance assertions remain separate. Original14failure observations immutable;all14 now have scoped engineering reconciliations across separate commits/scopes,zero unmatched observations from that ledger. This is not a fresh broad/all-class/complete-suite result or independent acceptance. Fresh discovery and uninterrupted selected-host regression remain the next large task. All66archives/64histories/167historical generated members/154current generated hashes/candidate and production/catalog/docs/review preserved. AuditINCOMPLETE;external17findings unclosed;old Unit7 restore causeUNCONFIRMED;physicalLAST;no assembly/install/signing/merge/freeze/approval.'
report=f'''# Historical conservation and digest scope verified

{summary}

## What changed and why

Six conservation assertions compared later current content with an isolated earlier correction. They now execute their original contracts against actual asset implementations:fragment teaching7efff9e1,Unit4presente6db0bdf,Unit7agreementf1dad5d9,Unit8positive existencefe919656 andUnit15preparation0f8001a8. The original Unit14/15 comparison executes at recorded49a926c5 against96242a17,while current Unit15 independently matches its later0f8001a8 preparation. Current full validation stays on current content. A shared test-only helper first requires the entire decoded current pack to equal its last actual asset implementationb7e53230 and checks each affected current unit's complete definition/items/examples/provenance/capabilities/digest against its genuine current implementation. No current approval/admission/eligibility rule changed.

The test-file creation commit was not always the asset implementation. Raw source comparison shows f56dbeed's asset has6984provenance records while actual fragment correction7efff9e1 has6989;fcc0113f's asset has6989 while actual positive-existence correctionfe919656 has7024. SOURCE_RECONCILIATION records exact asset hashes,changed keys/units and record counts. Executed typed contracts,not those raw counts alone,justify the source bindings. Current teaching/repair/source-rejection methods remain current and execute separately.

Four digest methods stopped at earlier aggregate/unit identities. All literal64hex pins and digest maps remain byte-for-byte unchanged. The helper asserts old pins against49a926c5;unchanged units must still equal those pins currently,and declared changed Units4/7/8/10/15 must match their actual implementation objects and differ from the old pins. V2Rebuild keeps its original Unit1–5/aggregate expectations in the appropriate old/current scopes;later structural mapping mutations still use current pack. BatchE keeps original aggregate and Unit7content/package literals historically,using its old manifest's actual curriculum source7d92d881 to reconstruct packageacfecf29. Current readiness row/content/package equals the actual current source and standard current generator;all unsigned/frozen/source/variance/release-refusal assertions remain current. No package generator or recorded mapping fact changed.

METHOD_BOUNDARIES proves all bytes outside each of the10named method bodies are identical to baseline;CODE_REVIEW proves every original literal digest sequence unchanged. The only additional source is the test-only RecordedCurriculumConservationScope helper. No other test/assertion/fixture/helper was rewritten. The original ten failed outputs remain immutable in the earlier three-scope regression archives.

## Actual validation and limits

Tested source`{c['sourceCommit']}`:21reported/21passed/0failed/0errors/0skipped,12classes,exit0. Exact21selectors/command/source/root/input/init/runner/test hashes,cwd/resources/timestamps and all outcomes are in VERIFIED/CONTEXT.json and RESULT.json. Fresh XML/RESULT events/selector identities/outcomes reconcile exactly. Ten modified methods and11existing current teaching/repair/source-rejection/governance methods executed. Most classes were explicitly selected by method;do not claim full-class coverage. Two6GiBworkers/recycle4classes,GC retained,detached launcher,no queued input mutation or automatic publisher.

Task states:{json.dumps(x['tasks'],sort_keys=True)}. Lint severities:{json.dumps(x['lintIssuesBySeverity'],sort_keys=True)}. Cached/up-to-date is not fresh analysis. Gate attachment executed/PASS,not release approval. Four screenshot exporters/16methods explicitly excluded:VisualReviewCaptureTest2,Units35ChunkCaptureTest2,Units610ChunkCaptureTest10,Units1115GapCaptureTest2. No instrumented/device/exporter result. Configured APKdev.russiancompanion/2.0.0-dev/code5;no assembly/install/signing/new artifact hash/signature.

Original14regression observations now have14scoped engineering reconciliations:prior Unit7four-method scope atad0c5705,complete-rule10-method scope atc55ba69f,and this21-method scope. Those scopes have different commits and some overlapping methods;they are not summed or a fresh14failure-case/all-suite result. New broad execution remains required. The old original stopped-run and continuation events/failed messages remain immutable. Original17external findings retain qualified-review status;CC003 still lacks admitted contextual applications. No independent linguistic/source/rights/media/reference acceptance is inferred.

## Conserved evidence and next step

Raw source versions/logs/XML/events/GC and commands are CRC/every-member-SHA verified in RAW_EXECUTION.zip. All66original archive hashes/64authentic histories,167historical generated members,154current generated file hashes,candidate and main/catalog/docs/review trees unchanged. No old evidence was regenerated or removed. Original historical audit/fourCSV remain unavailable. Private Penguin was not used/copied to app branch/assets/packet. Environment config unchanged/saved earlier,publication user-confirmed independently unverified. Mainff539220562pass/1skip and420f41ff691sourceannotations/handoff execution unverified remain separate histories. Old Unit7 restore-refusal cause remainsUNCONFIRMED.

Next large task:fresh host discovery against the corrected commit,then a detached uninterrupted finite debug-host regression with all four exporter exclusions preserved. Do not reuse1320as the expected current scope without new discovery. After verified engineering evidence,perform final comprehensive independent nonphysical audit/recheck against exact source and privately obtained reference. Actual Galaxy S26 Ultra airplane-mode/reboot acceptance remainsLAST/outstanding. No merge,freeze,formal stage advancement,owner acceptance or release approval. Source/documentation whitespace checks exclude only retained forensic CODE_CHANGE.patch context;original patch bytes are preserved.
'''
(D/'ENGINEERING_CHANGE_REPORT.md').write_text(report)
(D/'NEXT_LARGE_TASK.md').write_text('''# Next large task: fresh discovery and uninterrupted host regression

The ten remaining conservation/digest methods have focused verification. Read ENGINEERING_CHANGE_REPORT.md, METHOD_BOUNDARIES.json, SOURCE_RECONCILIATION.json and REGRESSION_DISPOSITION.json here. All14original regression observations now have scoped engineering reconciliation;this is not fresh broad verification or independent acceptance.

Use one agent and the existing checkout on PR64. No new approval is required. Preserve the current clean checkpoint and all original raw failure/history/archive evidence. Do not rerun historical whole-scope publishers or rewrite their manifests.

1. Activate `/workspace/setup/android-env.sh`. Inspect current resources. Retain the four screenshot exporters/16methods as explicit exclusions. Do not assemble/install/sign an APK.
2. Prepare a new external run directory and immutable runner. Perform genuine current `testDebugUnitTest --test-dry-run` discovery with the saved cloud-validation init and resource settings. Record exact source/root/input/init/runner identities,commands and XML/RESULT events. Synthetic skips are discovery only,zero actual runtime passes. Derive the current exact method/class sets from fresh discovery;do not assume the previous1320scope or count source annotations as execution.
3. Save discovery/plan evidence and a checkpoint. For actual runtime,use a detached launcher with stdin/stdout/stderr independent of tool transport,two6GiBforks/recycle4classes/GC logs subject to current resource verification. Preserve TLS/checksum verification and exclusions. No selectors narrowing the fresh discovered host scope. Include compileDebugSources,lintDebug and verifyReleaseGateAttachment with `--continue --offline --max-workers=2 --console=plain` as supported by the retained runner.
4. Freeze all test/application/review/catalog/docs inputs during execution. No automatic source mutation or evidence publisher queued. Monitor the actual process and event progress;wait for underlying exit and collector. Validate fresh XML/events/exact discovered identities/outcomes,record failures/errors/skips separately and retain full messages. A stopped/crashed run is partial;archive evidence before any continuation and preserve explicit overlaps. Do not fabricate exit/final XML or infer OOM/causation without evidence.
5. Preserve exact task/cache states,lint severities,release-gate result,configured APK identity and absence of a new artifact/signature. Verify all66original archives/64histories,167historical generated members,154current generated hashes and candidate. Commit/push evidence,update AGENTS.md and both continuation/checkpoint files and Draft PR64 without force. No unqualified complete-suite/app/curriculum claim even if the selected host scope passes:exporter/instrumented/device and qualified audit scope remain separate.

After engineering regression,perform the final comprehensive independent nonphysical audit/recheck against exact corrected source and privately obtained Penguin reference. Original17external findings/CC003contextual applications and source/rights/media/mapping/qualification requirements retain their original statuses. Physical Galaxy S26 Ultra airplane-mode/reboot acceptance is LAST and outstanding. No merge/freeze/formal advancement/owner or release approval. Original historical audit/fourCSV still unavailable. Environment settings unchanged;publication user-confirmed independently unverified. No active test job or automatic publisher remains at this checkpoint.
''')
for n in ['CODEX_ENGINEERING_CONTINUATION.md','CODEX_CHECKPOINT_2026-10-12.md']:
 with (R/'audit/content-corrections'/n).open('a') as f:f.write('\n\n## Historical conservation/digest scope verified\n\n'+summary+' Read engineering-conservation-digest-scope/ENGINEERING_CHANGE_REPORT.md and NEXT_LARGE_TASK.md under audit/gpt61-sol-high-comprehensive-2026-10-19/.\n')
p=R/'AGENTS.md';p.write_text(p.read_text().replace('# Codex continuation\n','# Codex continuation\n\nCurrent engineering checkpoint: [historical conservation/digest scope verified](audit/gpt61-sol-high-comprehensive-2026-10-19/engineering-conservation-digest-scope/ENGINEERING_CHANGE_REPORT.md). '+summary+' Read NEXT_LARGE_TASK.md there before fresh discovery/regression.\n',1))
save('SHA256.json',{p.relative_to(D).as_posix():sha(p) for p in sorted(D.rglob('*')) if p.is_file() and p.name!='SHA256.json'})
print(summary)
