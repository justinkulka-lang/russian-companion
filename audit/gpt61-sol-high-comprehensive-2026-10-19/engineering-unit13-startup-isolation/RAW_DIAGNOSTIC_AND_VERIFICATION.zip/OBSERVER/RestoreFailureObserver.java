import com.sun.jdi.*;
import com.sun.jdi.connect.*;
import com.sun.jdi.event.*;
import com.sun.jdi.request.*;
import java.nio.file.*;
import java.util.*;

/** Pause only after a refusal condition was selected; never invoke target methods. */
public final class RestoreFailureObserver {
  static String path(ObjectReference file) {
    Field field = file.referenceType().fieldByName("path");
    Value value = field == null ? null : file.getValue(field);
    return value instanceof StringReference text ? text.value() : null;
  }
  public static void main(String[] args) throws Exception {
    var connector = Bootstrap.virtualMachineManager().attachingConnectors().stream()
      .filter(c -> c.name().equals("com.sun.jdi.SocketAttach")).findFirst().orElseThrow();
    var options = connector.defaultArguments();
    options.get("hostname").setValue("127.0.0.1"); options.get("port").setValue(args[0]);
    options.get("timeout").setValue("1000");
    VirtualMachine vm = null;
    long attachDeadline = System.currentTimeMillis() + 90000;
    while (vm == null) {
      try { vm = connector.attach(options); }
      catch (java.io.IOException unavailable) {
        if (System.currentTimeMillis() > attachDeadline) throw unavailable;
        Thread.sleep(500);
      }
    }
    var prepare = vm.eventRequestManager().createClassPrepareRequest();
    prepare.addClassFilter("dev.russiancompanion.data.local.LocalStore");
    prepare.setSuspendPolicy(EventRequest.SUSPEND_EVENT_THREAD); prepare.enable();
    Path output = Path.of(args[1]); Files.createDirectories(output);
    System.out.println("ATTACHED"); vm.resume(); int hit = 0;
    long deadline = System.currentTimeMillis() + 10 * 60 * 1000;
    try {
      while (System.currentTimeMillis() < deadline) {
        EventSet events = vm.eventQueue().remove(1000); if (events == null) continue;
        boolean finished = false;
        for (Event event : events) {
          if (event instanceof ClassPrepareEvent ready) {
            for (int line : new int[]{1566,1977,1989,1994,2000})
              for (Location location : ready.referenceType().locationsOfLine(line)) {
                var request = vm.eventRequestManager().createBreakpointRequest(location);
                request.setSuspendPolicy(EventRequest.SUSPEND_EVENT_THREAD); request.enable();
              }
            System.out.println("FAILURE_BREAKPOINTS_READY");
          } else if (event instanceof BreakpointEvent failed) {
            var frame = failed.thread().frame(0); ObjectReference store = frame.thisObject();
            if (store == null) continue;
            Field rootField = store.referenceType().fieldByName("recordingRoot");
            Value rootValue = store.getValue(rootField);
            if (!(rootValue instanceof ObjectReference file)) continue;
            String root = path(file); if (root == null || !root.endsWith("/recordings")) continue;
            hit++; System.out.println("SELECTED_FAILURE\t" + failed.location() + "\tcode=" + failed.location().codeIndex());
            for (var local : frame.visibleVariables()) {
              Value value = frame.getValue(local);
              if (value instanceof ObjectReference ref && ref.referenceType().name().equals("java.io.File"))
                System.out.println("FILE_LOCAL\t" + local.name() + "\t" + path(ref));
              if (value instanceof BooleanValue || value instanceof StringReference)
                System.out.println("LOCAL\t" + local.name() + "\t" + value);
            }
            Path parent = Path.of(root).getParent(); Path snapshot = output.resolve("hit-" + hit); Files.createDirectories(snapshot);
            try (var files = Files.list(parent)) {
              for (Path p : files.toList()) {
                if (!p.getFileName().toString().startsWith("backup-replace-recordings")) continue;
                System.out.println("HOST_FILE\t" + p.getFileName() + "\tfile=" + Files.isRegularFile(p) + "\tdirectory=" + Files.isDirectory(p));
                if (Files.isRegularFile(p)) Files.copy(p, snapshot.resolve(p.getFileName()), StandardCopyOption.REPLACE_EXISTING);
              }
            }
          } else if (event instanceof VMDeathEvent || event instanceof VMDisconnectEvent) finished = true;
        }
        events.resume(); if (finished) break;
      }
    } catch (VMDisconnectedException finished) {
      System.out.println("VM_DISCONNECTED");
    } finally { try { vm.dispose(); } catch (VMDisconnectedException finished) { } }
    System.out.println("FAILURE_HITS\t" + hit);
  }
}
