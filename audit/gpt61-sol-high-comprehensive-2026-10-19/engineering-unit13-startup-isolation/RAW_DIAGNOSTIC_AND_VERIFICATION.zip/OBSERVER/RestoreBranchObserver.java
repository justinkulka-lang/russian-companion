import com.sun.jdi.*;
import com.sun.jdi.connect.*;
import com.sun.jdi.event.*;
import com.sun.jdi.request.*;
import java.util.*;

/** Observe exceptions on LocalStore executor threads; never invoke target methods. */
public final class RestoreBranchObserver {
  static String clean(Object s) { return String.valueOf(s).replace('\n',' ').replace('\r',' '); }
  public static void main(String[] args) throws Exception {
    AttachingConnector connector = Bootstrap.virtualMachineManager().attachingConnectors().stream()
      .filter(c -> c.name().equals("com.sun.jdi.SocketAttach")).findFirst().orElseThrow();
    var options = connector.defaultArguments();
    options.get("hostname").setValue("127.0.0.1");
    options.get("port").setValue(args[0]);
    options.get("timeout").setValue("1000");
    VirtualMachine vm = null;
    long attachDeadline = System.currentTimeMillis() + 90000;
    while (vm == null) {
      try { vm = connector.attach(options); }
      catch (java.io.IOException unavailable) {
        if (System.currentTimeMillis() > attachDeadline) throw unavailable;
        Thread.sleep(500);
      }
    }
    var manager = vm.eventRequestManager();
    var start = manager.createThreadStartRequest();
    start.setSuspendPolicy(EventRequest.SUSPEND_EVENT_THREAD);
    start.enable();
    var prepare = manager.createClassPrepareRequest();
    prepare.addClassFilter("dev.russiancompanion.data.local.LocalStore");
    prepare.setSuspendPolicy(EventRequest.SUSPEND_EVENT_THREAD);
    prepare.enable();
    System.out.println("ATTACHED\t" + vm.version());
    vm.resume();
    long deadline = System.currentTimeMillis() + 10 * 60 * 1000;
    try {
      while (System.currentTimeMillis() < deadline) {
        EventSet events = vm.eventQueue().remove(1000);
        if (events == null) continue;
        boolean finished = false;
        for (Event event : events) {
          if (event instanceof ClassPrepareEvent prepared) {
            int count = 0;
            for (int line : new int[]{1498,1508,1511,1517,1518,1523,1524,1528,1530,1534,1536,1537,1539,1540,1545,1554,1556,1560,1562,1566,1575}) {
              for (Location location : prepared.referenceType().locationsOfLine(line)) {
                var breakpoint = manager.createBreakpointRequest(location);
                breakpoint.setSuspendPolicy(EventRequest.SUSPEND_EVENT_THREAD);
                breakpoint.enable(); count++;
              }
            }
            System.out.println("BRANCH_BREAKPOINTS\t" + count);
          } else if (event instanceof BreakpointEvent stopped) {
            var frame = stopped.thread().frame(0);
            ObjectReference store = frame.thisObject();
            if (store == null) {
              for (Value argument : frame.getArgumentValues())
                if (argument instanceof ObjectReference object && object.referenceType().name().equals("dev.russiancompanion.data.local.LocalStore")) store = object;
            }
            if (store != null) {
              Field rootField = store.referenceType().fieldByName("recordingRoot");
              Value rootValue = rootField == null ? null : store.getValue(rootField);
              if (rootValue instanceof ObjectReference root) {
                Field pathField = root.referenceType().fieldByName("path");
                Value pathValue = pathField == null ? null : root.getValue(pathField);
                if (pathValue instanceof StringReference path && path.value().endsWith("/recordings"))
                  System.out.println("FRESH_BRANCH\t" + stopped.location() + "\tcode=" + stopped.location().codeIndex() + "\tmethod=" + stopped.location().method().name() + "\troot=" + path.value());
              }
            }
          } else if (event instanceof ThreadStartEvent threadStart) {
            ThreadReference thread = threadStart.thread();
            if (thread.name().equals("russian-companion-store")) {
              var exception = manager.createExceptionRequest(null, true, true);
              exception.addThreadFilter(thread);
              exception.setSuspendPolicy(EventRequest.SUSPEND_EVENT_THREAD);
              exception.enable();
              System.out.println("OBSERVING_STORE_THREAD\t" + thread.uniqueID());
            }
          } else if (event instanceof ExceptionEvent exception) {
            ObjectReference value = exception.exception();
            Location caught = exception.catchLocation();
            String type = value.referenceType().name();
            if ((caught != null && caught.declaringType().name().equals("dev.russiancompanion.data.local.LocalStore"))
                || type.contains("SQLite")) {
              Field message = value.referenceType().fieldByName("detailMessage");
              Value detail = message == null ? null : value.getValue(message);
              System.out.println("EXCEPTION\t" + type + "\t" + clean(detail) + "\tthrown=" + exception.location()
                + "\tcaught=" + caught);
              for (StackFrame frame : exception.thread().frames()) {
                String name = frame.location().declaringType().name();
                if (name.startsWith("dev.russiancompanion.") || name.startsWith("androidx.room."))
                  System.out.println("FRAME\t" + frame.location());
              }
            }
          } else if (event instanceof VMDeathEvent || event instanceof VMDisconnectEvent) {
            finished = true;
          }
        }
        events.resume();
        if (finished) break;
      }
    } catch (VMDisconnectedException ended) {
      System.out.println("VM_DISCONNECTED");
    } finally {
      try { vm.dispose(); } catch (VMDisconnectedException ended) { }
    }
  }
}
