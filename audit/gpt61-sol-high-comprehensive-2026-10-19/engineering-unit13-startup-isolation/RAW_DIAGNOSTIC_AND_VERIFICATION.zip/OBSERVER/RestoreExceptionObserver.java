import com.sun.jdi.*;
import com.sun.jdi.connect.*;
import com.sun.jdi.event.*;
import com.sun.jdi.request.*;
import java.util.*;

/** Observe exceptions on LocalStore executor threads; never invoke target methods. */
public final class RestoreExceptionObserver {
  static String clean(Object s) { return String.valueOf(s).replace('\n',' ').replace('\r',' '); }
  public static void main(String[] args) throws Exception {
    AttachingConnector connector = Bootstrap.virtualMachineManager().attachingConnectors().stream()
      .filter(c -> c.name().equals("com.sun.jdi.SocketAttach")).findFirst().orElseThrow();
    var options = connector.defaultArguments();
    options.get("hostname").setValue("127.0.0.1");
    options.get("port").setValue(args[0]);
    options.get("timeout").setValue("1000");
    VirtualMachine vm = null;
    long attachDeadline = System.currentTimeMillis() + 90000;
    while (vm == null) {
      try { vm = connector.attach(options); }
      catch (java.io.IOException unavailable) {
        if (System.currentTimeMillis() > attachDeadline) throw unavailable;
        Thread.sleep(500);
      }
    }
    var manager = vm.eventRequestManager();
    var start = manager.createThreadStartRequest();
    start.setSuspendPolicy(EventRequest.SUSPEND_EVENT_THREAD);
    start.enable();
    System.out.println("ATTACHED\t" + vm.version());
    vm.resume();
    long deadline = System.currentTimeMillis() + 10 * 60 * 1000;
    try {
      while (System.currentTimeMillis() < deadline) {
        EventSet events = vm.eventQueue().remove(1000);
        if (events == null) continue;
        boolean finished = false;
        for (Event event : events) {
          if (event instanceof ThreadStartEvent threadStart) {
            ThreadReference thread = threadStart.thread();
            if (thread.name().equals("russian-companion-store")) {
              var exception = manager.createExceptionRequest(null, true, true);
              exception.addThreadFilter(thread);
              exception.setSuspendPolicy(EventRequest.SUSPEND_EVENT_THREAD);
              exception.enable();
              System.out.println("OBSERVING_STORE_THREAD\t" + thread.uniqueID());
            }
          } else if (event instanceof ExceptionEvent exception) {
            ObjectReference value = exception.exception();
            Location caught = exception.catchLocation();
            String type = value.referenceType().name();
            if ((caught != null && caught.declaringType().name().equals("dev.russiancompanion.data.local.LocalStore"))
                || type.contains("SQLite")) {
              Field message = value.referenceType().fieldByName("detailMessage");
              Value detail = message == null ? null : value.getValue(message);
              System.out.println("EXCEPTION\t" + type + "\t" + clean(detail) + "\tthrown=" + exception.location()
                + "\tcaught=" + caught);
              for (StackFrame frame : exception.thread().frames()) {
                String name = frame.location().declaringType().name();
                if (name.startsWith("dev.russiancompanion.") || name.startsWith("androidx.room."))
                  System.out.println("FRAME\t" + frame.location());
              }
            }
          } else if (event instanceof VMDeathEvent || event instanceof VMDisconnectEvent) {
            finished = true;
          }
        }
        events.resume();
        if (finished) break;
      }
    } catch (VMDisconnectedException ended) {
      System.out.println("VM_DISCONNECTED");
    } finally {
      try { vm.dispose(); } catch (VMDisconnectedException ended) { }
    }
  }
}
