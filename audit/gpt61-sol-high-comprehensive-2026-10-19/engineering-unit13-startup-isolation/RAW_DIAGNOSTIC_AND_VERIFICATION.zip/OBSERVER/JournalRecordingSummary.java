import jdk.jfr.consumer.*;
import java.nio.file.*;
import java.util.*;

/** Read an existing diagnostic recording; no target JVM connection or mutation. */
public final class JournalRecordingSummary {
  public static void main(String[] args) throws Exception {
    Map<String, Long> counts = new TreeMap<>(); int selected = 0;
    try (RecordingFile file = new RecordingFile(Path.of(args[0]))) {
      while (file.hasMoreEvents()) {
        RecordedEvent event = file.readEvent(); String type = event.getEventType().getName();
        counts.merge(type, 1L, Long::sum);
        var stack = event.getStackTrace();
        boolean journal = stack != null && stack.getFrames().stream().anyMatch(f ->
          f.getMethod().getType().getName().equals("dev.russiancompanion.data.local.LocalStore") &&
          List.of("markReplacementJournalCommitted", "writeJournalAtomically").contains(f.getMethod().getName()));
        if (!journal) continue;
        if (!type.equals("jdk.JavaExceptionThrow")) {
          String path = event.getString("path");
          if (!path.contains("freshTeachingAndAnswersReestablishCompletionWithoutRelabellingOldAssignments")) continue;
        }
        selected++; System.out.println("SELECTED_EVENT\t" + event.getStartTime() + "\t" + type);
        if (type.equals("jdk.JavaExceptionThrow"))
          System.out.println("THROWN\t" + event.getClass("thrownClass").getName() + "\t" + event.getString("message"));
        else System.out.println("FILE\t" + event.getString("path") + "\tbytes=" + event.getLong(type.equals("jdk.FileRead") ? "bytesRead" : "bytesWritten"));
        for (RecordedFrame frame : stack.getFrames())
          System.out.println("FRAME\t" + frame.getMethod().getType().getName() + "." + frame.getMethod().getName() + ":" + frame.getLineNumber());
      }
    }
    System.out.println("EVENT_COUNTS\t" + counts);
    System.out.println("SELECTED_EVENTS\t" + selected);
  }
}
