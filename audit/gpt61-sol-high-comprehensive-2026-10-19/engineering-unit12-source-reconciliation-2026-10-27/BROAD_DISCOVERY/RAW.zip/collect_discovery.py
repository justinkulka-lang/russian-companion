from pathlib import Path
import json,hashlib,zipfile,shutil,subprocess
R=Path('/workspace/russian-companion');W=Path(__file__).parent;D=R/'audit/gpt61-sol-high-comprehensive-2026-10-19/engineering-unit12-source-reconciliation-2026-10-27';A=D/'BROAD_DISCOVERY';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();save=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
r=json.loads((W/'DISCOVERY/RESULT.json').read_text());c=json.loads((W/'DISCOVERY/CONTEXT.json').read_text());end=json.loads((W/'DISCOVERY_COMPLETION.json').read_text());inv=json.loads((W/'INVENTORY.json').read_text());assert end['runnerExit']==r['exitCode']==int(end['gradleExit'])==0 and r['testCounts']==dict(reported=1458,passed=0,failed=0,errors=0,skipped=1458) and r['classes']==253
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True).strip()
assert r['sourceCommit']==c['sourceCommit']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
prior=json.loads((R/inv['priorBroadResultPath']).read_text());old={(x['testClass'],x['method']) for x in prior['tests']};current={(x['testClass'],x['method']) for x in r['tests']};added=current-old;removed=old-current
assert len(old)==1441 and len(added)==17 and not removed and added=={(x['testClass'],x['method']) for x in inv['expectedAdded']}
assert current=={(x['testClass'],x['method']) for x in inv['tests']}
assert not (A/'RAW.zip').exists();files={p.relative_to(W).as_posix():p for p in (W/'DISCOVERY').rglob('*') if p.is_file()}
for n in ['DISCOVERY_COMPLETION.json','DISCOVERY_LAUNCHER.json','DISCOVERY_RUNNER_PROCESS.json','DISCOVERY_LAUNCHER.exit','DISCOVERY_RUNNER.log','DISCOVERY_LAUNCHER.log','run.py','supervise.py','resources.gradle','collect_discovery.py']:files[n]=W/n
for n in c['initScriptSha256']:files['INIT/'+Path(n).name]=Path(n)
files['PRIOR_BROAD_RESULT.json']=R/inv['priorBroadResultPath'];index={}
with zipfile.ZipFile(A/'RAW.zip','x',zipfile.ZIP_DEFLATED) as z:
 for name,p in sorted(files.items()):assert not name.lower().endswith('.pdf');z.write(p,name);index[name]=dict(bytes=p.stat().st_size,sha256=sha(p))
save(A/'RAW_INDEX.json',index)
for name in ['CONTEXT.json','RESULT.json','RESULTS.csv','RUN.exit','SHA256.json']:shutil.copy2(W/'DISCOVERY'/name,A/name)
save(A/'IDENTITY_DELTA.json',dict(priorBroadSource=prior['sourceCommit'],priorBroadResultSha256=sha(R/inv['priorBroadResultPath']),discoverySource=r['sourceCommit'],all1441EarlierMethodsPreserved=True,added=[dict(testClass=k[0],method=k[1]) for k in sorted(added)],removed=[],runtimeTestsExecuted=0,completeSuite=False))
v=json.loads(subprocess.check_output(['python3',str(A/'verify.py')],cwd=R,text=True));save(A/'VERIFICATION.json',v);print(json.dumps(v))
