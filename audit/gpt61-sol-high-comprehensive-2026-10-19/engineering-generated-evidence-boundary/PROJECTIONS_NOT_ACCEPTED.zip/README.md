# Diagnostic output only — not accepted review evidence

These are exact current compiled generator renderings from the source recorded in PROJECTION_CONTEXT.json. They were written outside the checkout; no tracked report or review file was overwritten. Existing source pointers remain in the renderings and require reconciliation. Do not copy this archive over current review/ or claim a review/audit/approval passed. See DRIFT_RECONCILIATION.json and NEXT_LARGE_TASK.md for required source-binding and historical-preservation work. No private PDF is included.
